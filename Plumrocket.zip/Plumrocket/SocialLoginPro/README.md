social-login-pro

Social Networks

Apple
_____
[Read official documentation](https://developer.apple.com/sign-in-with-apple/usage-guidelines-for-websites-and-other-platforms/)

For using this network, merchant must get "file_key.p8" from official site, then generate secret in extension admin