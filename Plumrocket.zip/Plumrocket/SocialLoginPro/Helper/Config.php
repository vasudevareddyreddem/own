<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2018 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Helper;

class Config extends Main
{
    const DISABLE_MODULE = 'Plumrocket_SocialLoginFree';
    const FREE_CONFIG_PATH = 'psloginfree';
    const PRO_CONFIG_PATH = 'psloginpro';

    /**
     * @var \Plumrocket\SocialLoginPro\Helper\Data
     */
    private $dataHelper;

    /**
     * @var \Magento\Framework\Module\Status
     */
    private $status;

    /**
     * @var \Magento\Config\Model\ResourceModel\Config\Data\CollectionFactory
     */
    private $configDataCollectionFactory;

    /**
     * Config constructor.
     *
     * @param \Magento\Framework\ObjectManagerInterface                         $objectManager
     * @param \Magento\Framework\App\Helper\Context                             $context
     * @param \Plumrocket\SocialLoginPro\Helper\Data                            $dataHelper
     * @param \Magento\Framework\Module\Status                                  $status
     * @param \Magento\Config\Model\ResourceModel\Config\Data\CollectionFactory $configDataCollectionFactory
     */
    public function __construct(
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\App\Helper\Context $context,
        \Plumrocket\SocialLoginPro\Helper\Data $dataHelper,
        \Magento\Framework\Module\Status $status,
        \Magento\Config\Model\ResourceModel\Config\Data\CollectionFactory $configDataCollectionFactory
    ) {
        $this->dataHelper                  = $dataHelper;
        $this->status                      = $status;
        $this->configDataCollectionFactory = $configDataCollectionFactory;
        parent::__construct($objectManager, $context);
    }

    /**
     * Copies configuration from the Plumrocket_SocialLoginFree module config
     * Used one time on install or update
     *
     * @return $this
     * @throws \Exception
     */
    public function copyConfig()
    {
        if ($this->_moduleManager->isEnabled(self::DISABLE_MODULE)) {
            $this->dataHelper->disableExtension(self::FREE_CONFIG_PATH);
            /** @var \Magento\Config\Model\ResourceModel\Config\Data\Collection $configDataCollection */
            $configDataCollection = $this->configDataCollectionFactory->create();
            $configDataCollection->addPathFilter(self::FREE_CONFIG_PATH);

            foreach ($configDataCollection as $item) {
                $path = $item->getData('path');
                $newPath = str_replace(self::FREE_CONFIG_PATH, self::PRO_CONFIG_PATH, $path);
                $item->setData('path', $newPath);
            }

            $configDataCollection->save();
            $this->status->setIsEnabled(false, [self::DISABLE_MODULE]);
            return $this;
        }
    }
}
