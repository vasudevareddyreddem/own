<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Helper;

use Magento\Cms\Helper\Page;
use Magento\Customer\Model\Customer;
use Magento\Customer\Model\Url;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Filesystem;
use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Framework\Stdlib\Cookie\PublicCookieMetadataFactory;
use Magento\Framework\Stdlib\CookieManagerInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Store\Model\Store;
use Magento\Store\Model\StoreManager;
use Plumrocket\SocialLoginPro\Api\Buttons\ProviderInterface;
use Plumrocket\SocialLoginPro\Model\Account\Photo;
use Plumrocket\SocialLoginPro\Model\Config\Provider;
use Plumrocket\SocialLoginPro\Model\Provider\Callback;
use Magento\Framework\App\Response\RedirectInterface;

class Data extends Main
{
    /**
     * Section name for configs
     */
    const SECTION_ID = 'psloginpro';

    const REFERER_QUERY_PARAM_NAME = 'pslogin_referer';
    const REFERER_STORE_PARAM_NAME = 'pslogin_referer_store';
    const SHOW_POPUP_PARAM_NAME = 'pslogin_show_popup';
    const SHOW_LINKPOPUP_PARAM_NAME = 'pslogin_show_linkpopup';

    const API_CALL_PARAM_NAME = 'pslogin_api_call';
    const FAKE_EMAIL_PREFIX = 'temp-email-ps';
    const TIME_TO_EDIT = 300;
    const COOKIE_DURATION = 600;
    const DEBUG_MODE = false;
    const DEFAULT_STORE_CODE = 1;

    protected $_configSectionId = 'psloginpro';

    /**
     * @var null|array
     */
    protected $buttonsPrepared;

    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    protected $customerSession;

    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $filesystem;

    /**
     * @var \Magento\Store\Model\Store
     */
    protected $store;

    /**
     * @var \Magento\Customer\Model\Customer
     */
    protected $customer;

    /**
     * @var \Magento\Store\Model\StoreManager
     */
    protected $storeManager;

    /**
     * @var \Magento\Backend\Helper\Data
     */
    protected $backendHelper;

    /**
     * @var \Magento\Framework\Stdlib\CookieManagerInterface
     */
    protected $cookieManager;

    /**
     * @var \Magento\Framework\Stdlib\Cookie\PublicCookieMetadataFactory
     */
    protected $publicCookieMetadataFactory;

    /**
     * @var \Magento\Framework\Url
     */
    protected $url;

    /**
     * @var \Magento\Customer\Model\Url
     */
    protected $customerUrl;

    /**
     * @var \Magento\Cms\Helper\Page
     */
    protected $cmsPageHelper;

    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @var \Magento\Config\Model\Config
     */
    protected $config;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    protected $timezone;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\Config\Provider
     */
    private $configProvider;

    /**
     * @var \Plumrocket\SocialLoginPro\Api\Buttons\ProviderInterface
     */
    private $buttonsProvider;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\Provider\Callback
     */
    private $callback;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\Account\Photo
     */
    private $photo;

    /**
     * @var \Magento\Framework\App\Response\RedirectInterface
     */
    private $redirect;

    /**
     * Data constructor.
     *
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\Session\SessionManagerInterface $customerSession
     * @param \Magento\Framework\Filesystem $filesystem
     * @param \Magento\Store\Model\Store $store
     * @param \Magento\Customer\Model\Customer $customer
     * @param \Magento\Store\Model\StoreManager $storeManager
     * @param \Magento\Backend\Helper\Data $backendHelper
     * @param \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager
     * @param \Magento\Framework\Url $url
     * @param \Magento\Customer\Model\Url $customerUrl
     * @param \Magento\Cms\Helper\Page $cmsPageHelper
     * @param \Magento\Framework\Stdlib\Cookie\PublicCookieMetadataFactory $publicCookieMetadataFactory
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
     * @param \Magento\Config\Model\Config $config
     * @param \Plumrocket\SocialLoginPro\Model\Config\Provider $configProvider
     * @param \Plumrocket\SocialLoginPro\Api\Buttons\ProviderInterface $buttonsProvider
     * @param \Plumrocket\SocialLoginPro\Model\Provider\Callback $callback
     * @param \Plumrocket\SocialLoginPro\Model\Account\Photo $photo
     * @param \Magento\Framework\App\Response\RedirectInterface $redirect
     */
    public function __construct(
        ObjectManagerInterface $objectManager,
        Context $context,
        SessionManagerInterface $customerSession,
        Filesystem $filesystem,
        Store $store,
        Customer $customer,
        StoreManager $storeManager,
        \Magento\Backend\Helper\Data $backendHelper,
        CookieManagerInterface $cookieManager,
        \Magento\Framework\Url $url,
        Url $customerUrl,
        Page $cmsPageHelper,
        PublicCookieMetadataFactory $publicCookieMetadataFactory,
        ResourceConnection $resourceConnection,
        TimezoneInterface $timezone,
        \Magento\Config\Model\Config $config,
        Provider $configProvider,
        ProviderInterface $buttonsProvider,
        Callback $callback,
        Photo $photo,
        RedirectInterface $redirect
    ) {
        $this->_configSectionId = self::SECTION_ID;
        parent::__construct($objectManager, $context);
        $this->customerSession  = $customerSession;
        $this->filesystem       = $filesystem;
        $this->store            = $store;
        $this->customer         = $customer;
        $this->storeManager     = $storeManager;
        $this->backendHelper    = $backendHelper;
        $this->cookieManager    = $cookieManager;
        $this->url              = $url;
        $this->customerUrl      = $customerUrl;
        $this->cmsPageHelper    = $cmsPageHelper;
        $this->publicCookieMetadataFactory = $publicCookieMetadataFactory;
        $this->resourceConnection = $resourceConnection;
        $this->timezone = $timezone;
        $this->config = $config;
        $this->configProvider = $configProvider;
        $this->buttonsProvider = $buttonsProvider;
        $this->callback = $callback;
        $this->photo = $photo;
        $this->redirect = $redirect;
    }

    /**
     * @return bool
     */
    public function moduleEnabled(): bool
    {
        return (bool)$this->getConfig($this->_configSectionId . '/general/enable');
    }

    /**
     * @return mixed
     */
    public function getShareData()
    {
        return $this->getConfig($this->_configSectionId . '/share');
    }

    /**
     * @return bool
     */
    public function photoEnabled(): bool
    {
        return $this->configProvider->isEnabledPhoto();
    }

    /**
     * @deprecated since 2.3.2
     * @see \Plumrocket\SocialLoginPro\Helper\Config\OneTap::isEnabled
     * @return bool
     */
    public function enableOneTapSignUp(): bool
    {
        return (bool)$this->getConfig($this->_configSectionId . '/google/enable_onetapsignup');
    }

    /**
     * @deprecated since 2.3.2
     * @see \Plumrocket\SocialLoginPro\Helper\Config\OneTap::getAllowedPages
     * @return false|string[]
     */
    public function getAllowedPages()
    {
        return explode(',', $this->getConfig($this->_configSectionId . '/google/onetapsignup_pages'));
    }

    /**
     * @deprecated since 2.3.2
     * @see \Plumrocket\SocialLoginPro\Helper\Config\OneTap::getClientId
     * @return string
     */
    public function getOtClientId(): string
    {
        return (string)$this->getConfig($this->_configSectionId . '/google/application_id');
    }

    /**
     * @param $position
     * @return bool
     */
    public function modulePositionEnabled($position): bool
    {
        $enabledFor = explode(',', $this->configProvider->getEnabledFor());
        return $this->moduleEnabled() && in_array($position, $enabledFor);
    }

    /**
     * @param null $configSection
     * @throws \Exception
     */
    public function disableExtension($configSection = null)
    {
        if ($configSection === null) {
            $configSection = $this->_configSectionId;
        }

        $connection = $this->resourceConnection->getConnection('core_write');
        $connection->delete(
            $this->resourceConnection->getTableName('core_config_data'),
            [$connection->quoteInto('path = ?', $configSection.'/general/enable')]
        );

        $this->config->setDataByPath($configSection.'/general/enable', 0);
        $this->config->save();
    }

    /**
     * @return bool
     */
    public function hasButtons(): bool
    {
        if (! $this->moduleEnabled()) {
            return false;
        }

        if ($this->customerSession->isLoggedIn()) {
            return false;
        }

        return (bool)$this->getButtons();
    }

    /**
     * @deprecated
     * @see \Plumrocket\SocialLoginPro\Model\Account\Photo::getPhotoUrl
     * @param bool $checkIsEnabled
     * @param null $customerId
     * @return bool|string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getPhotoPath($checkIsEnabled = true, $customerId = null)
    {
        if ($checkIsEnabled && ! $this->photoEnabled()) {
            return false;
        }

        if ($customerId === null) {
            if (!$this->customerSession->isLoggedIn()) {
                return false;
            }

            if (! $this->customerSession->getLoginProvider()) {
                return false;
            }

            if (! $customerId = $this->customerSession->getCustomerId()) {
                return false;
            }
        } elseif (! is_numeric($customerId) || $customerId <= 0) {
            return false;
        }

        return $this->photo->getPhotoUrl($customerId);
    }

    /**
     * @return bool
     */
    public function isGlobalScope(): bool
    {
        return $this->customer->getSharingConfig()->isGlobalScope();
    }

    /**
     * @return string[]
     */
    public function getRedirect(): array
    {
        return [
            'login' => $this->configProvider->getRedirectForLogin(),
            'login_link' => $this->configProvider->getRedirectLinkForLogin(),
            'register' => $this->configProvider->getRedirectForRegister(),
            'register_link' => $this->configProvider->getRedirectLinkForRegister(),
        ];
    }

    /**
     * @deprecated since 3.3.0
     * @see \Plumrocket\SocialLoginPro\Model\Provider\Callback::getUrl
     *
     * @param $provider
     * @param bool $byRequest
     * @return false|string|string[]|null
     */
    public function getCallbackURL($provider, $byRequest = false)
    {
        return $this->callback->getUrl($provider, $byRequest);
    }

    /**
     * @return array
     */
    public function getButtons(): array
    {
        return $this->buttonsProvider->getButtons();
    }

    /**
     * @param null|string $part
     * @return array
     */
    public function getPreparedButtons($part = null): array
    {
        if (null === $this->buttonsPrepared) {
            $this->buttonsPrepared = $this->buttonsProvider->getPreparedButtons();
        }

        return isset($this->buttonsPrepared[$part])
            ? $this->buttonsPrepared[$part]
            : array_merge($this->buttonsPrepared['visible'], $this->buttonsPrepared['hidden']);
    }

    /**
     * @param bool $value
     * @return mixed
     */
    public function refererLink($value = false)
    {
        // Customer session.
        $prevValueByCustomer = $this->customerSession->getData(self::REFERER_QUERY_PARAM_NAME);

        if ($value) {
            $this->customerSession->setData(self::REFERER_QUERY_PARAM_NAME, $value);
        } elseif ($value === null) {
            $this->customerSession->unsetData(self::REFERER_QUERY_PARAM_NAME);
        }

        return $prevValueByCustomer;
    }

    /**
     * @return string|null
     */
    public function getCookieRefererLink()
    {
        return $this->cookieManager->getCookie(self::REFERER_QUERY_PARAM_NAME);
    }

    /**
     * @param bool $value
     * @return mixed
     */
    public function refererStore($value = false)
    {
        // Customer session.
        $prevValueByCustomer = $this->customerSession->getData(self::REFERER_STORE_PARAM_NAME);

        if ($value) {
            $this->customerSession->setData(self::REFERER_STORE_PARAM_NAME, $value);
        } elseif ($value === null) {
            $this->customerSession->unsetData(self::REFERER_STORE_PARAM_NAME);
        }

        return $prevValueByCustomer;
    }

    /**
     * @return array
     */
    public function getRefererLinkSkipModules(): array
    {
        return ['customer/account', 'pslogin/account'];
    }

    /**
     * @throws \Magento\Framework\Exception\InputException
     * @throws \Magento\Framework\Stdlib\Cookie\CookieSizeLimitReachedException
     * @throws \Magento\Framework\Stdlib\Cookie\FailureToSendException
     */
    public function showSharePopup()
    {
        $publicCookieMetadata = $this->publicCookieMetadataFactory->create(['metadata' => []]);
        $publicCookieMetadata
            ->setDuration(self::COOKIE_DURATION)
            ->setPath('/');

        $this->cookieManager->setPublicCookie(self::SHOW_POPUP_PARAM_NAME, 1, $publicCookieMetadata);
    }

    /**
     * @return bool
     */
    public function isReminderPopupEnabled(): bool
    {
        return $this->configProvider->isReminderPopupEnabled() && $this->configProvider->isLinkingEnabled();
    }

    /**
     * @throws \Magento\Framework\Exception\InputException
     * @throws \Magento\Framework\Stdlib\Cookie\CookieSizeLimitReachedException
     * @throws \Magento\Framework\Stdlib\Cookie\FailureToSendException
     */
    public function showLinkReminderPopup()
    {
        $publicCookieMetadata = $this->publicCookieMetadataFactory->create(['metadata' => []]);
        $publicCookieMetadata
            ->setDuration(self::COOKIE_DURATION)
            ->setPath('/');

        $this->cookieManager->setPublicCookie(self::SHOW_LINKPOPUP_PARAM_NAME, 1, $publicCookieMetadata);
    }

    /**
     * @param string $after
     * @return string|null
     */
    public function getRedirectUrl($after = 'login')
    {
        $redirectUrl = null;
        $redirect = $this->getRedirect();

        // do not need redirect url
        if (($after === 'login' || $after === 'register') && $this->customerSession->getBeforeRequestParams()) {
            return '';
        }

        switch ($redirect[$after]) {
            case '__referer__':
                $redirectUrl = $this->redirect->getRefererUrl();
                break;

            case '__custom__':
                $redirectUrl = $redirect["{$after}_link"];
                if (!$this->isUrlInternal($redirectUrl)) {
                    $redirectUrl = $this->store->getBaseUrl() . $redirectUrl;
                }
                break;

            case '__dashboard__':
                $redirectUrl = $this->customerUrl->getDashboardUrl();
                break;

            default:
                if (is_numeric($redirect[$after])) {
                    $redirectUrl = $this->cmsPageHelper->getPageUrl($redirect[$after]);
                }
        }

        if (! $redirectUrl) {
            $redirectUrl = $this->customerUrl->getDashboardUrl();
        }

        return $redirectUrl;
    }

    /**
     * @param $url
     * @return bool
     */
    public function isUrlInternal($url): bool
    {
        return (stripos($url, 'http') === 0);
    }

    /**
     * @return bool
     */
    public function moduleInvitationsEnabled(): bool
    {
        return $this->moduleExists('Invitations') === 2;
    }

    /**
     * @param null|string $email
     * @return bool
     */
    public function isFakeMail($email = null): bool
    {
        if (null === $email && $this->customerSession->isLoggedIn()) {
            $email = $this->customerSession->getCustomer()->getEmail();
        }

        return strpos($email, self::FAKE_EMAIL_PREFIX) === 0;
    }

    /**
     * @return string
     */
    public function getCheckoutJsViewAuthentication(): string
    {
        if ($this->moduleEnabled() && $this->configProvider->getReplaceTemplates()) {
            $viewFile = 'Plumrocket_SocialLoginPro/js/view/checkout/authentication';
        } else {
            $viewFile = 'Magento_Checkout/js/view/authentication';
        }

        return $viewFile;
    }

    /**
     * @return string
     */
    public function getCheckoutJsViewFormElementEmail(): string
    {
        if ($this->moduleEnabled() && $this->configProvider->getReplaceTemplates()) {
            $viewFile = 'Plumrocket_SocialLoginPro/js/view/checkout/form/element/email';
        } else {
            $viewFile = 'Magento_Checkout/js/view/form/element/email';
        }

        return $viewFile;
    }

    /**
     * @return string
     */
    public function getCustomerJsViewAuthenticationPopup(): string
    {
        if ($this->moduleEnabled() && $this->configProvider->getReplaceTemplates()) {
            $viewFile = 'Plumrocket_SocialLoginPro/js/view/customer/authentication-popup';
        } else {
            $viewFile = 'Magento_Customer/js/view/authentication-popup';
        }

        return $viewFile;
    }

    /**
     * @return bool
     */
    public function getDebugMode(): bool
    {
        return (bool)$this->getConfig($this->_configSectionId.'/developer/enable');
    }

    /**
     * Is social linking enabled
     * @return boolean
     */
    public function isLinkingEnabled(): bool
    {
        return $this->configProvider->isLinkingEnabled();
    }

    /**
     * Retrieve linking description
     * @return string
     */
    public function getLinkingDescription(): string
    {
        return $this->configProvider->getLinkingDescription();
    }

    /**
     * @return string
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getDateTime(): string
    {
        return $this->timezone->convertConfigTimeToUtc($this->timezone->date()->format('Y-m-d H:i:s'));
    }
}
