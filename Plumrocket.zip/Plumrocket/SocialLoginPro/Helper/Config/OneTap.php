<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Csp
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Helper\Config;

use Plumrocket\Base\Helper\ConfigUtils;

/**
 * @since 2.3.2
 */
class OneTap extends ConfigUtils
{
    const XML_PATH_ENABLED = 'psloginpro/google/enable_onetapsignup';
    const XML_PATH_ALLOWED_PAGES = 'psloginpro/google/onetapsignup_pages';
    const XML_PATH_CLIENT_ID = 'psloginpro/google/application_id';
    const XML_PATH_AUTO_SIGN_IN = 'psloginpro/google/one_tap_auto_sign_in';
    const XML_PATH_PROMPT_TITLE = 'psloginpro/google/one_tap_prompt_title';
    const XML_PATH_PROMPT_POSITION = 'psloginpro/google/one_tap_sign_in_prompt';

    /**
     * @param null $store
     * @param null $scope
     * @return bool
     */
    public function isEnabled($store = null, $scope = null): bool
    {
        return (bool) $this->getConfig(self::XML_PATH_ENABLED, $store, $scope);
    }

    /**
     * @param null $store
     * @param null $scope
     * @return string
     */
    public function getClientId($store = null, $scope = null): string
    {
        return (string) $this->getConfig(self::XML_PATH_CLIENT_ID, $store, $scope);
    }

    /**
     * @param null $store
     * @param null $scope
     * @return array
     */
    public function getAllowedPages($store = null, $scope = null): array
    {
        return $this->prepareMultiselectValue($this->getConfig(self::XML_PATH_ALLOWED_PAGES, $store, $scope));
    }

    /**
     * @param null $store
     * @param null $scope
     * @return bool
     */
    public function isAllowedOnCurrentPage($store = null, $scope = null): bool
    {
        return in_array(
            $this->_request->getFullActionName(),
            $this->getAllowedPages($store, $scope),
            true
        );
    }

    /**
     * @param null $store
     * @param null $scope
     * @return bool
     */
    public function isEnabledAutoSignIn($store = null, $scope = null): bool
    {
        return (bool) $this->getConfig(self::XML_PATH_AUTO_SIGN_IN, $store, $scope);
    }

    /**
     * @param null $store
     * @param null $scope
     * @return string
     */
    public function getPromptTitle($store = null, $scope = null): string
    {
        return (string) $this->getConfig(self::XML_PATH_PROMPT_TITLE, $store, $scope);
    }

    /**
     * @param null $store
     * @param null $scope
     * @return string
     */
    public function getPromptPosition($store = null, $scope = null): string
    {
        return (string) $this->getConfig(self::XML_PATH_PROMPT_POSITION, $store, $scope);
    }
}
