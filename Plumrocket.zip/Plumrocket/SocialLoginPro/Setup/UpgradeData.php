<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Setup;

use Magento\Config\Model\ResourceModel\Config\Data\CollectionFactory;
use Magento\Customer\Model\Customer;
use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\App\Config\Storage\WriterInterface;
use Magento\Framework\App\State;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;
use Plumrocket\SocialLoginPro\Helper\ConfigFactory;
use Plumrocket\SocialLoginPro\Model\Account\Photo;
use Plumrocket\SocialLoginPro\Model\Config\Provider as ConfigProvider;
use Plumrocket\SocialLoginPro\Observer\LoginObserver;

class UpgradeData implements UpgradeDataInterface
{
    /**
     * @var \Magento\Eav\Setup\EavSetupFactory
     */
    private $eavSetupFactory;

    /**
     * @var \Plumrocket\SocialLoginPro\Helper\ConfigFactory
     */
    private $configHelperFactory;

    /**
     * @var \Magento\Config\Model\ResourceModel\Config\Data\CollectionFactory
     */
    private $configDataCollectionFactory;

    /**
     * @var \Magento\Framework\App\Config\Storage\WriterInterface
     */
    private $configWriter;

    /**
     * UpgradeData constructor.
     *
     * @param \Magento\Eav\Setup\EavSetupFactory                                $eavSetupFactory
     * @param \Plumrocket\SocialLoginPro\Helper\ConfigFactory                   $configHelperFactory
     * @param \Magento\Config\Model\ResourceModel\Config\Data\CollectionFactory $configDataCollectionFactory
     * @param \Magento\Framework\App\State                                      $state
     * @param \Magento\Framework\App\Config\Storage\WriterInterface             $configWriter
     */
    public function __construct(
        EavSetupFactory $eavSetupFactory,
        ConfigFactory $configHelperFactory,
        CollectionFactory $configDataCollectionFactory,
        State $state,
        WriterInterface $configWriter
    ) {
        $this->eavSetupFactory = $eavSetupFactory;
        $this->configHelperFactory = $configHelperFactory;
        $this->configDataCollectionFactory = $configDataCollectionFactory;
        $this->configWriter = $configWriter;
        try {
            $state->setAreaCode('adminhtml');
        } catch (\Exception $e) {}
    }

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $connection = $setup->getConnection();
        /** @var EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        if (version_compare($context->getVersion(), '2.3.0', '<')) {
            $eavSetup->addAttribute(
                Customer::ENTITY,
                LoginObserver::CUSTOMER_POPUP_DATE_ATTRIBUTE_CODE,
                [
                    'input'         => 'hidden',
                    'type'          => 'datetime',
                    'visible'       => 0,
                    'required'      => 0,
                    'user_defined'  => 0,
                ]
            );
        }

        if (version_compare($context->getVersion(), '2.6.0', '<')) {
            $this->configHelperFactory->create()->copyConfig();
        }

        if (version_compare($context->getVersion(), '2.7.0', '<')) {
            $tableName = $setup->getTable('plumrocket_sociallogin_account');

            $connection->update(
                $tableName,
                [
                    'type' => 'google',
                ],
                "`type` = 'googleplus'"
            );

            /** @var \Magento\Config\Model\ResourceModel\Config\Data\Collection $configDataCollection */
            $configDataCollection = $this->configDataCollectionFactory->create();
            $configDataCollection->addPathFilter('psloginpro/googleplus');

            /** @var \Magento\Framework\App\Config\Value $config */
            foreach ($configDataCollection as $config) {
                $newPath = str_replace(
                    'psloginpro/googleplus',
                    'psloginpro/google',
                    $config->getData('path')
                );

                $config->setData('path', $newPath);
            }

            $configDataCollection->save();
        }

        if (version_compare($context->getVersion(), '3.0.0', '<')) {
            /** @var \Magento\Config\Model\ResourceModel\Config\Data\Collection $configDataCollection */
            $configDataCollection = $this->configDataCollectionFactory->create();
            $configDataCollection->addPathFilter('psloginpro/general');

            $ignorePaths = [
                'psloginpro/general/version',
                'psloginpro/general/enable',
                'psloginpro/general/serial',
            ];

            /** @var \Magento\Framework\App\Config\Value $config */
            foreach ($configDataCollection as $config) {
                if (in_array($config->getData('path'), $ignorePaths, true)) {
                    continue;
                }

                if ($config->getData('path') === 'psloginpro/general/validate_ignore') {
                    $config->setData('path', ConfigProvider::XML_PATH_REGISTER_REQUIRE_LEVEL);
                    continue;
                }

                $newPath = str_replace(
                    'psloginpro/general',
                    'psloginpro/main',
                    $config->getData('path')
                );

                $config->setData('path', $newPath);
            }

            $configDataCollection->save();
        }

        /**
         * Version 3.4.0
         */
        if (version_compare($context->getVersion(), '3.4.0', '<')) {
            /** Copy previous config to the new path */
            $configurations = [];
            $path = 'psloginpro/main/enable_for';
            $fields = [
                'login'     => 'psloginpro/main/enable_for_login',
                'register'  => 'psloginpro/main/enable_for_register'
            ];

            foreach ($fields as $page => $fieldPath) {
                $values = $this->configDataCollectionFactory->create()
                    ->addFieldToFilter('path', ['eq' => $fieldPath])
                    ->getData();

                foreach ($values as $value) {
                    $configurations[$value['scope_id']]['scope'] = $value['scope'];

                    if ($value['value'] == 1) {
                        if (isset($configurations[$value['scope_id']]['value'])) {
                            $configurations[$value['scope_id']]['value'] .= ',' . $page;
                        } else {
                            $configurations[$value['scope_id']]['value'] = $page;
                        }
                    }
                }
            }

            foreach ($configurations as $scopeId => $configuration) {
                $this->configWriter->save($path, $configuration['value'], $configuration['scope'], $scopeId);
            }

            /** Add an attribute to the customer */
            $eavSetup->addAttribute(
                Customer::ENTITY,
                Photo::CUSTOMER_PHOTO_ATTRIBUTE_CODE,
                [
                    'type'         => 'varchar',
                    'label'        => 'Customer Photo',
                    'input'        => 'text',
                    'required'     => 0,
                    'visible'      => 0,
                    'user_defined' => 0,
                    'position'     => 1000,
                    'system'       => 0,
                ]
            );

            $eavSetup->updateAttribute(
                Customer::ENTITY,
                LoginObserver::CUSTOMER_POPUP_DATE_ATTRIBUTE_CODE,
                ['is_system' => 0]
            );
        }

        $setup->endSetup();
    }
}
