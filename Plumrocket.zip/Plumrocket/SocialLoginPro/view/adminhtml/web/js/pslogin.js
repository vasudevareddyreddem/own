/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

require([
    'jquery',
    'jquery/ui',
    'mage/adminhtml/events'
], function (pjQuery_1_11_3) {
    // 'use strict';

    pjQuery_1_11_3(function () {
        if (pjQuery_1_11_3('#psloginpro_general_enable').size()) {
            // Disable empty image fields.
            if (typeof varienGlobalEvents != undefined) {
                varienGlobalEvents.attachEventHandler('formSubmit', function () {
                    pjQuery_1_11_3('[id$=icon_btn], [id$=login_btn], [id$=register_btn]').each(function () {
                        var $input = pjQuery_1_11_3(this);
                        var canDisable = true;

                        // If is new value.
                        if ($input.val()) {
                            canDisable = false;
                        }

                        // If is set value and not checked "Delete Image".
                        var isImageDelete = pjQuery_1_11_3('#'+ $input.attr('id') +'_delete');
                        if (isImageDelete.size() != false) {
                            if (isImageDelete.is(':checked')) {
                                canDisable = false;
                            } else {
                                // Remove hidden field, to avoid notice after save.
                                isImageDelete.nextAll('input[type="hidden"]').remove();
                            }
                        }

                        if (canDisable) {
                            $input.attr('disabled', 'disabled');
                        }
                    });
                });
            }
        }
        
        // Sortable.
        pjQuery_1_11_3('ul#sortable-visible, ul#sortable-hidden').sortable({
            connectWith: "ul",
            receive: function (event, ui) {
                ui.item.attr('id', ui.item.attr('id').replace(ui.sender.data('list'), pjQuery_1_11_3(this).data('list')));
            },
            update: function (event, ui) {
                var sortable = [
                    pjQuery_1_11_3('#sortable-visible').sortable('serialize'),
                    pjQuery_1_11_3('#sortable-hidden').sortable('serialize')
                ];

                pjQuery_1_11_3('#psloginpro_main_sortable').val(sortable.join('&'));
            },
            stop: function (event, ui) {
                if (this.id === 'sortable-visible' && pjQuery_1_11_3('#'+ this.id +' li').length < 1) {
                    alert('Sorry, "Visible Buttons" list can not be empty');
                    // return false;
                    pjQuery_1_11_3(this).sortable('cancel');
                }
            }
        })
        .disableSelection();

        // Sortable reminder
        pjQuery_1_11_3('ul#sortable-reminder-visible, ul#sortable-reminder-hidden').sortable({
            connectWith: "ul",
            receive: function (event, ui) {
                ui.item.attr('id', ui.item.attr('id').replace(ui.sender.data('list'), pjQuery_1_11_3(this).data('list')));
            },
            update: function (event, ui) {
                var sortable = [
                    pjQuery_1_11_3('#sortable-reminder-visible').sortable('serialize'),
                    pjQuery_1_11_3('#sortable-reminder-hidden').sortable('serialize')
                ];

                sortable = sortable.map(function (item) {
                    return item.replace(/reminder-hidden/g, 'hidden').replace(/reminder-visible/g, 'visible')
                });

                console.log(sortable);

                pjQuery_1_11_3('#psloginpro_link_reminder_sortable').val(sortable.join('&'));
            },
            stop: function (event, ui) {
                if (this.id === 'reminder-sortable-visible' && pjQuery_1_11_3('#'+ this.id +' li').length < 1) {
                    alert('Sorry, "Visible Buttons" list can not be empty');
                    // return false;
                    pjQuery_1_11_3(this).sortable('cancel');
                }
            }
        })
        .disableSelection();

        if (pjQuery_1_11_3('#psloginpro_main_sortable_drag_and_drop').css('display') != 'none') {
            if (pjQuery_1_11_3('#psloginpro_main_sortable_inherit').length) {
                pjQuery_1_11_3('#psloginpro_main_sortable_inherit').on('change', function () {
                    var $sortLists = pjQuery_1_11_3('ul#sortable-visible, ul#sortable-hidden');
                    if (pjQuery_1_11_3(this).is(':checked')) {
                        $sortLists.sortable({ disabled: true });
                    } else {
                        $sortLists.sortable({ disabled: false });
                    }
                }).change();
            }
        } else {
            pjQuery_1_11_3('#row_psloginpro_main_sortable').hide();
        }

        if (pjQuery_1_11_3('#psloginpro_general_reminder_drag_and_drop').css('display') != 'none') {
            if (pjQuery_1_11_3('#psloginpro_general_reminder_sortable_inherit').length) {
                pjQuery_1_11_3('#psloginpro_general_reminder_sortable_inherit').on('change', function () {
                    var $sortLists = pjQuery_1_11_3('ul#reminder-sortable-visible, ul#reminder-sortable-hidden');
                    if (pjQuery_1_11_3(this).is(':checked')) {
                        $sortLists.sortable({ disabled: true });
                    } else {
                        $sortLists.sortable({ disabled: false });
                    }
                }).change();
            }
        } else {
            pjQuery_1_11_3('#row_psloginpro_link_reminder_sortable').hide();
        }

        // Share Url.
        pjQuery_1_11_3('#psloginpro_share_page').find('option[value=__invitationsoff__], option[value=__none__]').prop('disabled', true);

        // Alert "Not installed".
        pjQuery_1_11_3('.psloginpro-notinstalled').parents('fieldset.config').each(function () {
            var $section = pjQuery_1_11_3('#'+ this.id +'-head').parents('div.entry-edit-head');
            $section.addClass('psloginpro-notinstalled-section');
            $section.find('a').append('<span class="psloginpro-notinstalled-title">(Not installed)</span>');
        });

        // Callback URL.
        pjQuery_1_11_3('.psloginpro-callbackurl-autofocus').on('focus click', function () {
            var $this = pjQuery_1_11_3(this);
            /*// Get provider name.
            var name = $this.parents('tr').attr('id');
            name = name.replace('row_psloginpro_', '').replace('_callbackurl', '');
            $this.val( $this.val().replace('_PROVIDER_', name) );*/

            $this.select();
        })
        .each(function (n, item) {
            var $item = pjQuery_1_11_3(item);
            if ($item.val().indexOf('http://') >= 0) {
                $item.next('p.note').find('span span').css('color', 'red');
            }
        });
    });
});