define([
    'jquery',
    'uiComponent',
    'https://accounts.google.com/gsi/client',
    'mage/cookies',
    'domReady!'
], function ($, Component) {
    'use strict';

    /**
     * @type {{urlSignUp: string, oneTapParams: {}}}
     */
    var component;

    return Component.extend({
        initialize: function () {
            this._super();
            component = this;
            this.initOneTap();
        },

        handleCredentialResponse: function (credential) {
            $.ajax({
                url: component.urlSignUp,
                type: "POST",
                data: credential,
                showLoader: true
            }).done(function (data) {
                if (/<\/?[a-z][\s\S]*>/i.test(data)) {
                    $('body').append(data);
                    return;
                }

                if (data.redirectUrl) {
                    window.location.href = data.redirectUrl;
                }
            });
        },

        initOneTap: function () {
            component.oneTapParams.callback = this.handleCredentialResponse;

            var disableAutoSelect = $.mage.cookies.get('pslogin_disable_one_tap_auto_sign_in');

            if (disableAutoSelect) {
                google.accounts.id.disableAutoSelect();
                $.mage.cookies.clear('pslogin_disable_one_tap_auto_sign_in');
            }

            google.accounts.id.initialize(component.oneTapParams);
            google.accounts.id.prompt();
        }
    });
});
