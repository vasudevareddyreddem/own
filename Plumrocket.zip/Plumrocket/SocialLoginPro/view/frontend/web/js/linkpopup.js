/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

define([
    'jquery',
    'underscore',
    'uiComponent',
    'ko',
    'mage/translate',
], function ($) {
    'use strict';

    return function (options) {
        var showPopup = $.cookieStorage.get('pslogin_show_linkpopup'),
            pageBlackList = ['pslogin/account', 'checkout'];

        if (showPopup && isAllowedPage(pageBlackList)) {
            $.cookieStorage.set('pslogin_show_linkpopup', 0);
            $.ajax({
                url: options.ajaxUrl,
                dataType: 'json'
            }).success(function (response) {
                if (!response.html) {
                    return;
                }
                var hld = $('#pslogin-linkpopup-init');
                hld.html(response.html);
                $('.prpop-close-btn').click(function () {
                    hld.hide();
                });
            });
        }

        /**
         * @param {[]} pageBlackList
         */
        function isAllowedPage(pageBlackList)
        {
            var isValid = true;
            pageBlackList.forEach(function (value) {
                if (-1 !== document.location.href.search(value)) {
                    isValid = false;
                    return false;
                }
            });

            return isValid;
        }
    };

});