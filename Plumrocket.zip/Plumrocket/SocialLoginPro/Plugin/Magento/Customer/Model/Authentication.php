<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */
namespace Plumrocket\SocialLoginPro\Plugin\Magento\Customer\Model;

use \Magento\Customer\Model\Authentication as MagentoAuthentication;

class Authentication
{
    /**
     * @var \Plumrocket\SocialLoginPro\Helper\Data
     */
    private $helper;

    /**
     * Authentication constructor.
     * @param \Plumrocket\SocialLoginPro\Helper\Data $helper
     */
    public function __construct(
        \Plumrocket\SocialLoginPro\Helper\Data $helper
    ) {
        $this->helper = $helper;
    }

    /**
     * @param \Magento\Customer\Model\Authentication $subject
     * @param callable $proceed
     * @param $customerId
     * @param $password
     * @return bool
     */
    public function aroundAuthenticate(MagentoAuthentication $subject, callable $proceed, $customerId, $password)
    {
        if ($this->helper->moduleEnabled() && $this->helper->isFakeMail()) {
            return true;
        }

        return $proceed($customerId, $password);
    }
}
