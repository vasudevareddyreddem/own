<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Plugin\AdvancedReviewAndReminder\Model\Provider;

use Plumrocket\SocialLoginPro\Api\Buttons\ProviderInterface;
use Plumrocket\SocialLoginPro\Helper\Data;

class SocialButtonsPlugin
{
    /**
     * @var \Plumrocket\SocialLoginPro\Api\Buttons\ProviderInterface
     */
    private $buttonsProvider;

    /**
     * @var \Plumrocket\SocialLoginPro\Helper\Data
     */
    private $dataHelper;

    /**
     * SocialButtonsPlugin constructor.
     *
     * @param \Plumrocket\SocialLoginPro\Api\Buttons\ProviderInterface $buttonsProvider
     * @param \Plumrocket\SocialLoginPro\Helper\Data                   $dataHelper
     */
    public function __construct(
        ProviderInterface $buttonsProvider,
        Data $dataHelper
    ) {
        $this->buttonsProvider = $buttonsProvider;
        $this->dataHelper = $dataHelper;
    }

    /**
     * @param \Plumrocket\AdvancedReviewAndReminder\Model\Provider\SocialButtons $subject
     * @param                                                                    $result
     * @return array
     */
    public function afterGetList(
        \Plumrocket\AdvancedReviewAndReminder\Model\Provider\SocialButtons $subject,
        $result
    ) {
        if ($this->dataHelper->moduleEnabled()) {
            return array_merge($result, $this->buttonsProvider->getPreparedButtons(true, false));
        }

        return $result;
    }
}
