<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Controller;

abstract class AbstractAccount extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    protected $customerSession;

    /**
     * @var \Plumrocket\SocialLoginPro\Helper\Data
     */
    protected $dataHelper;

    /**
     * @var \Magento\Store\Model\StoreManager
     */
    protected $storeManager;

    /**
     * @var \Magento\Framework\View\Layout
     */
    protected $layout;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\AccountProviderInterface
     */
    protected $accountProvider;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\Network\ApiCallParamsPersistorInterface
     */
    protected $apiCallParamsPersistor;

    /**
     * AbstractAccount constructor.
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Session\SessionManagerInterface $customerSession
     * @param \Plumrocket\SocialLoginPro\Helper\Data $dataHelper
     * @param \Magento\Store\Model\StoreManager $storeManager
     * @param \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider
     * @param \Plumrocket\SocialLoginPro\Model\Network\ApiCallParamsPersistorInterface $apiCallParamsPersistor
     * @param \Magento\Framework\View\Layout $layout
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Session\SessionManagerInterface $customerSession,
        \Plumrocket\SocialLoginPro\Helper\Data $dataHelper,
        \Magento\Store\Model\StoreManager $storeManager,
        \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider,
        \Plumrocket\SocialLoginPro\Model\Network\ApiCallParamsPersistorInterface $apiCallParamsPersistor,
        \Magento\Framework\View\Layout $layout
    ) {
        parent::__construct($context);
        $this->customerSession = $customerSession;
        $this->dataHelper = $dataHelper;
        $this->storeManager = $storeManager;
        $this->accountProvider = $accountProvider;
        $this->apiCallParamsPersistor = $apiCallParamsPersistor;
        $this->layout = $layout;
    }

    protected function _windowClose() //@codingStandardsIgnoreLine
    {
        if ($this->getRequest()->isXmlHttpRequest()) {
            $this->getResponse()
                ->setHeader('Content-type', 'application/json', true);
            $this->getResponse()->setBody(json_encode([
                'windowClose' => true
            ]));
        } else {
            $this->getResponse()->setBody($this->jsWrap('window.close();'));
        }
    }

    /**
     * @return \Magento\Customer\Model\Session
     */
    protected function getCustomerSession() //@codingStandardsIgnoreLine
    {
        return $this->customerSession;
    }

    /**
     * @return \Plumrocket\SocialLoginPro\Helper\Data
     */
    protected function getDataHelper() //@codingStandardsIgnoreLine
    {
        return $this->dataHelper;
    }

    protected function jsWrap($js) //@codingStandardsIgnoreLine
    {
        return '<html><head></head><body><script type="text/javascript">'.$js.'</script></body></html>';
    }

    /**
     * Display error in debug mode
     * @param \Plumrocket\SocialLoginPro\Model\Account $model
     * @return $this
     */
    protected function displayError($model) //@codingStandardsIgnoreLine
    {
        $errorBlock = $this->layout->getBlockSingleton(\Magento\Framework\View\Element\Template::class)
            ->setTemplate('Plumrocket_SocialLoginPro::error.phtml')
            ->setError($model->getDebugErrors())
            ->toHtml();

        $this->getResponse()->setBody($errorBlock);
        return $this;
    }
}
