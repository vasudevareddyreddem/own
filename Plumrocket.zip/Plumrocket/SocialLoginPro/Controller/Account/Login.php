<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Controller\Account;

use Magento\Customer\Model\Customer;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Form\FormKey;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Registry;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Framework\View\Layout;
use Magento\Store\Model\StoreManager;
use Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface;
use Plumrocket\SocialLoginPro\Helper\Data;
use Plumrocket\SocialLoginPro\Model\Account as SocialAccount;
use Plumrocket\SocialLoginPro\Model\AccountProviderInterface;
use Plumrocket\SocialLoginPro\Model\Config\Provider;
use Plumrocket\SocialLoginPro\Model\Config\Source\RequireLevel;
use Plumrocket\SocialLoginPro\Model\Network\ApiCallParamsPersistorInterface;
use Psr\Log\LoggerInterface;

class Login extends \Plumrocket\SocialLoginPro\Controller\AbstractAccount
{
    /**
     * @var \Magento\Customer\Model\Customer
     */
    protected $customer;

    /**
     * @var SocialAccount
     */
    protected $account;

    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    private $formKey;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $_registry;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\Config\Provider
     */
    private $configProvider;

    /**
     * @var \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface
     */
    private $customerNetworksManager;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;

    /**
     * Login constructor.
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Session\SessionManagerInterface $customerSession
     * @param \Plumrocket\SocialLoginPro\Helper\Data $dataHelper
     * @param \Magento\Store\Model\StoreManager $storeManager
     * @param \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider
     * @param \Plumrocket\SocialLoginPro\Model\Network\ApiCallParamsPersistorInterface $apiCallParamsPersistor
     * @param \Magento\Framework\View\Layout $layout
     * @param \Magento\Customer\Model\Customer $customer
     * @param SocialAccount $account
     * @param \Magento\Framework\Data\Form\FormKey $formKey
     * @param \Magento\Framework\Registry $registry
     * @param \Plumrocket\SocialLoginPro\Model\Config\Provider $configProvider
     * @param \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(
        Context $context,
        SessionManagerInterface $customerSession,
        Data $dataHelper,
        StoreManager $storeManager,
        AccountProviderInterface $accountProvider,
        ApiCallParamsPersistorInterface $apiCallParamsPersistor,
        Layout $layout,
        Customer $customer,
        SocialAccount $account,
        FormKey $formKey,
        Registry $registry,
        Provider $configProvider,
        CustomerNetworksManagerInterface $customerNetworksManager,
        LoggerInterface $logger
    ) {
        parent::__construct(
            $context,
            $customerSession,
            $dataHelper,
            $storeManager,
            $accountProvider,
            $apiCallParamsPersistor,
            $layout
        );
        $this->customer = $customer;
        $this->account = $account;
        $this->formKey = $formKey;
        $this->_registry = $registry;
        $this->accountProvider = $accountProvider;
        $this->configProvider = $configProvider;
        $this->apiCallParamsPersistor = $apiCallParamsPersistor;
        $this->customerNetworksManager = $customerNetworksManager;
        $this->logger = $logger;
    }

    public function execute()
    {
        $session = $this->getCustomerSession();
        $type = $this->getRequest()->getParam('type');
        $redirectUrl = $this->getDataHelper()->getRedirectUrl();

        // API.
        $callTarget = false;
        if ($call = $this->apiCallParamsPersistor->get()) {
            if (isset($call['type']) && $call['type'] == $type && !empty($call['action'])) {
                $_target = explode('.', $call['action'], 3);
                if (count($_target) === 3) {
                    $callTarget = $_target;
                } else {
                    $this->_windowClose();
                    return;
                }
            }
        }

        if (! $callTarget && $session->isLoggedIn()) {
            $this->_windowClose();
            return;
        }

        try {
            $model = $this->accountProvider->getByType($type);
        } catch (LocalizedException $localizedException) {
            $this->_windowClose();
            return;
        }

        $responseTypes = $model->getResponseType();

        if (is_array($responseTypes)) {
            $response = [];
            foreach ($responseTypes as $responseType) {
                $response[$responseType] = $this->getRequest()->getParam($responseType);
            }
        } else {
            $response = $this->getRequest()->getParam($responseTypes);
        }
        $model->_setLog($this->getRequest()->getParams());

        if (! $model->loadUserData($response)) {
            if ($this->_registry->registry('close_popup')) {
                $this->_windowClose();
                return;
            }
            if ($this->getDataHelper()->getDebugMode()) {
                $model->recordLog();
                $this->displayError($model);
                return;
            }

            $this->getResponse()->setBody(
                __(
                    'The Login Application was not configured correctly. If your are the admin of store: ' .
                    'Please activate “Enable Logging” in Magento Login Extension and try again to see error details.'
                )
            );
            return;
        }

        // Switch store.
        if ($storeId = $this->getDataHelper()->refererStore()) {
            $this->storeManager->setCurrentStore($storeId);
        }

        // API.
        if ($callTarget) {
            list($module, $controller, $action) = $callTarget;
            $this->_forward($action, $controller, $module, ['pslogin' => $model->getUserData()]);
            return;
        }

        if ($customerId = $model->getCustomerIdByUserId()) {
            # Social Network Already Linked
            if ($responseEmail = $model->getUserData('email')) {
                $customer = $this->customer->load($customerId);
                if ($customer->getId() && $this->getDataHelper()->isFakeMail($customer->getEmail())) {
                    if ($responseEmail != $customer->getEmail()) {
                        $otherCustomer = $this->customer
                            ->getCollection()
                            ->addFieldToFilter('email', $responseEmail)
                            ->setPageSize(1)
                            ->getFirstItem();

                        if (!$otherCustomer->getId()) {
                            $customer->setEmail($responseEmail)->save();
                        }
                    }
                }
            }

            if ($model->getUserData('photo')) {
                $model->loadAndSaveCustomerPhotoFromNetwork((int) $customerId, $model->getUserData('photo'));
            }
            # Do auth.
            $redirectUrl = $this->getDataHelper()->getRedirectUrl();
        } elseif ($customerId = $model->getCustomerIdByEmail()) {
            # Customer with received email was placed in db.

            $session->unsPsloginLog();

            if ($this->configProvider->needConfirmWithMatchingEmail()) {
                $this->saveDataForRegistration($type, $model->getUserData())
                     ->sendResponseForShowPopup($model, 2);
                return;
            }

            try {
                $this->customerNetworksManager->linkNetworkToCustomer(
                    $model->getProvider(),
                    $model->getUserData('user_id'),
                    $customerId,
                    $model->getUserData('photo')
                );

                if (! $this->configProvider->isPreventDuplicateEnabled()) {
                    $redirectUrl = $this->getDataHelper()->getRedirectUrl();
                }

            } catch (LocalizedException $exception) {
                $this->logger->critical($exception);
                $this->messageManager->addErrorMessage(
                    __('Sorry, but something went wrong while connecting social account.')
                );
            }
        } else {
            # Registration customer.

            /** To popup step 1 - "Email Missing Popup" */
            if ((RequireLevel::ONLY_EMAIL === $this->configProvider->getRequireLevel() || RequireLevel::ALL === $this->configProvider->getRequireLevel())
                && ! $model->getUserData('email')
            ) {
                $session->unsPsloginLog();
                $this->saveDataForRegistration($type, $model->getUserData())
                     ->sendResponseForShowPopup($model);
                return;
            }

            /** To popup step 4 - "Do you have an account?" popup */
            if ($this->configProvider->isPreventDuplicateEnabled()
                && SocialAccount::CUSTOMER_ACTION_LOGIN === $this->apiCallParamsPersistor->get('customer_action')
                && $model->getUserData('email')
            ) {
                $session->unsPsloginLog();
                $this->saveDataForRegistration($type, $model->getUserData())
                     ->sendResponseForShowPopup($model, 4);
                return;
            }

            if ($customerId = $model->registrationCustomer()) {
                # Success.
                // Display system messages (before setCustomerIdByUserId(), because reset messages).

                $this->messageManager->addSuccessMessage(__('Customer registration successful.'));

                if ($errors = $model->getErrors()) {
                    foreach ($errors as $error) {
                        $this->messageManager->addNoticeMessage($error);
                    }
                }

                // Dispatch event.
                $this->_eventManager->dispatch(
                    'customer_register_success',
                    ['account_controller' => $this, 'customer' => $model->getCustomer()]
                );

                $this->customerNetworksManager->linkNetworkToCustomer(
                    $model->getProvider(),
                    $model->getUserData('user_id'),
                    $customerId,
                    $model->getUserData('photo')
                );

                // Post mail.
                $model->postToMail();

                // Show share-popup.
                $this->getDataHelper()->showSharePopup();

                $redirectUrl = $this->getDataHelper()->getRedirectUrl('register');
            } else {
                # Error.
                $userData = $model->getUserData();
                $session->setCustomerFormData($userData);
                $session->setPsloginFields($userData);
                $redirectUrl = $this->_url->getUrl('customer/account/create', ['_secure' => true]);

                if ($errors = $model->getErrors()) {
                    foreach ($errors as $error) {
                        $this->messageManager->addError($error);
                    }
                }

                // Remember current provider data.
                $session->setData('pslogin', [
                    'provider'  => $model->getProvider(),
                    'user_id'   => $model->getUserData('user_id'),
                    'photo'     => $model->getUserData('photo'),
                    'timeout'   => time() + Data::TIME_TO_EDIT,
                ]);
            }
        }

        if ($customerId) {
            // Log in.
            if ($session->loginById($customerId)) {
                $session->regenerateId();

                $customerSocialAccount = $this->account->load($customerId, 'customer_id');
                $customerSocialAccount->setCountEntry(new \Zend_Db_Expr('count_entry + 1'))
                      ->setLastEnterAt($this->getDataHelper()->getDateTime())
                      ->save();

                if (strpos($redirectUrl, 'form_key') !== false) {
                    $replace = 'form_key/' . $this->formKey->getFormKey() . '/';
                    $redirectUrl = preg_replace('/form_key\/.*?\//', $replace, $redirectUrl);
                }
            }

            // Unset referer link.
            $this->getDataHelper()->refererLink(null);

            // Remember provider type (for persona).
            $session->setLoginProvider($model->getProvider());
        }

        if ($this->getRequest()->isXmlHttpRequest()) {
            $this->getResponse()->setHeader('Content-type', 'application/json', true);
            $this->getResponse()->setBody(json_encode([
                'redirectUrl' => $redirectUrl
            ]));
        } else {
            $jsAction = '
                var pslDocument = window.opener ? window.opener.document : document;
                pslDocument.getElementById("pslogin-login-referer").value = "'.htmlspecialchars(base64_encode($redirectUrl)).'";
                pslDocument.getElementById("pslogin-login-submit").click();
            ';

            $body = $this->jsWrap('if(window.opener && window.opener.location &&  !window.opener.closed) { window.close(); }; '.$jsAction.';');
            $this->getResponse()->setBody($body);
        }
        $session->unsPsloginLog();
    }

    /**
     * @param SocialAccount $model
     * @param int           $step
     */
    private function sendResponseForShowPopup(SocialAccount $model, $step = 1)
    {
        $email = (string)$model->getUserData('email');
        $firstname = (string)$model->getUserData('firstname');
        $type = (string)$model->getProvider();

        $body = $this->jsWrap(
            'var pslDocument = window.opener ? window.opener.document : document;' .
            "pslDocument.pslogin.bindEmail.openPopup('$firstname', '$email', '$type', $step);" .
            'window.close();'
        );

        $this->getResponse()->setBody($body);
    }

    /**
     * @param string $type
     * @param array  $userData
     * @return $this
     */
    private function saveDataForRegistration($type, array $userData)
    {
        $this->getCustomerSession()->setPsloginUserData([$type, $userData]);

        return $this;
    }

    /**
     * Perform custom request validation.
     * Return null if default validation is needed.
     *
     * @param \Magento\Framework\App\RequestInterface $request
     *
     * @return bool|null
     */
    public function validateForCsrf(\Magento\Framework\App\RequestInterface $request)
    {
        return true;
    }

    /**
     * Create exception in case CSRF validation failed.
     * Return null if default exception will suffice.
     *
     * @param \Magento\Framework\App\RequestInterface $request
     *
     * @return \Magento\Framework\App\Request\InvalidRequestException|null
     */
    public function createCsrfValidationException(\Magento\Framework\App\RequestInterface $request)
    {
        return null;
    }
}
