<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Controller\Account\Google;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Plumrocket\SocialLoginPro\Model\Token\Jwt;
use Psr\Log\LoggerInterface;
use Plumrocket\SocialLoginPro\Model\Googleonetap;

class Onetap extends Action
{
    /**
     * @var Jwt
     */
    private $jwtSerializer;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * Onetap constructor.
     *
     * @param Context $context
     * @param Jwt $jwtSerializer
     * @param LoggerInterface $logger
     */
    public function __construct(
        Context $context,
        Jwt $jwtSerializer,
        LoggerInterface $logger
    ) {
        parent::__construct($context);

        $this->jwtSerializer = $jwtSerializer;
        $this->logger = $logger;
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        $request = $this->getRequest();
        $credentials = $request->getParam('credential');

        try {
            $params = $this->jwtSerializer->unserialize($credentials, '', Googleonetap::LOGIN_TYPE);
            $params['type'] = Googleonetap::LOGIN_TYPE;
        } catch (\Exception $e) {
            $this->logger->error('Google One Tap: ' . $e->getMessage());
            $this->messageManager->addErrorMessage(
                __('Sorry, but something went wrong while connecting social account.')
            );

            return $this->resultFactory->create(ResultFactory::TYPE_JSON);
        }

        /** @var \Magento\Framework\Controller\Result\Forward $result */
        $result = $this->resultFactory->create(ResultFactory::TYPE_FORWARD);

        return $result->setController('account')
            ->setParams($params)
            ->forward('login');
    }
}
