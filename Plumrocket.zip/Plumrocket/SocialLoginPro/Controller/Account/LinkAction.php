<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2017 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Controller\Account;

use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\LocalizedException;

class LinkAction extends \Plumrocket\SocialLoginPro\Controller\AbstractAccount
{
    /**
     * @var \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface
     */
    private $customerNetworksManager;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;

    /**
     * LinkAction constructor.
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Session\SessionManagerInterface $customerSession
     * @param \Plumrocket\SocialLoginPro\Helper\Data $dataHelper
     * @param \Magento\Store\Model\StoreManager $storeManager
     * @param \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider
     * @param \Plumrocket\SocialLoginPro\Model\Network\ApiCallParamsPersistorInterface $apiCallParamsPersistor
     * @param \Magento\Framework\View\Layout $layout
     * @param \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Session\SessionManagerInterface $customerSession,
        \Plumrocket\SocialLoginPro\Helper\Data $dataHelper,
        \Magento\Store\Model\StoreManager $storeManager,
        \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider,
        \Plumrocket\SocialLoginPro\Model\Network\ApiCallParamsPersistorInterface $apiCallParamsPersistor,
        \Magento\Framework\View\Layout $layout,
        \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager,
        \Psr\Log\LoggerInterface $logger
    ) {
        parent::__construct(
            $context,
            $customerSession,
            $dataHelper,
            $storeManager,
            $accountProvider,
            $apiCallParamsPersistor,
            $layout
        );
        $this->customerNetworksManager = $customerNetworksManager;
        $this->logger = $logger;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        $userData = $this->getRequest()->getParam('pslogin', []);

        $type = $this->getRequest()->getParam('type');
        $customerId = $this->getCustomerSession()->getCustomerId();
        $userId = isset($userData['user_id']) ? $userData['user_id'] : 0;
        $userPhoto = isset($userData['photo']) ? $userData['photo'] : null;

        try {
            $this->customerNetworksManager->linkNetworkToCustomer($type, $userId, $customerId, $userPhoto);
        } catch (AlreadyExistsException $alreadyExistsException) {
            $this->logger->critical($alreadyExistsException);
            $this->messageManager->addWarningMessage($alreadyExistsException->getMessage());
        } catch (LocalizedException $exception) {
            $this->logger->critical($exception);
            $this->messageManager->addErrorMessage(__('Sorry, but something went wrong.'));
        }

        $redirectUrl = $this->_url->getUrl('pslogin/account/view', []);
        $this->getResponse()->setBody(
            $this->jsWrap(
                'if(window.opener && window.opener.location &&  !window.opener.closed) { ' .
                'window.close(); window.opener.location.href = "'.$redirectUrl.'";' .
                ' }else{ window.location.href = "'.$redirectUrl.'"; }'
            )
        );
    }
}
