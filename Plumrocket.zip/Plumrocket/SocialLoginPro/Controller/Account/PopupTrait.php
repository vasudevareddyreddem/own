<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Controller\Account;

trait PopupTrait
{
    /**
     * @param string                                           $value
     * @param \Magento\Customer\Model\Session                  $session
     * @param \Plumrocket\SocialLoginPro\Helper\Data           $dataHelper
     * @return bool
     */
    protected function baseValidateRequest( //@codingStandardsIgnoreLine
        $value,
        \Magento\Customer\Model\Session $session,
        \Plumrocket\SocialLoginPro\Helper\Data $dataHelper
    ) {
        return $dataHelper->moduleEnabled()
            && $value
            && ! $session->isLoggedIn()
            && ! empty($session->getPsloginUserData());
    }

    /**
     * @param string $url
     * @param array  $params
     * @return string
     */
    protected function getUrl($url, array $params = []) //@codingStandardsIgnoreLine
    {
        return $this->_url->getUrl($url, $params);
    }

    /**
     * @param                                 $customerId
     * @param \Magento\Customer\Model\Session $session
     * @param                                 $redirectUrl
     * @return string|string[]|null
     */
    protected function afterLogin( //@codingStandardsIgnoreLine
        $customerId,
        \Magento\Customer\Model\Session $session,
        $redirectUrl
    ) {
        $session->regenerateId();

        $customerSocialAccount = $this->accountProvider->getByType('account');

        $customerSocialAccount->load($customerId, 'customer_id');

        $customerSocialAccount->setCountEntry(new \Zend_Db_Expr('count_entry + 1'))
                              ->setLastEnterAt($this->dataHelper->getDateTime())
                              ->save();

        if (strpos($redirectUrl, 'form_key') !== false) {
            $replace = 'form_key/' . $this->formKey->getFormKey() . '/';
            $redirectUrl = preg_replace('/form_key\/.*?\//', $replace, $redirectUrl);
        }

        $session->unsPsloginLog();

        return $redirectUrl;
    }
}
