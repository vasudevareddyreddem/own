<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Controller\Account;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Plumrocket\SocialLoginPro\Model\Account as SocialAccount;

class Register extends \Magento\Framework\App\Action\Action
{
    use \Plumrocket\SocialLoginPro\Controller\Account\PopupTrait;

    /**
     * @var \Magento\Customer\Api\CustomerRepositoryInterface
     */
    private $customerRepository;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\AccountProviderInterface
     */
    protected $accountProvider;

    /**
     * @var \Magento\Customer\Model\Session\Proxy
     */
    private $customerSession;

    /**
     * @var \Plumrocket\SocialLoginPro\Helper\Data
     */
    private $dataHelper;

    /**
     * @var \Magento\Store\Model\StoreManager
     */
    private $storeManager;

    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    protected $formKey;

    /**
     * @var \Magento\Framework\View\Layout
     */
    private $layout;

    /**
     * @var \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface
     */
    private $customerNetworksManager;
    /**
     * @var \Plumrocket\SocialLoginPro\Model\Config\Provider
     */
    private $configProvider;
    /**
     * @var \Plumrocket\SocialLoginPro\Model\Network\ApiCallParamsPersistorInterface
     */
    private $apiCallParamsPersistor;

    /**
     * Register constructor.
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository
     * @param \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider
     * @param \Magento\Framework\Session\SessionManagerInterface $customerSession
     * @param \Plumrocket\SocialLoginPro\Helper\Data $dataHelper
     * @param \Magento\Store\Model\StoreManager $storeManager
     * @param \Magento\Framework\Data\Form\FormKey $formKey
     * @param \Magento\Framework\View\Layout $layout
     * @param \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
        \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider,
        \Magento\Framework\Session\SessionManagerInterface $customerSession,
        \Plumrocket\SocialLoginPro\Helper\Data $dataHelper,
        \Magento\Store\Model\StoreManager $storeManager,
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Magento\Framework\View\Layout $layout,
        \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager,
        \Plumrocket\SocialLoginPro\Model\Config\Provider $configProvider,
        \Plumrocket\SocialLoginPro\Model\Network\ApiCallParamsPersistorInterface $apiCallParamsPersistor
    ) {
        parent::__construct($context);
        $this->customerRepository = $customerRepository;
        $this->accountProvider = $accountProvider;
        $this->customerSession = $customerSession;
        $this->dataHelper = $dataHelper;
        $this->storeManager = $storeManager;
        $this->formKey = $formKey;
        $this->layout = $layout;
        $this->customerNetworksManager = $customerNetworksManager;
        $this->configProvider = $configProvider;
        $this->apiCallParamsPersistor = $apiCallParamsPersistor;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Json|\Magento\Framework\Controller\ResultInterface
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\ValidatorException
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Json $jsonResult */
        $jsonResult = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_JSON);
        $responseData = [
            'status' => true,
            'data' => [],
            'error' => [],
        ];

        try {
            /** @var \Plumrocket\SocialLoginPro\Model\Account $model */
            list($userDataWithEmail, $model) = $this->parseRequireData(
                $this->getRequest(),
                $this->customerSession,
                $this->dataHelper
            );
        } catch (LocalizedException $localizedException) {
            $responseData['status'] = false;
            $responseData['error'] = $localizedException->getMessage();
            return $jsonResult->setData($responseData);
        }

        if ($customerId = $this->getCustomerIdWithSameEmail($userDataWithEmail['email'])) {
            $this->customerSession->setPsloginUserData([$model->getProvider(), $userDataWithEmail]);
            $this->customerSession->setForgottenEmail($userDataWithEmail['email']);
            $responseData['data']['exist'] = true;
            $responseData['data']['linked_networks'] = $this->getLinkedNetworksHtml($customerId);
            return $jsonResult->setData($responseData);
        }

        if ($this->configProvider->isPreventDuplicateEnabled()
            && SocialAccount::CUSTOMER_ACTION_LOGIN === $this->apiCallParamsPersistor->get('customer_action')
            && $model->getUserData('email')
            && $this->getRequest()->getParam('step', '') != 4
        ) {
            $responseData['data']['exist'] = false;
            $responseData['data']['step'] = 4;
            return $jsonResult->setData($responseData);
        }

        $this->switchStore();

        if ($model->getCustomerIdByUserId()) {
            $responseData['error'] = __('Social Network already linked');
            return $jsonResult->setData($responseData);
        }

        $customerId = $model->registrationCustomer();

        if ($customerId) {
            $responseData['status'] = true;

            $responseData['data']['message'] = __('Customer registration successful.');

            foreach ($model->getErrors() as $error) {
                $this->messageManager->addNoticeMessage($error);
            }

            $this->_eventManager->dispatch(
                'customer_register_success',
                ['account_controller' => $this, 'customer' => $model->getCustomer()]
            );

            $this->customerNetworksManager->linkNetworkToCustomer(
                $model->getProvider(),
                $model->getUserData('user_id'),
                $customerId,
                $model->getUserData('photo')
            );

            $model->postToMail();

            $redirectUrl = $this->dataHelper->getRedirectUrl('register');
            if ($this->customerSession->loginById($customerId)) {
                $redirectUrl = $this->afterLogin($customerId, $this->customerSession, $redirectUrl);
            }

            $this->dataHelper->refererLink(null);

            // Remember provider type (for persona).
            $this->customerSession->setLoginProvider($model->getProvider());
        } else {
            $responseData['status'] = false;

            $userDataWithEmail = $model->getUserData();
            $this->customerSession->setCustomerFormData($userDataWithEmail);
            $this->customerSession->setPsloginFields($userDataWithEmail);
            $redirectUrl = $this->getUrl('customer/account/create', ['_secure' => true]);

            foreach ($model->getErrors() as $error) {
                $this->messageManager->addErrorMessage($error);
                $responseData['error'][] = (string)$error;
            }

            // Remember current provider data.
            $this->customerSession->setData(
                'pslogin',
                [
                    'provider' => $model->getProvider(),
                    'user_id'  => $model->getUserData('user_id'),
                    'photo'    => $model->getUserData('photo'),
                    'timeout'  => time() + \Plumrocket\SocialLoginPro\Helper\Data::TIME_TO_EDIT,
                ]
            );
        }

        $this->customerSession->unsPsloginLog();

        $responseData['data']['redirectUrl'] = $redirectUrl;
        $responseData['error'] = implode(',', $responseData['error']);

        return $jsonResult->setData($responseData);
    }

    /**
     * @param $email
     * @return int
     */
    private function getCustomerIdWithSameEmail($email)
    {
        try {
            return $this->customerRepository->get($email)->getId();
        } catch (NoSuchEntityException $noSuchEntityException) {
            return 0;
        }
    }

    /**
     * @return $this
     */
    private function switchStore()
    {
        if ($storeId = $this->dataHelper->refererStore()) {
            $this->storeManager->setCurrentStore($storeId);
        }

        return $this;
    }

    /**
     * @param \Magento\Framework\App\RequestInterface $request
     * @param \Magento\Customer\Model\Session         $customerSession
     * @param \Plumrocket\SocialLoginPro\Helper\Data  $dataHelper
     * @return array
     * @throws LocalizedException
     */
    private function parseRequireData(
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Customer\Model\Session $customerSession,
        \Plumrocket\SocialLoginPro\Helper\Data $dataHelper
    ) {
        $email = $request->getParam('email', '');
        list($type, $userData) = $customerSession->getPsloginUserData();
        $userData['email'] = $email;
        $userDataWithEmail = $userData;

        if (! $this->baseValidateRequest($email, $customerSession, $dataHelper)
            || ! \Zend_Validate::is($email, 'EmailAddress')
        ) {
            throw new LocalizedException(__('Bad request.'));
        }

        try {
            $model = $this->accountProvider->getByType($type);
            $model->setUserData($userDataWithEmail);
        } catch (\Magento\Framework\Exception\LocalizedException $localizedException) {
            throw new LocalizedException(__('Social Network not specified.'));
        }

        return [$userDataWithEmail, $model];
    }

    /**
     * @param $customerId
     * @return string
     */
    private function getLinkedNetworksHtml($customerId)
    {
        $types = $this->customerNetworksManager->getLinkedTypesByCustomerId($customerId);

        if (! empty($types)) {
            /** @var \Plumrocket\SocialLoginPro\Block\Popup\Login $block */
            $block = $this->layout->createBlock(\Plumrocket\SocialLoginPro\Block\Popup\Login::class)
                         ->setTemplate('Plumrocket_SocialLoginPro::popup/linked_buttons.phtml');

            return $block->setLinkedNetworkTypes($types)->toHtml();
        }

        return '';
    }
}
