<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2017 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Controller\Account;

use Magento\Framework\Controller\ResultFactory;

class UnlinkAction extends \Plumrocket\SocialLoginPro\Controller\AbstractAccount
{
    /**
     * @var \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface
     */
    private $customerNetworksManager;

    /**
     * UnlinkAction constructor.
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Session\SessionManagerInterface $customerSession
     * @param \Plumrocket\SocialLoginPro\Helper\Data $dataHelper
     * @param \Magento\Store\Model\StoreManager $storeManager
     * @param \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider
     * @param \Plumrocket\SocialLoginPro\Model\Network\ApiCallParamsPersistorInterface $apiCallParamsPersistor
     * @param \Magento\Framework\View\Layout $layout
     * @param \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Session\SessionManagerInterface $customerSession,
        \Plumrocket\SocialLoginPro\Helper\Data $dataHelper,
        \Magento\Store\Model\StoreManager $storeManager,
        \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider,
        \Plumrocket\SocialLoginPro\Model\Network\ApiCallParamsPersistorInterface $apiCallParamsPersistor,
        \Magento\Framework\View\Layout $layout,
        \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager
    ) {
        parent::__construct(
            $context,
            $customerSession,
            $dataHelper,
            $storeManager,
            $accountProvider,
            $apiCallParamsPersistor,
            $layout
        );
        $this->customerNetworksManager = $customerNetworksManager;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $customerId = $this->getCustomerSession()->getCustomerId();
        $networkAccountId = (int)$this->getRequest()->getParam('id', 0);

        if ($customerId && $networkAccountId) {
            $result = $this->customerNetworksManager->unlinkNetworkFromCustomer($customerId, $networkAccountId);

            if ($result) {
                $this->messageManager->addSuccessMessage(__('You was successfully unlinked'));
            } else {
                $this->messageManager->addErrorMessage(__('Something went wrong while unlinking network account'));
            }
        } else {
            $this->messageManager->addErrorMessage(__('Missed required parameters'));
        }

        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
    }
}
