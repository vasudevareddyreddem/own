<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Controller\Account\Login;

use Magento\Framework\Exception\LocalizedException;

class Network extends \Plumrocket\SocialLoginPro\Controller\AbstractAccount
{
    use \Plumrocket\SocialLoginPro\Controller\Account\PopupTrait;

    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    protected $formKey;

    /**
     * @var \Magento\Framework\Stdlib\Cookie\PhpCookieManager
     */
    private $cookieManager;

    /**
     * @var \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory
     */
    private $cookieMetadataFactory;

    /**
     * @var \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface
     */
    private $customerNetworksManager;

    /**
     * @var \Magento\Customer\Api\CustomerRepositoryInterface
     */
    private $customerRepository;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;

    /**
     * Network constructor.
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Session\SessionManagerInterface $customerSession
     * @param \Plumrocket\SocialLoginPro\Helper\Data $dataHelper
     * @param \Magento\Store\Model\StoreManager $storeManager
     * @param \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider
     * @param \Plumrocket\SocialLoginPro\Model\Network\ApiCallParamsPersistorInterface $apiCallParamsPersistor
     * @param \Magento\Framework\View\Layout $layout
     * @param \Magento\Framework\Data\Form\FormKey $formKey
     * @param \Magento\Framework\Stdlib\Cookie\PhpCookieManager $cookieManager
     * @param \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory
     * @param \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager
     * @param \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Session\SessionManagerInterface $customerSession,
        \Plumrocket\SocialLoginPro\Helper\Data $dataHelper,
        \Magento\Store\Model\StoreManager $storeManager,
        \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider,
        \Plumrocket\SocialLoginPro\Model\Network\ApiCallParamsPersistorInterface $apiCallParamsPersistor,
        \Magento\Framework\View\Layout $layout,
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Magento\Framework\Stdlib\Cookie\PhpCookieManager $cookieManager,
        \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory,
        \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
        \Psr\Log\LoggerInterface $logger
    ) {
        parent::__construct(
            $context,
            $customerSession,
            $dataHelper,
            $storeManager,
            $accountProvider,
            $apiCallParamsPersistor,
            $layout
        );
        $this->accountProvider = $accountProvider;
        $this->formKey = $formKey;
        $this->cookieManager = $cookieManager;
        $this->cookieMetadataFactory = $cookieMetadataFactory;
        $this->customerNetworksManager = $customerNetworksManager;
        $this->customerRepository = $customerRepository;
        $this->logger = $logger;
    }

    public function execute()
    {
        $userData = $this->getRequest()->getParam('pslogin', []);

        $type = $this->getRequest()->getParam('type');

        try {
            $modelForLogin = $this->accountProvider->createByType($type);
        } catch (LocalizedException $localizedException) {
            $this->_windowClose();
            return;
        }

        $modelForLogin->setUserData($userData);

        try {
            /** @var \Plumrocket\SocialLoginPro\Model\Account $model */
            list($LinkNetworkModel, $LinkNetworkType, $LinkNetworkUserId) = $this->parseRequireData(
                $this->getCustomerSession(),
                $this->accountProvider,
                $this->getDataHelper()
            );
        } catch (LocalizedException $localizedException) {
            $this->_windowClose();
            return;
        }

        if ($customerId = $modelForLogin->getCustomerIdByUserId()) {
            try {
                $this->customerNetworksManager->linkNetworkToCustomer(
                    $LinkNetworkType,
                    $LinkNetworkUserId,
                    $customerId,
                    $modelForLogin->getUserData('photo')
                );
            } catch (LocalizedException $exception) {
                $this->apiCallParamsPersistor->clear();
                $this->logger->critical($exception);
                $error = __('Sorry, but something went wrong while connecting social account.');
            }
        } else {
            $this->apiCallParamsPersistor->clear();
            $error = __('This social account didn\'t link to store account');
        }

        if (isset($error)) {
            $body = $this->jsWrap(
                'var pslDocument = window.opener ? window.opener.document : document;' .
                "pslDocument.pslogin.bindEmail.renderError(\"$error\");" .
                'window.close();'
            );

            $this->getResponse()->setBody($body);
            return;
        }

        $customer = $this->customerRepository->getById($customerId);

        $this->getCustomerSession()->setCustomerDataAsLoggedIn($customer);

        if ($this->getDataHelper()->photoEnabled()) {
            $LinkNetworkModel->setCustomerPhoto($customer->getId());
        }

        $redirectUrl = $this->afterLogin(
            $customer->getId(),
            $this->getCustomerSession(),
            $this->getDataHelper()->getRedirectUrl()
        );

        $this->getCustomerSession()->setLoginProvider($modelForLogin->getProvider());

        if ($this->cookieManager->getCookie('mage-cache-sessid')) {
            $metadata = $this->cookieMetadataFactory->createCookieMetadata();
            $metadata->setPath('/');
            $this->cookieManager->deleteCookie('mage-cache-sessid', $metadata);
        }

        $body = $this->jsWrap(
            'var pslDocument = window.opener ? window.opener.document : document;' .
            "pslDocument.pslogin.bindEmail.setSuccessRedirect('$redirectUrl');" .
            "pslDocument.pslogin.bindEmail.renderError('');" .
            'pslDocument.pslogin.bindEmail.setStep(3);' .
            'window.close();'
        );

        $this->getResponse()->setBody($body);
    }

    /**
     * @param \Magento\Customer\Model\Session                   $session
     * @param \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider
     * @param \Plumrocket\SocialLoginPro\Helper\Data            $dataHelper
     * @return array
     * @throws LocalizedException
     */
    private function parseRequireData(
        \Magento\Customer\Model\Session $session,
        \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider,
        \Plumrocket\SocialLoginPro\Helper\Data $dataHelper
    ) {
        if (! $this->baseValidateRequest(true, $session, $dataHelper)) {
            throw new LocalizedException(__('Bad request.'));
        }

        list($type, $userDataWithEmail) = $session->getPsloginUserData();

        $model = $accountProvider->getByType($type);
        $model->setUserData($userDataWithEmail);

        if ($model->getCustomerIdByUserId()) {
            throw new LocalizedException(__('Social Network already linked'));
        }

        return [$model, $model->getProvider(), $model->getUserData('user_id')];
    }
}
