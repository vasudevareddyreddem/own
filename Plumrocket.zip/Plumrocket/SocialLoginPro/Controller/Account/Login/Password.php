<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Controller\Account\Login;

use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Model\Url;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Form\FormKey;
use Magento\Framework\Exception\AuthenticationException;
use Magento\Framework\Exception\EmailNotConfirmedException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\State\UserLockedException;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Framework\Stdlib\Cookie\CookieMetadataFactory;
use Magento\Framework\Stdlib\Cookie\PhpCookieManager;
use Plumrocket\SocialLoginPro\Helper\Data;
use Plumrocket\SocialLoginPro\Model\AccountProviderInterface;
use Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface;

class Password extends \Magento\Framework\App\Action\Action
{
    use \Plumrocket\SocialLoginPro\Controller\Account\PopupTrait;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\AccountProviderInterface
     */
    protected $accountProvider;

    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    private $customerSession;

    /**
     * @var \Plumrocket\SocialLoginPro\Helper\Data
     */
    private $dataHelper;

    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    protected $formKey;

    /**
     * @var \Magento\Customer\Api\AccountManagementInterface
     */
    private $customerAccountManagement;

    /**
     * @var \Magento\Framework\Stdlib\Cookie\PhpCookieManager
     */
    private $cookieManager;

    /**
     * @var \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory
     */
    private $cookieMetadataFactory;

    /**
     * @var \Magento\Customer\Model\Url
     */
    private $customerUrl;

    /**
     * @var \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface
     */
    private $customerNetworksManager;

    /**
     * Password constructor.
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider
     * @param \Magento\Framework\Session\SessionManagerInterface $customerSession
     * @param \Plumrocket\SocialLoginPro\Helper\Data $dataHelper
     * @param \Magento\Framework\Data\Form\FormKey $formKey
     * @param \Magento\Customer\Api\AccountManagementInterface $customerAccountManagement
     * @param \Magento\Framework\Stdlib\Cookie\PhpCookieManager $cookieManager
     * @param \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory
     * @param \Magento\Customer\Model\Url $customerHelperData
     * @param \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager
     */
    public function __construct(
        Context $context,
        AccountProviderInterface $accountProvider,
        SessionManagerInterface $customerSession,
        Data $dataHelper,
        FormKey $formKey,
        AccountManagementInterface $customerAccountManagement,
        PhpCookieManager $cookieManager,
        CookieMetadataFactory $cookieMetadataFactory,
        Url $customerHelperData,
        CustomerNetworksManagerInterface $customerNetworksManager
    ) {
        parent::__construct($context);
        $this->accountProvider = $accountProvider;
        $this->customerSession = $customerSession;
        $this->dataHelper = $dataHelper;
        $this->formKey = $formKey;
        $this->customerAccountManagement = $customerAccountManagement;
        $this->cookieManager = $cookieManager;
        $this->cookieMetadataFactory = $cookieMetadataFactory;
        $this->customerUrl = $customerHelperData;
        $this->customerNetworksManager = $customerNetworksManager;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Json|\Magento\Framework\Controller\ResultInterface
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     * @throws \Magento\Framework\Exception\InputException
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\ValidatorException
     * @throws \Magento\Framework\Stdlib\Cookie\FailureToSendException
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Json $jsonResult */
        $jsonResult = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_JSON);
        $responseData = [
            'status' => true,
            'data' => [],
            'error' => [],
        ];

        try {
            /** @var \Plumrocket\SocialLoginPro\Model\Account $model */
            list($email, $model, $userDataWithEmail, $password) = $this->parseRequireData(
                $this->getRequest(),
                $this->customerSession,
                $this->accountProvider,
                $this->dataHelper
            );
        } catch (LocalizedException $localizedException) {
            $responseData['status'] = false;
            $responseData['error'] = $localizedException->getMessage();
            return $jsonResult->setData($responseData);
        }

        try {
            $customer = $this->customerAccountManagement->authenticate(
                $email ?: $userDataWithEmail['email'],
                $password
            );
        } catch (EmailNotConfirmedException $e) {
            $value = $this->customerUrl->getEmailConfirmationUrl($userDataWithEmail['email']);
            $message = __(
                'This account is not confirmed. <a href="%1">Click here</a> to resend confirmation email.',
                $value
            );
        } catch (UserLockedException $e) {
            $message = __(
                'The account sign-in was incorrect or your account is disabled temporarily. '
                . 'Please wait and try again later.'
            );
        } catch (AuthenticationException $e) {
            $message = __(
                'The account sign-in was incorrect or your account is disabled temporarily. '
                . 'Please wait and try again later.'
            );
        } catch (LocalizedException $e) {
            $message = $e->getMessage();
        } catch (\Exception $e) {
            // PA DSS violation: throwing or logging an exception here can disclose customer password
            $this->messageManager->addError(
                __('An unspecified error occurred. Please contact us for assistance.')
            );
        } finally {
            if (isset($message)) {
                $responseData['status'] = false;
                $responseData['error'] = $message;
                return $jsonResult->setData($responseData);
            }
        }

        $this->customerSession->setCustomerDataAsLoggedIn($customer);

        $customerId = $customer->getId();
        $this->customerNetworksManager->linkNetworkToCustomer(
            $model->getProvider(),
            $model->getUserData('user_id'),
            $customerId,
            $model->getUserData('photo')
        );

        $redirectUrl = $this->afterLogin(
            $customerId,
            $this->customerSession,
            $this->dataHelper->getRedirectUrl()
        );

        $this->customerSession->setLoginProvider($model->getProvider());

        if ($this->cookieManager->getCookie('mage-cache-sessid')) {
            $metadata = $this->cookieMetadataFactory->createCookieMetadata();
            $metadata->setPath('/');
            $this->cookieManager->deleteCookie('mage-cache-sessid', $metadata);
        }

        $responseData['data']['redirectUrl'] = $redirectUrl;
        $responseData['error'] = implode(',', $responseData['error']);

        return $jsonResult->setData($responseData);
    }

    /**
     * @param \Magento\Framework\App\RequestInterface           $request
     * @param \Magento\Customer\Model\Session                   $session
     * @param \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider
     * @param \Plumrocket\SocialLoginPro\Helper\Data            $dataHelper
     * @return array
     * @throws LocalizedException
     */
    private function parseRequireData(
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Customer\Model\Session $session,
        AccountProviderInterface $accountProvider,
        Data $dataHelper
    ) {
        $password = $request->getPost('password');

        if (! $this->baseValidateRequest($password, $session, $dataHelper)) {
            throw new LocalizedException(__('Bad request.'));
        }

        list($type, $userDataWithEmail) = $session->getPsloginUserData();

        if ($type !== $request->getPost('type')) {
            $responseData['status'] = false;
            throw new LocalizedException(__('Bad request. There\'s no information for social network: "%1"', $type));
        }

        $model = $accountProvider->getByType($type);
        $model->setUserData($userDataWithEmail);

        if ($model->getCustomerIdByUserId()) {
            throw new LocalizedException(__('Social Network already linked'));
        }

        if (($email = $request->getPost('email')) && ! \Zend_Validate::is($email, 'EmailAddress')) {
            throw new LocalizedException(__('Invalid email'));
        }

        return [$email, $model, $userDataWithEmail, $password];
    }
}
