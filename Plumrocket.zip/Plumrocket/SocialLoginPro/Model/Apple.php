<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model;

/**
 * Documentation
 * https://developer.okta.com/blog/2019/06/04/what-the-heck-is-sign-in-with-apple
 */
class Apple extends Account
{
    protected $type = 'apple';

    protected $url = 'https://appleid.apple.com/auth/authorize';

    protected $fields = [
        'user_id'   => 'sub',
        'email'     => 'email',
        'firstname' => null,
        'lastname'  => null
    ];

    protected $popupSize = [650, 350];

    public function _construct()
    {
        parent::_construct();

        $this->buttonLinkParams = [
            'client_id'     => $this->applicationId,
            'redirect_uri'  => $this->redirectUri,
            'response_type' => $this->responseType,
            'response_mode' => 'form_post',
            'scope'         => urlencode('name email')
        ];
    }

    public function loadUserData($response)
    {
        if (empty($response)) {
            $responseParams = $this->request->getParams();
            if (!$response || (isset($responseParams['error']) && $responseParams['error'] === 'access_denied')) {
                $this->_registry->register('close_popup', true);
            }

            return false;
        }

        $params = [
            'grant_type' => 'authorization_code',
            'client_id' => $this->applicationId,
            'client_secret' => $this->secret,
            'code' => $response,
            'redirect_uri' => $this->redirectUri
        ];

        $data = [];
        $token = null;
        $this->curl->post('https://appleid.apple.com/auth/token', $params);
        if ($this->curl->getStatus() === 200) {
            $response = json_decode($this->curl->getBody());
            if (isset($response->id_token)) {
                $token = explode('.', $response->id_token)[1];
                $token = base64_decode($token);
                $data = json_decode($token, true);
            }
        }

        if (!$this->userData = $this->_prepareData($data)) {
            return false;
        }

        return true;
    }

    protected function _prepareData($data)
    {
        if (empty($data['sub'])) {
            return false;
        }

        return parent::_prepareData($data);
    }
}
