<?php
/**
 * Plumrocket Inc.
 * NOTICE OF LICENSE
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Model\Account\Photo;

/**
 * @since 3.4.0
 */
class Loader
{
    /**
     * @param string $url
     * @param int    $recursionLevel
     * @return mixed|string
     */
    public function load(string $url, int $recursionLevel = 1)
    {
        if ($recursionLevel > 5) {
            return '';
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $data = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);

        if (! $data) {
            return '';
        }

        $dataArray = explode("\r\n\r\n", $data, 2);

        if (count($dataArray) !== 2) {
            return '';
        }

        list($header, $body) = $dataArray;
        if ($httpCode === 301 || $httpCode === 302) {
            $matches = [];
            preg_match('/Location:\s?(.*?)\n/im', $header, $matches);

            if (isset($matches[1])) {
                return $this->load(trim($matches[1]), ++$recursionLevel);
            }
        } else {
            return $body;
        }

        return '';
    }
}
