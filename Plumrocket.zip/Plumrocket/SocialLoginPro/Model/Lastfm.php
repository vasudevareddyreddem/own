<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2017 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model;

use Magento\Framework\Encryption\Encryptor;

class Lastfm extends Account
{
    protected $type = 'lastfm';

    protected $responseType = 'token';

    protected $url = 'http://www.last.fm/api/auth/';

    protected $fields = [
                    'user_id' => 'id',
                    'firstname' => 'realname_fn',
                    'lastname' => 'realname_ln',
                    'email' => 'email', // empty
                    'dob' => 'birthday', // empty
                    'gender' => 'gender',
                    'photo' => 'photoUrl',
                ];

    protected $gender = ['m', 'f'];

    protected $buttonLinkParams = [];

    protected $popupSize = [1020, 480];

    public function _construct()
    {
        parent::_construct();

        $this->buttonLinkParams = array_merge($this->buttonLinkParams, [
            'api_key'     => $this->applicationId,
            'cb'  => $this->redirectUri,
        ]);
    }

    public function loadUserData($response)
    {
        if (empty($response)) {
            return false;
        }

        $data = [];

        $signature = $this->encryptor->hash(
            "api_key{$this->applicationId}methodauth.getSessiontoken{$response}{$this->secret}",
            Encryptor::HASH_VERSION_MD5
        );

        $params = [
            'method' => 'auth.getSession',
            'token' => $response,
            'api_key' => $this->applicationId,
            'api_sig' => $signature,
            'format' => 'json',
        ];

        $json = null;
        if ($response = $this->_call('http://ws.audioscrobbler.com/2.0/', $params, 'POST')) {
            $json = json_decode($response, true);
        }
        $this->_setLog($json, true);

        if (!empty($json['session']['key'])) {
            $params = [
                'method' => 'user.getInfo',
                'api_key' => $this->applicationId,
                'user' => $json['session']['name'],
                'format' => 'json',
            ];

            if ($response = $this->_call('http://ws.audioscrobbler.com/2.0/', $params, 'POST')) {
                $data = json_decode($response, true);
            }

            $this->_setLog($data, true);
        }

        if (!$this->userData = $this->_prepareData($data)) {
            return false;
        }

        $this->_setLog($this->userData, true);

        return true;
    }

    protected function _prepareData($data)
    {
        if (empty($data['user']['id'])) {
            return false;
        }

        $data = $data['user'];

        // Name.
        if (!empty($data['realname'])) {
            $nameParts = explode(' ', $data['realname'], 2);
            $data['realname_fn'] = ucfirst($nameParts[0]);
            $data['realname_ln'] = !empty($nameParts[1])? ucfirst($nameParts[1]) : '';
        }

        if (!empty($data['name'])) {
            $separator = strpos($data['name'], '_') !== false? '_' : '-';
            $nameParts = explode($separator, $data['name'], 2);
            $data['name_fn'] = ucfirst($nameParts[0]);
            $data['name_ln'] = !empty($nameParts[1])? ucfirst($nameParts[1]) : '';
        }

        if (empty($data['realname_fn'])) {
            $data['realname_fn'] = $data['name_fn'];
        }
        if (empty($data['realname_ln'])) {
            $data['realname_ln'] = !empty($data['name_ln'])? $data['name_ln'] : $data['name'];
        }

        // Photo.
        $photoUrl = is_array($data['image'])? array_pop($data['image']) : $data['image'];
        if (!empty($photoUrl)) {
            $data['photoUrl'] = $photoUrl;
        }

        return parent::_prepareData($data);
    }
}
