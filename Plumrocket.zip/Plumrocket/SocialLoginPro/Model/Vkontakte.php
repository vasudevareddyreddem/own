<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2017 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model;

class Vkontakte extends Account
{
    protected $type = 'vkontakte';

    protected $url = 'http://oauth.vk.com/authorize';

    protected $fields = [
                    'user_id' => 'id',
                    'firstname' => 'first_name',
                    'lastname' => 'last_name',
                    'email' => 'email',
                    'dob' => 'bdate',
                    'gender' => 'sex',
                    'photo' => 'photo_rec',
                ];

    protected $dob = ['day', 'month', 'year', '.'];
    protected $gender = ['2', '1'];

    protected $buttonLinkParams = [
                    'scope' => 'email,wall',
                    'display' => 'popup',
                    'v' => '5.24',
                ];

    protected $popupSize = [605, 425];

    public function _construct()
    {
        parent::_construct();

        $this->buttonLinkParams = array_merge($this->buttonLinkParams, [
            'client_id'     => $this->applicationId,
            'redirect_uri'  => $this->redirectUri,
            'response_type' => $this->responseType
        ]);
    }

    public function loadUserData($response)
    {
        if (empty($response)) {
            return false;
        }

        $data = [];

        $params = [
            'client_id' => $this->applicationId,
            'client_secret' => $this->secret,
            'code' => $response,
            'redirect_uri' => $this->redirectUri
        ];

        $token = null;
        if ($response = $this->_call('https://oauth.vk.com/access_token', $params)) {
            $token = json_decode($response, true);
        }
        $this->_setLog($token, true);

        if (isset($token['access_token'])) {
            $params = [
                'uids' => $token['user_id'],
                'fields' => implode(',', $this->fields),
                'access_token' => $token['access_token'],
                'v' => '5.62'
            ];

            if ($response = $this->_call('https://api.vk.com/method/users.get', $params)) {
                $data = json_decode($response, true);
            }

            if (isset($data['response'][0]) && !empty($token['email'])) {
                $data['response'][0]['email'] = $token['email'];
            }

            $this->_setLog($data, true);
        }

        if (!$this->userData = $this->_prepareData($data)) {
            return false;
        }

        $this->_setLog($this->userData, true);

        return true;
    }

    protected function _prepareData($data)
    {
        if (empty($data['response'][0]['id'])) {
            return false;
        }
        $data = $data['response'][0];

        return parent::_prepareData($data);
    }

    /**
     * {@inheritdoc}
     */
    public function getSocialUrl()
    {
        if ($id = $this->getUserId()) {
            return 'https://vk.com/id' . $id;
        }
        return null;
    }
}
