<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2017 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model;

class Boxcom extends Account
{
    protected $type = 'boxcom';

    protected $responseType = 'code';
    protected $url = 'https://app.box.com/api/oauth2/authorize';

    protected $fields = [
                    'user_id' => 'id',
                    'firstname' => 'name_fn',
                    'lastname' => 'name_ln',
                    'email' => 'login',
                    'dob' => 'birthday', // empty
                    'gender' => 'gender', // empty
                    'photo' => 'avatar_url',
                ];

    protected $gender = ['male', 'female'];

    protected $buttonLinkParams = [
                    'scope' => '',
                ];

    protected $popupSize = [450, 550];

    public function _construct()
    {
        parent::_construct();

        $this->buttonLinkParams = array_merge($this->buttonLinkParams, [
            'client_id'     => $this->applicationId,
            'redirect_uri'  => $this->redirectUri,
            'response_type' => $this->responseType
        ]);
    }

    public function loadUserData($response)
    {
        if (empty($response)) {
            return false;
        }

        $data = [];

        $params = [
            'client_id' => $this->applicationId,
            'client_secret' => $this->secret,
            'code' => $response,
            'redirect_uri' => $this->redirectUri,
            'grant_type' => 'authorization_code',
        ];

        $token = null;
        if ($response = $this->_callPost('https://api.box.com/oauth2/token', $params)) {
            $token = json_decode($response, true);
        }
        $this->_setLog($token, true);

        if (isset($token['access_token'])) {
            $params = [
                'access_token' => $token['access_token']
            ];

            if ($response = $this->_call('https://api.box.com/2.0/users/me', $params)) {
                $data = json_decode($response, true);
            }
            $this->_setLog($data, true);
        }

        if (!$this->userData = $this->_prepareData($data)) {
            return false;
        }

        $this->_setLog($this->userData, true);

        return true;
    }

    protected function _prepareData($data)
    {
        if (empty($data['id'])) {
            return false;
        }

        // Name.
        if (!empty($data['name'])) {
            $nameParts = explode(' ', $data['name'], 2);
            $data['name_fn'] = $nameParts[0];
            $data['name_ln'] = !empty($nameParts[1])? $nameParts[1] : '';
        }

        return parent::_prepareData($data);
    }

    protected function _callPost($url, $params = [])
    {
        $this->_setLog($url, true, true);
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, 1);
        // curl_setopt($curl, CURLOPT_USERPWD, $this->applicationId .':'. $this->secret);//!! з цим заголовком видає помилку "Can't use "Authorization" header and "client_secret" arg together."
        curl_setopt($curl, CURLOPT_POSTFIELDS, urldecode(http_build_query($params)));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($curl);

        if ($errno = curl_errno($curl)) {
            $this->_setLog(curl_getinfo($curl), true, true);
            $this->_setLog(curl_error($curl), true, true);
        }

        curl_close($curl);

        return $result;
    }
}
