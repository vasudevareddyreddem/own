<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

// @codingStandardsIgnoreFile

namespace Plumrocket\SocialLoginPro\Model;

use Magento\Customer\Model\Attribute;
use Magento\Customer\Model\Customer;
use Magento\Eav\Model\Config;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\Encryption\Encryptor;
use Magento\Framework\Filesystem;
use Magento\Framework\Filesystem\Io\File;
use Magento\Framework\ImageFactory;
use Magento\Framework\Math\Random;
use Magento\Framework\Model\Context;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Registry;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Framework\Validation\ValidationException;
use Magento\Newsletter\Model\SubscriberFactory;
use Magento\Store\Model\Store;
use Magento\Store\Model\StoreManager;
use Plumrocket\SocialLoginPro\Helper\Data as DataHelper;
use Plumrocket\SocialLoginPro\Lib\Http\Client\Curl as PlumCurl;
use Plumrocket\SocialLoginPro\Model\Account\Data\PasswordGenerator;
use Plumrocket\SocialLoginPro\Model\Account\Data\Prepare;
use Plumrocket\SocialLoginPro\Model\Account\Photo;
use Plumrocket\SocialLoginPro\Model\Config\Provider;

/**
 * Class Account
 *
 * @method string       getType()
 * @method string       getUserId()
 * @method string|array getAdditional()
 * @method int|null     getCustomerId()
 *
 * @method $this        setType($type)
 * @method $this        setUserId($userId)
 * @method $this        setAdditional(array $additional)
 * @method $this        setCustomer($customer)
 * @method $this        setErrors($errors)
 */
class Account extends \Magento\Framework\Model\AbstractModel
{
    /**
     * @deprecated since 3.4.0
     */
    const PHOTO_FILE_EXT = 'png';
    const LOG_FILE = 'pslogin.log';
    const GENDER_NOT_SPECIFIED = 3;

    const CUSTOMER_ACTION_LOGIN = 'login';
    const CUSTOMER_ACTION_REGISTER = 'register';
    const CUSTOMER_ACTION_LINK = 'link';

    /**
     * @var null | string
     */
    protected $type = null;

    /**
     * @var string
     */
    protected $protocol = 'OAuth';

    /**
     * @var null | int
     */
    protected $websiteId = null;

    /**
     * @var null | string
     */
    protected $redirectUri = null;

    /**
     * @var array
     */
    protected $userData = [];

    /**
     * @var int
     */
    protected $passwordLength = null;

    /**
     * @var null | string
     */
    protected $photoDir = null;

    /**
     * @var int
     */
    protected $photoSize = 150;

    /**
     * @var null | string | int
     */
    protected $applicationId = null;

    /**
     * @var null | string | int
     */
    protected $secret = null;

    /**
     * @var string
     */
    protected $responseType = 'code';

    /**
     * @var array
     */
    protected $dob = [];

    /**
     * @var null | array | string
     */
    protected $callInfo = null;

    /**
     * @var string[]
     */
    protected $gender = ['male', 'female'];

    /**
     * @var DataHelper
     */
    protected $helper;

    /**
     * @var \Magento\Store\Model\StoreManager
     */
    protected $storeManager;

    /**
     * @var \Magento\Store\Model\Store
     */
    protected $store;

    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $filesystem;

    /**
     * @var \Magento\Framework\Encryption\Encryptor
     */
    protected $encryptor;

    /**
     * @var \Magento\Customer\Model\Customer
     */
    protected $customer;

    /**
     * @var \Magento\Newsletter\Model\SubscriberFactory
     */
    protected $subscriberFactory;

    /**
     * @var \Magento\Eav\Model\Config
     */
    protected $eavConfig;

    /**
     * @var \Magento\Customer\Model\Attribute
     */
    protected $attribute;

    /**
     * @var \Magento\Framework\Math\Random
     */
    protected $random;

    /**
     * @var \Magento\Framework\Filesystem\Io\File
     */
    protected $ioFile;

    /**
     * @var \Magento\Framework\ImageFactory
     */
    protected $imageFactory;

    /**
     * @var  \Magento\Framework\Session\SessionManagerInterface
     */
    protected $customerSession;

    /**
     * @var \Magento\Framework\Filesystem\DirectoryList
     */
    protected $dir;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $request;

    /**
     * @var
     */
    protected $email;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\Config\Provider
     */
    private $configProvider;

    /**
     * @var AccountProviderInterface
     */
    private $accountProvider;

    /**
     * @var \Plumrocket\SocialLoginPro\Lib\Http\Client\Curl
     */
    protected $curl;

    /**
     * @var \Magento\Framework\Serialize\SerializerInterface
     */
    protected $serializer;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\Account\Photo
     */
    protected $photo;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\Account\Data\Prepare
     */
    private $prepareData;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\Account\Data\PasswordGenerator
     */
    private $passwordGenerator;

    /**
     * @param \Magento\Framework\Model\Context                                $context
     * @param \Magento\Framework\Registry                                     $registry
     * @param \Plumrocket\SocialLoginPro\Helper\Data                          $dataHelper
     * @param \Magento\Store\Model\StoreManager                               $storeManager
     * @param \Magento\Store\Model\Store                                      $store
     * @param \Magento\Framework\Filesystem                                   $filesystem
     * @param \Magento\Framework\Encryption\Encryptor                         $encryptor
     * @param \Magento\Customer\Model\Customer                                $customer
     * @param \Magento\Newsletter\Model\SubscriberFactory                     $subscriberFactory
     * @param \Magento\Eav\Model\Config                                       $eavConfig
     * @param \Magento\Customer\Model\Attribute                               $attribute
     * @param \Magento\Framework\Math\Random                                  $random
     * @param \Magento\Framework\Filesystem\Io\File                           $ioFile
     * @param \Magento\Framework\ImageFactory                                 $imageFactory
     * @param \Magento\Framework\Session\SessionManagerInterface              $customerSession
     * @param \Magento\Framework\Filesystem\DirectoryList                     $dir
     * @param \Magento\Framework\App\RequestInterface                         $request
     * @param \Plumrocket\SocialLoginPro\Model\AccountProviderInterface       $accountProvider
     * @param \Plumrocket\SocialLoginPro\Model\Config\Provider                $configProvider
     * @param PlumCurl                                                        $curl
     * @param \Magento\Framework\Serialize\SerializerInterface                $serializer
     * @param \Plumrocket\SocialLoginPro\Model\Account\Photo                  $photo
     * @param \Plumrocket\SocialLoginPro\Model\Account\Data\PasswordGenerator $passwordGenerator
     * @param \Plumrocket\SocialLoginPro\Model\Account\Data\Prepare           $prepareData
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null    $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb|null              $resourceCollection
     * @param array                                                           $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        DataHelper $dataHelper,
        StoreManager $storeManager,
        Store $store,
        Filesystem $filesystem,
        Encryptor $encryptor,
        Customer $customer,
        SubscriberFactory $subscriberFactory,
        Config $eavConfig,
        Attribute $attribute,
        Random $random,
        File $ioFile,
        ImageFactory $imageFactory,
        SessionManagerInterface $customerSession,
        \Magento\Framework\Filesystem\DirectoryList $dir,
        RequestInterface $request,
        AccountProviderInterface $accountProvider,
        Provider $configProvider,
        PlumCurl $curl,
        SerializerInterface $serializer,
        Photo $photo,
        PasswordGenerator $passwordGenerator,
        Prepare $prepareData,
        AbstractResource $resource = null,
        AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->helper = $dataHelper;
        $this->storeManager = $storeManager;
        $this->store = $store;
        $this->filesystem = $filesystem;
        $this->encryptor = $encryptor;
        $this->customer = $customer;
        $this->subscriberFactory = $subscriberFactory;
        $this->eavConfig = $eavConfig;
        $this->attribute = $attribute;
        $this->random = $random;
        $this->ioFile = $ioFile;
        $this->imageFactory = $imageFactory;
        $this->customerSession = $customerSession;
        $this->dir = $dir;
        $this->request = $request;
        $this->configProvider = $configProvider;
        $this->accountProvider = $accountProvider;
        $this->curl = $curl;
        $this->serializer = $serializer;
        $this->photo = $photo;
        $this->prepareData = $prepareData;
        $this->passwordGenerator = $passwordGenerator;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    public function _construct()
    {
        $this->_init(\Plumrocket\SocialLoginPro\Model\ResourceModel\Account::class);
        $this->websiteId = $this->storeManager->getWebsite()->getId();
        $this->redirectUri = $this->helper->getCallbackURL($this->type);
        $this->photoDir = $this->filesystem
            ->getDirectoryRead(DirectoryList::MEDIA)
            ->getAbsolutePath('pslogin'. DIRECTORY_SEPARATOR .'photo');
        $this->applicationId = trim(
            (string) $this->helper->getConfig($this->helper->getConfigSectionId() . '/' . $this->type . '/application_id')
        );
        $this->secret = trim(
            $this->encryptor->decrypt(
                (string) $this->helper->getConfig($this->helper->getConfigSectionId() . '/' . $this->type . '/secret')
            )
        );
        $this->passwordLength = $this->helper->getConfig('customer/password/minimum_password_length');
    }

    /**
     * @return bool
     */
    public function enabled(): bool
    {
        return (bool)$this->helper->getConfig($this->helper->getConfigSectionId() .'/'. $this->type .'/enable');
    }

    /**
     * @deprecated since 3.4.0
     * @see \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface::linkNetworkToCustomer()
     * @param $customerId
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function setCustomerIdByUserId($customerId): Account
    {
        $data = [
            'type'          => $this->type,
            'user_id'       => $this->getUserData('user_id'),
            'customer_id'   => $customerId,
            'created_at'    => $this->helper->getDateTime(),
            'last_enter_at' => $this->helper->getDateTime()
        ];

        $this->addData($data)->save();
        return $this;
    }

    public function getCustomerIdByUserId()
    {
        $customerId = $this->_getCustomerIdByUserId();
        if (!$customerId && $this->helper->isGlobalScope()) {
            $customerId = $this->_getCustomerIdByUserId(true);
        }

        return $customerId;
    }

    protected function _getCustomerIdByUserId($useGlobalScope = false)
    {
        $customerId = 0;

        if ($this->getUserData('user_id')) {
            $collection = $this->getCollection()
                ->join(['ce' => 'customer_entity'], 'ce.entity_id = main_table.customer_id', null)
                ->addFieldToFilter('main_table.type', $this->type)
                ->addFieldToFilter('main_table.user_id', $this->getUserData('user_id'))
                ->setPageSize(1);

            if ($useGlobalScope === false) {
                $collection->addFieldToFilter('ce.website_id', $this->websiteId);
            }

            $customerId = $collection->getFirstItem()->getData('customer_id');
        }

        return $customerId;
    }

    public function getCustomerIdByEmail()
    {
        $customerId = $this->_getCustomerIdByEmail();
        if (!$customerId && $this->helper->isGlobalScope()) {
            $customerId = $this->_getCustomerIdByEmail(true);
        }
        return $customerId;
    }

    protected function _getCustomerIdByEmail($useGlobalScope = false)
    {
        $customerId = 0;

        if (is_string($this->getUserData('email'))) {
            $collection = $this->customer->getCollection()
                ->addFieldToFilter('email', $this->getUserData('email'))
                ->setPageSize(1);

            if ($useGlobalScope == false) {
                $collection->addFieldToFilter('website_id', $this->websiteId);
            }

            $customerId = $collection->getFirstItem()->getId();
        }

        return $customerId;
    }

    public function registrationCustomer()
    {
        $customerId = 0;
        $errors = [];
        /** @var \Magento\Customer\Model\Customer $customer */
        $customer = $this->customer->setId(null);

        try {
            $customer->setData($this->getUserData())
                ->setConfirmation($customer->getRandomConfirmationKey())
                ->setPasswordConfirmation($this->getUserData('password'))
                ->setData('is_active', 1)
                ->getGroupId();

            $errors = $this->_validateErrors($customer);

            // If email is not valid, always error.
            $correctEmail = \Zend_Validate::is($this->getUserData('email'), 'EmailAddress');

            if ((empty($errors) || $this->configProvider->getRequireLevel()) && $correctEmail) {
                $customerId = $customer->save()->getId();

                if ($this->configProvider->isEnabledSubscription()
                    && ! $this->helper->isFakeMail($this->getUserData('email'))
                ) {
                    $this->subscriberFactory->create()->subscribeCustomerById($customerId);
                    $this->_registry->unregister('prgdpr_skip_save_consents');
                }

                // Set email confirmation;
                $customer->setConfirmation(null)->save();
            } elseif (! $correctEmail) {
                $errors[] = __('Please enter a customer email.');
            }
        } catch (\Exception $e) {
            $errors[] = $e->getMessage();
        }

        $this->setCustomer($customer);
        $this->setErrors($errors);

        return $customerId;
    }

    protected function _validateErrors($customer)
    {
        $errors = [];

        // Date of birth.
        $entityType = $this->eavConfig->getEntityType('customer');
        $attribute = $this->attribute->loadByCode($entityType, 'dob');

        if ($attribute->getIsRequired()
            && $this->getUserData('dob')
            && ! \Zend_Validate::is($this->getUserData('dob'), 'Date')
        ) {
            $errors[] = __('The Date of Birth is not correct.');
        }

        if (true !== ($customerErrors = $customer->validate())) {
            $errors = array_merge($customerErrors, $errors);
        }

        return $errors;
    }

    public function getResponseType()
    {
        return $this->responseType;
    }

    public function getEmail()
    {
        return $this->email;
    }

    public function setUserData($key, $value = null): Account
    {
        if (is_array($key)) {
            $this->userData = array_merge($this->userData, $key);
        } else {
            $this->userData[$key] = $value;
        }
        return $this;
    }

    public function getUserData($key = null)
    {
        if ($key !== null) {
            return isset($this->userData[$key]) ? $this->userData[$key] : null;
        }
        return $this->userData;
    }

    protected function _prepareData($data)
    {
        $_data = [];
        foreach ($this->fields as $customerField => $userField) {
            $_data[$customerField] = ($userField && isset($data[$userField])) ? $data[$userField] : null;
        }

        $_data = $this->prepareData->email($_data);
        $_data = $this->prepareData->names($_data);
        $_data = $this->prepareData->dateOfBirth($_data, $this->dob);
        $_data = $this->prepareData->gender($_data, $this->fields);
        $_data = $this->prepareData->taxVat($_data);

        $_data['phone_number'] = isset($_data['phone_number']) ?: '';
        $_data['password'] = $this->passwordGenerator->generatePassword();

        return $_data;
    }

    /**
     * @deprecated since 3.4.0
     * @see Account::loadAndSaveCustomerPhotoFromNetwork()
     * @param int         $customerId
     * @param string|null $customerPhoto
     * @return bool|null
     */
    public function setCustomerPhoto($customerId, $customerPhoto = null)
    {
        if (is_null($customerPhoto)) {
            $customerPhoto = $this->userData['photo'] ?? '';
        }

        return $this->loadAndSaveCustomerPhotoFromNetwork((int) $customerId, $customerPhoto);
    }

    /**
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function postToMail(): bool
    {
        if (!$this->helper->isFakeMail($this->getUserData('email'))) {
            $storeId = $this->storeManager->getStore()->getId();
            $this->customer->sendNewAccountEmail('registered', '', $storeId);
        }

        return true;
    }

    /**
     * @return array
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getButton(): array
    {
        // Href.
        $uri = null;

        if ($this->getProtocol() == 'OAuth' && (empty($this->applicationId) || empty($this->secret))) {
            $uri = $loginHref = $registerHref = $linkHref = null;
        } else {
            $uriParams = ['type' => $this->type, 'refresh' => time()];

            $uri = $this->store->getUrl('pslogin/account/douse', $uriParams);
            $loginHref = $this->store->getUrl(
                'pslogin/account/douse',
                array_merge($uriParams, ['customer_action' => self::CUSTOMER_ACTION_LOGIN])
            );
            $registerHref = $this->store->getUrl(
                'pslogin/account/douse',
                array_merge($uriParams, ['customer_action' => self::CUSTOMER_ACTION_REGISTER])
            );
            $linkHref = $this->store->getUrl(
                'pslogin/account/douse',
                array_merge($uriParams, ['customer_action' => self::CUSTOMER_ACTION_LINK])
            );
        }

        // Images.
        $image = [];
        $media = $this->store->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) .'pslogin/';

        // ..icon
        $iconBtn = $this->helper->getConfig($this->helper->getConfigSectionId() .'/'. $this->type .'/icon_btn');
        $image['icon'] = $iconBtn? $media . $iconBtn : null;

        // ..login
        $loginBtn = $this->helper->getConfig($this->helper->getConfigSectionId() .'/'. $this->type .'/login_btn');
        $image['login'] = $loginBtn? $media . $loginBtn : null;

        // ..register
        $registerBtn = $this->helper->getConfig($this->helper->getConfigSectionId() .'/'. $this->type .'/register_btn');
        $image['register'] = $registerBtn? $media . $registerBtn : null;

        return [
            'href' => $uri,
            'login_href' => $loginHref,
            'register_href' => $registerHref,
            'link_href' => $linkHref,
            'type' => $this->type,
            'image' => $image,
            'login_text' => $this->helper->getConfig(
                $this->helper->getConfigSectionId() . '/' . $this->type . '/login_btn_text'
            ),
            'link_text' => $this->helper->getConfig(
                $this->helper->getConfigSectionId() . '/' . $this->type . '/link_text'
            ),
            'register_text' => $this->helper->getConfig(
                $this->helper->getConfigSectionId() . '/' . $this->type . '/register_btn_text'
            ),
            'popup_width' => $this->popupSize[0],
            'popup_height' => $this->popupSize[1],
        ];
    }

    public function getProviderLink()
    {
        if (empty($this->applicationId) || empty($this->secret)) {
            $uri = null;
        } elseif (is_array($this->buttonLinkParams)) {
            $uri = $this->url .'?'. urldecode(http_build_query($this->buttonLinkParams));
        } else {
            $uri = $this->buttonLinkParams;
        }

        return $uri;
    }

    /**
     * @return string|null
     */
    public function getProvider()
    {
        return $this->type;
    }

    /**
     * @return string
     */
    public function getProtocol(): string
    {
        return $this->protocol;
    }

    public function _setLog($data, $append = false, $isCallRequest = false)
    {
        if ($this->helper->getDebugMode()) {
            $log = [];
            $title = strtoupper($this->type);
            $log[] = "\n-------- $title --------";

            if (is_string($data)) {
                try {
                    $data = $this->serializer->unserialize($data);
                } catch (\InvalidArgumentException $e) {}
            }

            if (is_array($data) || is_object($data)) {
                $log[] = print_r($data, true);
            } else if (strpos(trim($data), ' ') === false) {
                parse_str($data, $result);
                $log[] = print_r($result, true);
            } else {
                $log[] = $data;
            }

            if (! $isCallRequest) {
                $this->callInfo = $log;
            }

            $log[] = '---------------------------------';

            $psloginLog = $this->customerSession->getPsloginLog();
            if (null === $psloginLog) {
                $psloginLog = [];
            }
            $psloginLog[] = implode(PHP_EOL, $log);
            $this->customerSession->setPsloginLog($psloginLog);
        }
    }

    /**
     * Record error in the log
     * @return void
     */
    public function recordLog()
    {
        $pathToLog = $this->dir->getPath('log');
        if (! is_dir($pathToLog)) {
            $this->ioFile->mkdir($pathToLog);
        }
        $writer = new \Zend\Log\Writer\Stream($pathToLog . DIRECTORY_SEPARATOR . self::LOG_FILE);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->debug(implode(PHP_EOL, $this->customerSession->getPsloginLog()));
    }

    /**
     * @param $url
     * @param $params
     * @return array
     */
    protected function _prepareParams($url, $params)
    {
        $paramsStr = is_array($params)? urlencode(http_build_query($params)) : urlencode($params);
        if ($paramsStr) {
            $url .= '?'. urldecode($paramsStr);
        }

        return ['url' => $url, 'params' => $paramsStr];
    }

    /**
     * Makes a post query for a given $url and parameters
     * @param $url
     * @param array $params
     * @return string
     */
    public function makePostCall($url, array $params = []): string
    {
        try {
            $this->_setLog($url, true, true);
            $this->curl->post($url, $params);
        } catch (\Exception $e) {
            $this->_setLog($e, true, true);
        }

        $body = $this->curl->getBody();
        $this->curl->reset();
        return $body;
    }

    /**
     * Makes a get query for a given $url and options
     * @param string $url
     * @param array  $urlParams
     * @param string $options
     * @param string $value
     * @return string
     */
    public function makeGetCall(string $url, array $urlParams, $options = '', $value = ''): string
    {
        try {
            $this->_setLog($url, true, true);
            if ($options) {
                $this->curl->setOption($options, $value);
            }
            $this->curl->get($url, $urlParams);
        } catch (\Exception $e) {
            $this->_setLog($e->getMessage(), true, true);
        }

        $body = $this->curl->getBody();
        $this->curl->reset();
        return $body;
    }

    /**
     * @deprecated use Magento Curl class instead
     * @param $url
     * @param array $params
     * @param string $method
     * @param null $curlResource
     * @return bool|string|null
     */
    protected function _call($url, $params = [], $method = 'GET', $curlResource = null)
    {
        $preparePrams = $this->_prepareParams($url, $params);
        $url = $preparePrams['url'];
        $paramsStr = $preparePrams['params'];

        $this->_setLog($url, true, true);

        $curl = is_resource($curlResource)? $curlResource : curl_init();

        if ($method === 'POST') {
            // POST.
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $paramsStr);
        } else {
            // GET.
            curl_setopt($curl, CURLOPT_URL, $url);
        }

        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($curl);

        if (curl_errno($curl)) {
            $this->_setLog(curl_getinfo($curl), true, true);
            $this->_setLog(curl_error($curl), true, true);
        }

        curl_close($curl);

        return $result;
    }

    /**
     * Retrieve account url
     * @return string
     */
    public function getAccountUrl(): string
    {
        return (string) $this->getSocialModel()->getSocialUrl();
    }

    /**
     * Retrieve account image
     * @return string
     */
    public function getAccountImage(): string
    {
        $socialModel = $this->getSocialModel();
        $photo = $socialModel->getSocialPhoto();

        if (! $photo) {
            $photo = $this->helper->getPhotoPath(false, $this->getCustomerId());
        }

        return $photo;
    }

    /**
     * Retrieve social model
     * @return $this
     * @throws \Exception
     */
    protected function getSocialModel(): self
    {
        $socialModel = $this->accountProvider->getByType($this->getType());
        $socialModel->setData($this->getData());
        $socialModel->setData($this->prepareAdditionalData($this->getData()));

        return $socialModel;
    }

    /**
     * Retrieve social network errors
     *
     * @return mixed
     */
    public function getDebugErrors()
    {
        // Replace origin application id and secret key to fake
        $protectSecretData = function (&$value) {
            $search = [$this->applicationId, $this->secret];
            $replace = ['APPLICATION_ID', 'SECRET_KEY'];
            return $value =  str_replace($search, $replace, $value);
        };

        if (is_array($this->callInfo)) {
            array_walk_recursive($this->callInfo, $protectSecretData);
        } elseif (is_string($this->callInfo)) {
            $this->callInfo = $protectSecretData($this->callInfo);
        }

        return $this->callInfo;
    }

    /**
     * Replace origin application id and secret key to fake
     * @param string $data
     * @return string
     */
    protected function protectSecretData($data): string
    {
        $search = [$this->applicationId, $this->secret];
        $replace = ['APPLICATION_ID', 'SECRET_KEY'];
        return str_replace($search, $replace, $data);
    }

    /**
     * Decoded additional json data
     *
     * @param array $data
     * @return array
     */
    protected function prepareAdditionalData(array $data): array
    {
        if (isset($data['additional']) && $data['additional']) {
            $data['additional'] = $this->serializer->unserialize($data['additional']);
        }

        return $data;
    }

    /**
     * @param string $key
     * @param mixed $value
     * @return $this
     */
    public function addAdditionalData($key, $value): self
    {
        $data = $this->getAdditional();
        if (! is_array($data)) {
            $data = [];
        }

        $data[$key] = $value;
        $this->setAdditional($data);

        return $this;
    }

    /**
     * Serialize additional data
     *
     * @return \Magento\Framework\Model\AbstractModel
     */
    public function beforeSave()
    {
        $additional = $this->getAdditional();
        if (is_array($additional)) {
            $this->setAdditional($this->serializer->serialize($additional));
        }

        return parent::beforeSave();
    }

    /**
     * @return array
     */
    public function getErrors(): array
    {
        return $this->getData('errors') ?: [];
    }

    /**
     * @param int $customerId
     * @param string $customerPhoto
     * @return bool
     */
    public function loadAndSaveCustomerPhotoFromNetwork(int $customerId, string $customerPhoto): bool
    {
        try {
            return $this->photo->saveExternal($customerId, $customerPhoto);
        } catch (ValidationException $e) {
            return false;
        }
    }
}
