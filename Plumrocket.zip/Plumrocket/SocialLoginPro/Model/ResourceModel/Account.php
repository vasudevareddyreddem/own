<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2017 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model\ResourceModel;

class Account extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    public function _construct()
    {
        $this->_init('plumrocket_sociallogin_account', 'id');
    }

    /**
     * @param $type
     * @param $userId
     * @return int
     */
    public function getCustomerIdByNetwork($type, $userId)
    {
        $connection = $this->getConnection();

        $bind = ['type' => $type, 'userId' => $userId];

        $select = $connection->select()->from(
            $this->getTable($this->getMainTable()),
            ['customer_id']
        )->where(
            'type = :type'
        )->where(
            'user_id = :userId'
        )->limit(
            1
        );

        return (int)$connection->fetchOne($select, $bind);
    }
}
