<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model\Provider;

use Magento\Framework\App\Area;

class Callback
{
    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    private $request;

    /**
     * @var \Magento\Store\Model\StoreManager
     */
    private $storeManager;

    /**
     * @var \Magento\Backend\App\Area\FrontNameResolver
     */
    private $frontNameResolver;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @var \Magento\Framework\App\State
     */
    private $state;

    /**
     * Callback constructor.
     * @param \Magento\Framework\App\RequestInterface $request
     * @param \Magento\Store\Model\StoreManager $storeManager
     * @param \Magento\Backend\App\Area\FrontNameResolver $frontNameResolver
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Store\Model\StoreManager $storeManager,
        \Magento\Backend\App\Area\FrontNameResolver $frontNameResolver,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\App\State $state
    ) {
        $this->request = $request;
        $this->storeManager = $storeManager;
        $this->frontNameResolver = $frontNameResolver;
        $this->scopeConfig = $scopeConfig;
        $this->state = $state;
    }

    /**
     * Get redirect url by provider
     * @param  string
     * @param  boolean
     * @return string
     */
    public function getUrl($provider, $byRequest = false)
    {
        $storeCode = $this->request->getParam('store');

        if (! $storeCode && $this->state->getAreaCode() === Area::AREA_ADMINHTML) {
            $websiteCode = $this->request->getParam('website');
            $storeCode = $this->storeManager
                ->getWebsite($byRequest ? $websiteCode : null)
                ->getDefaultGroup()
                ->getDefaultStoreId();

            if (! $storeCode) {
                $websites = $this->storeManager->getWebsites(true);

                foreach ($websites as $website) {
                    $storeCode = $website->getDefaultGroup()->getDefaultStoreId();

                    if ($storeCode) {
                        break;
                    }
                }
            }

            if (! $storeCode) {
                $storeCode = self::DEFAULT_STORE_CODE;
            }
        }
        $url = $this->storeManager->getStore($storeCode)->getUrl(
            'pslogin/account/login',
            ['type' => $provider, 'key' => false, '_nosid' => true]
        );

        $url = str_replace(
            DIRECTORY_SEPARATOR . $this->frontNameResolver->getFrontName() . DIRECTORY_SEPARATOR,
            DIRECTORY_SEPARATOR,
            $url
        );

        if (false !== ($length = stripos($url, '?'))) {
            $url = substr($url, 0, $length);
        }

        $url = preg_replace('/key\/(.*)/', '', $url);

        if ($byRequest) {
            if ($this->scopeConfig->getValue('web/seo/use_rewrites')) {
                $url = str_replace('index.php/', '', $url);
            }
        }

        return $url;
    }
}
