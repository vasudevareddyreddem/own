<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model\Network;

class ApiCallParamsPersistor implements ApiCallParamsPersistorInterface
{
    const PSLOGIN_SESSION_PART_NAME = 'pslogin_api_call_params';

    /**
     * @var \Magento\Customer\Model\Session
     */
    private $customerSession;

    /**
     * ApiCallParamsPersistor constructor.
     *
     * @param \Magento\Customer\Model\Session $customerSession
     */
    public function __construct(\Magento\Customer\Model\Session $customerSession)
    {
        $this->customerSession = $customerSession;
    }

    /**
     * @param      $key
     * @param null $value
     * @return $this|ApiCallParamsPersistorInterface
     */
    public function add($key, $value)
    {
        $data = $this->customerSession->getData(self::PSLOGIN_SESSION_PART_NAME);
        $data[$key] = $value;
        $this->customerSession->setData(self::PSLOGIN_SESSION_PART_NAME, $data);
        return $this;
    }

    /**
     * @param array $value
     * @return $this
     */
    public function set(array $value)
    {
        $this->customerSession->setData(self::PSLOGIN_SESSION_PART_NAME, $value);
        return $this;
    }

    /**
     * @param string|null $key
     * @return mixed|null
     */
    public function get($key = null)
    {
        if (null !== $key) {
            $data = $this->customerSession->getData(self::PSLOGIN_SESSION_PART_NAME);
            return isset($data[$key]) ? $data[$key] : null;
        }

        return $this->customerSession->getData(self::PSLOGIN_SESSION_PART_NAME);
    }

    /**
     * @return $this|ApiCallParamsPersistorInterface
     */
    public function clear()
    {
        $this->customerSession->unsetData(self::PSLOGIN_SESSION_PART_NAME);

        return $this;
    }
}
