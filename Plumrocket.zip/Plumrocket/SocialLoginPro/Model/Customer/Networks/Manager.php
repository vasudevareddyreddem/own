<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model\Customer\Networks;

use Plumrocket\SocialLoginPro\Model\Account;

class Manager implements \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface
{
    /**
     * @var \Plumrocket\SocialLoginPro\Model\ResourceModel\Account\Collection
     */
    private $networkCollectionFactory;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\ResourceModel\Account
     */
    private $resourceNetwork;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\AccountProviderInterface
     */
    private $networkProvider;

    /**
     * @var \Plumrocket\SocialLoginPro\Helper\Data
     */
    private $dataHelper;

    /**
     * @var \Magento\Customer\Helper\Session\CurrentCustomer
     */
    private $currentCustomer;

    /**
     * @var array[]
     */
    private $typesCache = [];

    /**
     * @var array[]
     */
    private $networksCache = [];

    /**
     * Manager constructor.
     *
     * @param \Plumrocket\SocialLoginPro\Model\ResourceModel\Account\CollectionFactory $networkCollectionFactory
     * @param \Plumrocket\SocialLoginPro\Model\ResourceModel\Account                   $resourceNetwork
     * @param \Plumrocket\SocialLoginPro\Model\AccountProviderInterface                $networkProvider
     * @param \Plumrocket\SocialLoginPro\Helper\Data                                   $dataHelper
     * @param \Magento\Customer\Helper\Session\CurrentCustomer                         $currentCustomer
     */
    public function __construct(
        \Plumrocket\SocialLoginPro\Model\ResourceModel\Account\CollectionFactory $networkCollectionFactory,
        \Plumrocket\SocialLoginPro\Model\ResourceModel\Account $resourceNetwork,
        \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $networkProvider,
        \Plumrocket\SocialLoginPro\Helper\Data $dataHelper,
        \Magento\Customer\Helper\Session\CurrentCustomer $currentCustomer
    ) {
        $this->networkCollectionFactory = $networkCollectionFactory;
        $this->resourceNetwork = $resourceNetwork;
        $this->networkProvider = $networkProvider;
        $this->dataHelper = $dataHelper;
        $this->currentCustomer = $currentCustomer;
    }

    /**
     * @param int $customerId
     * @return string[]
     */
    public function getLinkedTypesByCustomerId($customerId)
    {
        $customerId = (int)$customerId;

        if (! array_key_exists($customerId, $this->typesCache)) {
            $networks = $this->getLinkedNetworksByCustomerId($customerId);

            $this->typesCache[$customerId] = array_map(
                static function (Account $network) {
                    return $network->getProvider();
                },
                $networks
            );
        }

        return $this->typesCache[$customerId];
    }

    /**
     * @param int $customerId
     * @return Account[]
     */
    public function getLinkedNetworksByCustomerId($customerId)
    {
        $customerId = (int)$customerId;

        if (! $customerId) {
            return [];
        }

        if (! array_key_exists($customerId, $this->networksCache)) {
            /** @var \Plumrocket\SocialLoginPro\Model\ResourceModel\Account\Collection $collection */
            $collection = $this->networkCollectionFactory->create();
            $collection->addFieldToFilter('customer_id', (int)$customerId);

            $networks = [];

            foreach ($collection->getItems() as $item) {
                $network = $this->networkProvider->createByType($item->getType());
                $network->setData($item->getData());
                $networks[] = $network;
            }

            $this->networksCache[$customerId] = $networks;
        }

        return $this->networksCache[$customerId];
    }

    /**
     * @return string[]
     */
    public function getLinkedTypesForCurrentCustomer()
    {
        return $this->getLinkedTypesByCustomerId($this->currentCustomer->getCustomerId());
    }

    /**
     * @return Account[]
     */
    public function getLinkedNetworksForCurrentCustomer()
    {
        return $this->getLinkedNetworksByCustomerId($this->currentCustomer->getCustomerId());
    }

    /**
     * @param string      $type
     * @param int         $userId
     * @param int         $customerId
     * @param string|null $customerPhoto
     * @return bool
     *
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\ValidatorException
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     */
    public function linkNetworkToCustomer($type, $userId, $customerId, $customerPhoto = null)
    {
        if (! $customerId || ! $userId || ! $type) {
            throw new \Magento\Framework\Exception\ValidatorException(
                __('One of the params "customerId", "userId", "type" is empty')
            );
        }

        if ($linkedCustomerId = $this->getCustomerIdByNetwork($type, $userId)) {
            if ($linkedCustomerId === (int)$customerId) {
                throw new \Magento\Framework\Exception\AlreadyExistsException(
                    __('This %1 account has already been assigned to your store account.', $type)
                );
            }

            throw new \Magento\Framework\Exception\AlreadyExistsException(
                __('This %1 account has already been assigned to another store account.', $type)
            );
        }

        $network = $this->networkProvider->createByType($type);

        $data = [
            'type'          => $type,
            'user_id'       => $userId,
            'customer_id'   => $customerId,
            'created_at'    => $this->dataHelper->getDateTime(),
            'last_enter_at' => $this->dataHelper->getDateTime()
        ];

        $network->addData($data);

        $this->resourceNetwork->save($network);

        if ($this->dataHelper->photoEnabled()) {
            $network->setCustomerPhoto($customerId, $customerPhoto);
        }

        return true;
    }

    /**
     * @param int $customerId
     * @param int $networkAccountId
     * @return bool
     */
    public function unlinkNetworkFromCustomer($customerId, $networkAccountId)
    {
        /** @var \Plumrocket\SocialLoginPro\Model\ResourceModel\Account\Collection $collection */
        $collection = $this->networkCollectionFactory->create();
        $collection->addFieldToFilter('customer_id', (int)$customerId)
                   ->addFieldToFilter('id', $networkAccountId)
                   ->setPageSize(1);

        /** @var Account $network */
        $network = $collection->getFirstItem();

        if ($network->getId()) {
            try {
                $this->resourceNetwork->delete($network);
                return true;
            } catch (\Exception $e) {
                return false;
            }
        }

        return false;
    }

    /**
     * @param string $type
     * @param int    $userId
     * @return bool
     */
    public function isNetworkAlreadyLinked($type, $userId)
    {
        return (bool)$this->resourceNetwork->getCustomerIdByNetwork($type, $userId);
    }

    /**
     * @param string $type
     * @param int    $userId
     * @return bool|void
     */
    public function getCustomerIdByNetwork($type, $userId)
    {
        return $this->resourceNetwork->getCustomerIdByNetwork($type, $userId);
    }
}
