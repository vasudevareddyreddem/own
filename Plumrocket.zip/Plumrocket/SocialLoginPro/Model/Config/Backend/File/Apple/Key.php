<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model\Config\Backend\File\Apple;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Filesystem;

class Key extends \Magento\Config\Model\Config\Backend\File
{
    /**
     * @var \Magento\Framework\Filesystem\DriverInterface $driver
     */
    protected $driver;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    protected $messageManager;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\Token\Apple $apple
     */
    protected $apple;

    /**
     * Key constructor.
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $config
     * @param \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList
     * @param \Magento\MediaStorage\Model\File\UploaderFactory $uploaderFactory
     * @param \Magento\Config\Model\Config\Backend\File\RequestData\RequestDataInterface $requestData
     * @param \Magento\Framework\Filesystem $filesystem
     * @param \Magento\Framework\Filesystem\DriverInterface $driver
     * @param \Magento\Framework\Message\ManagerInterface $messageManager
     * @param \Plumrocket\SocialLoginPro\Model\Token\Apple $apple
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb|null $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        ScopeConfigInterface $config,
        \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList,
        \Magento\MediaStorage\Model\File\UploaderFactory $uploaderFactory,
        \Magento\Config\Model\Config\Backend\File\RequestData\RequestDataInterface $requestData,
        Filesystem $filesystem,
        \Magento\Framework\Filesystem\DriverInterface $driver,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Plumrocket\SocialLoginPro\Model\Token\Apple $apple,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct(
            $context,
            $registry,
            $config,
            $cacheTypeList,
            $uploaderFactory,
            $requestData,
            $filesystem,
            $resource,
            $resourceCollection,
            $data
        );
        $this->driver = $driver;
        $this->messageManager = $messageManager;
        $this->apple = $apple;
    }

    /**
     * @return \Magento\Config\Model\Config\Backend\File
     * @throws \Magento\Framework\Exception\FileSystemException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function beforeSave()
    {
        $file = $this->getFileData();
        if (!empty($file) && $this->isValueChanged()) {
            $key = $this->driver->fileGetContents($file['tmp_name']);
            $key = openssl_pkey_get_private($key);

            if (!$key) {
                throw new \Magento\Framework\Exception\LocalizedException(
                    __('You have provided invalid Apple key.')
                );
            }
        }

        if (isset($key)) {
            $this->apple->generateSecret($key);
        }

        return parent::beforeSave();
    }
}
