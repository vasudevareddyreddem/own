<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Model\Config\Source;

/**
 * @since 3.5.0
 */
class OneTapTitle implements \Magento\Framework\Option\ArrayInterface
{
    const ONE_TAP_TITLE_USE = 'use';
    const ONE_TAP_TITLE_SIGN_IN = 'signin';
    const ONE_TAP_TITLE_SIGN_UP = 'signup';

    /**
     * Return array of options as value-label pairs
     *
     * @return array Format: array(array('value' => '<value>', 'label' => '<label>'), ...)
     */
    public function toOptionArray(): array
    {
        return [
            ['value' => self::ONE_TAP_TITLE_USE,    'label' => __('Use with Google')],
            ['value' => self::ONE_TAP_TITLE_SIGN_IN, 'label' => __('Sign in with Google')],
            ['value' => self::ONE_TAP_TITLE_SIGN_UP, 'label' => __('Sign up with Google')],
        ];
    }
}
