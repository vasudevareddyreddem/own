<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Model\Config\Source;

class Page implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray(): array
    {
        return [
            'cms_index_index'       => __('Home Page'),
            'catalog_product_view'  => __('Product Pages'),
            'catalog_category_view' => __('Category Pages'),
            'checkout_cart_index'   => __('Cart Page'),
            'checkout_index_index'  => __('Checkout Page'),
            'cms_page_view'         => __('Cms Pages'),
            'contact_index_index'   => __('Contact Us Page'),
            'skin-alchemy_index_index'   => __('Skin Alchemy Page'),
        ];
    }

    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray(): array
    {
        $result = [];
        foreach ($this->toArray() as $value => $label) {
            $result[] = ['value' => $value, 'label' => $label];
        }

        return $result;
    }
}
