<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model\Config\Source;

class RequireLevel implements \Magento\Framework\Option\ArrayInterface
{
    const NO = 1;
    const ONLY_EMAIL = 2;
    const ALL = 0;

    /**
     * Return array of options as value-label pairs
     *
     * @return array Format: array(array('value' => '<value>', 'label' => '<label>'), ...)
     */
    public function toOptionArray()
    {
        return [
            ['value' => self::NO,         'label' => __('No profile data is required (quick registration)')],
            ['value' => self::ONLY_EMAIL, 'label' => __('Only email is required')],
            ['value' => self::ALL,        'label' => __('All account registration fields are required')],
        ];
    }
}
