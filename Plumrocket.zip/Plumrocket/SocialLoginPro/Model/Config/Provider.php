<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Model\Config;

use Plumrocket\SocialLoginPro\Model\Config\Source\RequireLevel;

class Provider
{
    const XML_PATH_REPLACE_TEMPLATES              = 'psloginpro/main/replace_templates';

    /**
     * @deprecated since 3.4.0
     */
    const XML_PATH_ENABLE_FOR_LOGIN               = 'psloginpro/main/enable_for_login';

    /**
     * @deprecated since 3.4.0
     */
    const XML_PATH_ENABLE_FOR_REGISTER            = 'psloginpro/main/enable_for_register';
    const XML_PATH_BUTTON_SORT                    = 'psloginpro/main/sortable';
    const XML_PATH_REDIRECT_FOR_LOGIN             = 'psloginpro/main/redirect_for_login';
    const XML_PATH_REDIRECT_FOR_LOGIN_LINK        = 'psloginpro/main/redirect_for_login_link';
    const XML_PATH_REDIRECT_FOR_REGISTER          = 'psloginpro/main/redirect_for_register';
    const XML_PATH_REDIRECT_FOR_REGISTER_LINK     = 'psloginpro/main/redirect_for_register_link';
    const XML_PATH_ENABLE_SUBSCRIPTION            = 'psloginpro/main/enable_subscription';
    const XML_PATH_ENABLE_PHOTO                   = 'psloginpro/main/enable_photo';
    const XML_PATH_REGISTER_REQUIRE_LEVEL         = 'psloginpro/main/require_level';

    const XML_PATH_PREVENT_DUPLICATE_ENABLED      = 'psloginpro/developer/prevent_duplicate';
    const XML_PATH_MATCHING_EMAIL_REQUIRE_CONFIRM = 'psloginpro/developer/require_confirm';

    const XML_PATH_SHARE_POPUP_ENABLE             = 'psloginpro/share/enable';

    const XML_PATH_BUTTON_REMINDER_SORT           = 'psloginpro/link/reminder_sortable';

    const XML_PATH_LINK_STATUS                    = 'psloginpro/link/enable';
    const XML_PATH_LINK_DESCRIPTION               = 'psloginpro/link/description';
    const XML_PATH_LINK_REMINDER_POPUP_STATUS     = 'psloginpro/link/enable_popup';
    const XML_PATH_LINK_POPUP_TIMEOUT             = 'psloginpro/link/timeout';
    const XML_PATH_ENABLE_FOR                     = 'psloginpro/main/enable_for';

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @var array
     */
    private $networkEnabledInfo;

    /**
     * Provider constructor.
     *
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     */
    public function __construct(\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig)
    {
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Base Helper has got same method
     *
     * Receive magento config value
     *
     * @param string      $path
     * @param string|int  $scopeCode
     * @param string|null $scope
     * @return mixed
     */
    public function getConfig($path, $scopeCode = null, $scope = null)
    {
        if ($scope === null) {
            $scope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        }

        return $this->scopeConfig->getValue($path, $scope, $scopeCode);
    }

    /**
     * @param null $scopeCode
     * @param null $scope
     * @return array
     */
    public function getNetworkStatusInfo($scopeCode = null, $scope = null): array
    {
        if (null === $this->networkEnabledInfo) {
            $groups = $this->getConfig(\Plumrocket\SocialLoginPro\Helper\Data::SECTION_ID, $scopeCode, $scope);
            $this->networkEnabledInfo = [];

            if (! $groups) {
                return $this->networkEnabledInfo;
            }

            if (is_array($groups)) {
                unset(
                    $groups['general'],
                    $groups['share'],
                    $groups['link'],
                    $groups['developer']
                );

                foreach ($groups as $name => $fields) {
                    $this->networkEnabledInfo[$name] = isset($fields['enable'])
                        ? (int)$fields['enable']
                        : 0;
                }
            }
        }

        return $this->networkEnabledInfo;
    }

    /**
     * @param null $store
     * @param null $scope
     * @return bool
     */
    public function getReplaceTemplates($store = null, $scope = null): bool
    {
        return (bool)$this->getConfig(self::XML_PATH_REPLACE_TEMPLATES, $store, $scope);
    }

    /**
     * @param null $store
     * @param null $scope
     * @return bool
     */
    public function forLoginEnabled($store = null, $scope = null): bool
    {
        return (bool)$this->getConfig(self::XML_PATH_ENABLE_FOR_LOGIN, $store, $scope);
    }

    /**
     * @param null $store
     * @param null $scope
     * @return bool
     */
    public function forRegisterEnabled($store = null, $scope = null): bool
    {
        return (bool)$this->getConfig(self::XML_PATH_ENABLE_FOR_REGISTER, $store, $scope);
    }

    /**
     * @param null $store
     * @param null $scope
     * @return string
     */
    public function getRedirectForLogin($store = null, $scope = null): string
    {
        return (string)$this->getConfig(self::XML_PATH_REDIRECT_FOR_LOGIN, $store, $scope);
    }

    /**
     * @param null $store
     * @param null $scope
     * @return string
     */
    public function getRedirectLinkForLogin($store = null, $scope = null): string
    {
        return (string)$this->getConfig(self::XML_PATH_REDIRECT_FOR_LOGIN_LINK, $store, $scope);
    }

    /**
     * @param null $store
     * @param null $scope
     * @return string
     */
    public function getRedirectForRegister($store = null, $scope = null): string
    {
        return (string)$this->getConfig(self::XML_PATH_REDIRECT_FOR_REGISTER, $store, $scope);
    }

    /**
     * @param null $store
     * @param null $scope
     * @return string
     */
    public function getRedirectLinkForRegister($store = null, $scope = null): string
    {
        return (string)$this->getConfig(self::XML_PATH_REDIRECT_FOR_REGISTER_LINK, $store, $scope);
    }

    /**
     * @param null $store
     * @param null $scope
     * @return bool
     */
    public function isEnabledSubscription($store = null, $scope = null): bool
    {
        return (bool)$this->getConfig(self::XML_PATH_ENABLE_SUBSCRIPTION, $store, $scope);
    }
    /**
     * @param null $store
     * @param null $scope
     * @return bool
     */
    public function isEnabledPhoto($store = null, $scope = null): bool
    {
        return (bool)$this->getConfig(self::XML_PATH_ENABLE_PHOTO, $store, $scope);
    }

    /**
     * @param null $store
     * @param null $scope
     * @return array
     */
    public function getSortableParams($store = null, $scope = null): array
    {
        $value = $this->getConfig(self::XML_PATH_BUTTON_SORT, $store, $scope);
        if ($value) {
            parse_str($value, $sortParams);
            return $sortParams;
        }

        return [];
    }

    /**
     * @param int|null $store
     * @return array
     */
    public function getReminderSortableParams($store = null): array
    {
        $value = $this->getConfig(self::XML_PATH_BUTTON_REMINDER_SORT, $store);
        if ($value) {
            parse_str($value, $sortParams);
            return $sortParams;
        }

        return [];
    }

    /**
     * @return int
     */
    public function getRequireLevel(): int
    {
        return (int)$this->getConfig(self::XML_PATH_REGISTER_REQUIRE_LEVEL);
    }

    /**
     * @return bool
     */
    public function isIgnoreAllRequirements(): bool
    {
        return (int)$this->getConfig(self::XML_PATH_REGISTER_REQUIRE_LEVEL) === RequireLevel::NO;
    }

    /**
     * @return bool
     */
    public function isRequireOnlyEmail(): bool
    {
        return (int)$this->getConfig(self::XML_PATH_REGISTER_REQUIRE_LEVEL) === RequireLevel::ONLY_EMAIL;
    }

    /**
     * @return bool
     */
    public function createFakeData(): bool
    {
        return (int)$this->getConfig(self::XML_PATH_REGISTER_REQUIRE_LEVEL) !== RequireLevel::ALL;
    }

    /**
     * @return bool
     */
    public function isPreventDuplicateEnabled(): bool
    {
        return (bool)$this->getConfig(self::XML_PATH_PREVENT_DUPLICATE_ENABLED);
    }

    /**
     * @return bool
     */
    public function needConfirmWithMatchingEmail(): bool
    {
        return (bool)$this->getConfig(self::XML_PATH_MATCHING_EMAIL_REQUIRE_CONFIRM);
    }

    /**
     * @return bool
     */
    public function isLinkingEnabled(): bool
    {
        return (bool)$this->getConfig(self::XML_PATH_LINK_STATUS);
    }

    /**
     * @return bool
     */
    public function isReminderPopupEnabled(): bool
    {
        return (bool)$this->getConfig(self::XML_PATH_LINK_REMINDER_POPUP_STATUS);
    }

    /**
     * @return string
     */
    public function getLinkingDescription(): string
    {
        return (string)$this->getConfig(self::XML_PATH_LINK_DESCRIPTION);
    }

    /**
     * @return string
     */
    public function getReminderPopupTimeout(): string
    {
        return (string)$this->getConfig(self::XML_PATH_LINK_POPUP_TIMEOUT);
    }

    /**
     * @return string
     */
    public function isSharePopupEnabled(): string
    {
        return (string)$this->getConfig(self::XML_PATH_SHARE_POPUP_ENABLE);
    }

    /**
     * @return string
     */
    public function getEnabledFor(): string
    {
        return (string)$this->getConfig(self::XML_PATH_ENABLE_FOR);
    }
}
