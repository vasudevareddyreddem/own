<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model;

class Google extends Account
{
    protected $type = 'google';

    protected $url = 'https://accounts.google.com/o/oauth2/v2/auth';

    protected $fields = [
        'user_id' => 'id',
        'firstname' => 'given_name',
        'lastname' => 'family_name',
        'email' => 'email',
        'photo' => 'picture',
    ];

    protected $buttonLinkParams = [
        'scope' => 'https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile',
    ];

    protected $popupSize = [450, 450];

    public function _construct()
    {
        parent::_construct();

        $this->buttonLinkParams = array_merge($this->buttonLinkParams, [
            'client_id'     => $this->applicationId,
            'redirect_uri'  => $this->redirectUri,
            'response_type' => $this->responseType
        ]);
    }

    public function getProviderLink()
    {
        if (empty($this->applicationId) || empty($this->secret)) {
            $uri = null;
        } elseif (is_array($this->buttonLinkParams)) {
            $uri = $this->url .'?'. /*urldecode*/(http_build_query($this->buttonLinkParams));
        } else {
            $uri = $this->buttonLinkParams;
        }

        return $uri;
    }

    public function loadUserData($response)
    {
        if (empty($response)) {
            return false;
        }

        $data = [];

        $params = [
            'client_id' => $this->applicationId,
            'client_secret' => $this->secret,
            'code' => $response,
            'redirect_uri' => $this->redirectUri,
            'grant_type' => 'authorization_code',
        ];

        $token = null;
        if ($response = $this->_callPost('https://www.googleapis.com/oauth2/v4/token', $params)) {
            $token = json_decode($response, true);
        }

        $this->_setLog($token, true);

        if (isset($token['access_token'])) {
            $params['access_token'] = $token['access_token'];
            if ($response = $this->_call('https://www.googleapis.com/oauth2/v1/userinfo', $params)) {
                $data = json_decode($response, true);
            }
            $this->_setLog($data);
        }

        if (!$this->userData = $this->_prepareData($data)) {
            return false;
        }

        $this->_setLog($this->userData, true);

        return true;
    }

    protected function _prepareData($data)
    {
        if (empty($data['id'])) {
            return false;
        }

        return parent::_prepareData($data);
    }

    protected function _callPost($url, $params = [])
    {
        $this->_setLog($url, true, true);
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, urldecode(http_build_query($params)));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($curl);

        if ($errno = curl_errno($curl)) {
            $this->_setLog(curl_getinfo($curl), true, true);
            $this->_setLog(curl_error($curl), true, true);
        }

        curl_close($curl);

        return $result;
    }
}
