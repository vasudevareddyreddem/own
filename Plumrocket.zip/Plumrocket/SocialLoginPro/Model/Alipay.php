<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2017 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model;

use Magento\Framework\Encryption\Encryptor;

class Alipay extends Account
{
    protected $type = 'alipay';

    // protected $responseType = 'code';
    protected $responseType = 'app_auth_code';
    // protected $url = 'https://openauth.alipay.com/oauth2/authorize';
    protected $url = 'https://openauth.alipay.com/oauth2/appToAppAuth.htm';

    protected $fields = [
                    'user_id' => 'alipay_user_id',
                    'firstname' => 'real_name_fn',
                    'lastname' => 'real_name_ln',
                    'email' => 'email', // empty
                    'dob' => 'birthday',
                    'gender' => 'sex',
                    'photo' => 'figureurl_1',
                ];

    protected $dob = ['year', 'month', 'day', '-'];
    protected $gender = ['男', '女'];
                        /*Man 男人
                        Woman 女人
                        Male 男(性)
                        Female 女(性)*/

    protected $buttonLinkParams = [
                    // 'display' => 'popup',
                ];

    protected $popupSize = [650, 400];

    public function _construct()
    {
        parent::_construct();

        $this->buttonLinkParams = array_merge($this->buttonLinkParams, [
            'app_id'        => $this->applicationId,
            'redirect_uri'  => $this->redirectUri,
            // 'response_type' => $this->responseType
        ]);
    }

    public function loadUserData($response)
    {
        if (empty($response)) {
            return false;
        }

        $data = [];

        $params = [
            // 'app_id' => $this->applicationId,
            // 'method' => 'alipay.open.auth.token.app',
            'client_id' => $this->applicationId,
            'client_secret' => $this->secret,
            'code' => $response,
            'redirect_uri' => $this->redirectUri,
            'grant_type' => 'authorization_code',
        ];

        $token = null;
        if ($response = $this->_call('https://openauth.alipay.com/oauth2/token', $params)) {
            $token = json_decode($response, true);
            parse_str($response, $token);
        }
        $this->_setLog($token, true);


        if (isset($token['access_token'])) {
            // User info.
            $params = [
                'app_key' => $this->applicationId,
                'fields' => 'alipay_user_id,real_name,logon_id,sex,user_status,user_type,created,last_visit,birthday,type,status',
                'format' => 'json',
                'method' => 'alipay.user.get',
                'session' => $token['access_token'],
                'sign_method' => 'md5',
                'timestamp' => strftime('%Y-%m-%d %H:%M:%S'),
                'v' => '2.0',
            ];

            // # params.sort.collect { |k, v| "#{k}#{v}" }
            // str = options.client_secret + params.sort {|a,b| "#{a[0]}"<=>"#{b[0]}"}.flatten.join + options.client_secret
            // params['sign'] = Digest::MD5.hexdigest(str).upcase!

            $iterator = new \RecursiveIteratorIterator(new \RecursiveArrayIterator($arr));
            $sign = $this->secret . join('', iterator_to_array($iterator, true)) . $this->secret;
            $params['sign'] = strtoupper($this->encryptor->hash($sign, Encryptor::HASH_VERSION_MD5));

            if ($response = $this->_call('https://openapi.alipay.com/gateway.do', $params)) {
                $data = json_decode($response, true);
            }
            $this->_setLog($data, true);
        }

        if (!$this->userData = $this->_prepareData($data)) {
            return false;
        }

        $this->_setLog($this->userData, true);

        return true;
    }

    protected function _prepareData($data)
    {
        if (empty($data['alipay_user_id'])) {
            return false;
        }

        // Name.
        if (!empty($data['real_name'])) {
            $nameParts = explode(' ', $data['real_name'], 2);
            $data['real_name_fn'] = $nameParts[0];
            $data['real_name_ln'] = !empty($nameParts[1])? $nameParts[1] : '';
        }

        return parent::_prepareData($data);
    }
}
