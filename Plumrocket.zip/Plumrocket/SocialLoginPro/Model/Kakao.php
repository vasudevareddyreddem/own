<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model;

class Kakao extends Account
{
    /**
     * @var string
     */
    protected $type = 'kakao';

    /**
     * @var string
     */
    protected $url = 'https://kauth.kakao.com/oauth/authorize';

    /**
     * @var array
     */
    protected $fields = [
        'user_id' => 'id',
        'firstname' => 'nickname',
        'lastname' => 'lastname',// empty
        'email' => 'kaccount_email',// empty
        'dob' => 'birthday', // empty
        'photo' => 'thumbnail_image', // empty
    ];

    /**
     * @var array
     */
    protected $popupSize = [650, 800];

    /**
     * Kakao Construct
     */
    public function _construct()
    {
        parent::_construct();

        $this->buttonLinkParams = [
            'client_id'     => $this->applicationId,
            'redirect_uri'  => $this->redirectUri,
            'response_type' => $this->responseType,
        ];
    }

    /**
     * @param $response
     * @return bool
     */
    public function loadUserData($response)
    {
        $codeForCreatingToken = $response;

        if(empty($codeForCreatingToken)) {
            $responseParams = $this->request->getParams();

            if (isset($responseParams['error']) && $responseParams['error'] === 'access_denied') {
                $this->_registry->register('close_popup', true);
            }

            return false;
        }

        $params = [
            'client_id' => $this->applicationId,
            'client_secret' => $this->secret,
            'redirect_uri' => $this->redirectUri,
            'code' => $codeForCreatingToken,
            'grant_type' => 'authorization_code'
        ];

        $customerData = [];

        $this->_setLog($params, true);

        $createTokenUrl = 'https://kauth.kakao.com/oauth/token';

        if ($response = $this->makePostCall($createTokenUrl, $params)) {
            $token = json_decode($response, true);
        } else {
            $this->_setLog(
                'Request to ' . $createTokenUrl . ' have failed. Please check if url ' .
                'is accessible and you send correct params that meet the latest requirements',
                true
            );

            return false;
        }

        $url = 'https://kapi.kakao.com/v2/user/me';
        $response = $this->makeGetCall(
            $url,
            [],
            CURLOPT_HTTPHEADER,
            ['Authorization: Bearer ' . $token['access_token']]
        );

        if ($response && ($customerData = json_decode($response, true))) {
            if (is_array($customerData) && isset($customerData['id']) && isset($customerData['properties'])) {
                 $customerData = array_merge($customerData['properties'], ['id' => $customerData['id']]);
            } else {
                return false;
            }
        }

        if (! $this->userData = $this->_prepareData($customerData)) {
            return false;
        }

        $this->_setLog($this->userData, true);

        return true;
    }

    /**
     * @param $url
     * @param $params
     * @return array
     */
    protected function _prepareParams($url, $params)
    {
        return ['url' => $url, 'params' => http_build_query($params)];
    }
}

