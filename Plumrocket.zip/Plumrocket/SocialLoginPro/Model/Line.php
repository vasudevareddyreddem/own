<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2018 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model;

class Line extends Account
{
    protected $type = 'line';
    protected $_scope = 'openid+profile+email';

    protected $responseType = 'code';
    protected $url = 'https://access.line.me/oauth2/v2.1/authorize';

    protected $fields = [
        'user_id' => 'sub',
        'firstname' => 'name_fn',
        'lastname' => 'name_ln',
        'email' => 'email', // empty
        'dob' => 'birthday', // empty
        'photo' => 'picture',
    ];

    protected $popupSize = [650, 400];

    public function _construct()
    {
        parent::_construct();

        $this->buttonLinkParams = [
            'client_id'     => $this->applicationId,
            'redirect_uri'  => $this->redirectUri,
            'response_type' => $this->responseType,
            'scope'         => $this->_scope,
            'state'         => $this->random->getRandomString(8), //require random string
            'nonce'         => $this->random->getRandomString(8) //require random string
        ];
    }

    public function loadUserData($response)
    {
        if (empty($response)) {
            return false;
        }

        $data = [];

        $params = [
            'grant_type' => 'authorization_code',
            'code' => $response,
            'redirect_uri' => $this->redirectUri,
            'client_id' => $this->applicationId,
            'client_secret' => $this->secret,
        ];

        $token = null;
        if ($response = $this->_call('https://api.line.me/oauth2/v2.1/token', $params, 'POST')) {
            $token = json_decode($response, true);
        }

        $this->_setLog($token, true);
        if (isset($token['id_token'])) {
            // User info.
            $idToken = explode('.', $token['id_token']);
            $data = json_decode(base64_decode($idToken[1]), true);
            $this->_setLog($data, true);
        }

        if (!$this->userData = $this->_prepareData($data)) {
            return false;
        }

        $this->_setLog($this->userData, true);

        return true;
    }

    protected function _prepareParams($url, $params)
    {
        return ['url' => $url, 'params' => http_build_query($params)];
    }

    protected function _prepareData($data)
    {
        if (empty($data['sub'])) {
            return false;
        }

        // Name.
        if (!empty($data['name'])) {
            $nameParts = explode(' ', $data['name'], 2);
            $data['name_fn'] = $nameParts[0];
            $data['name_ln'] = !empty($nameParts[1])? $nameParts[1] : '';
        }

        return parent::_prepareData($data);
    }
}
