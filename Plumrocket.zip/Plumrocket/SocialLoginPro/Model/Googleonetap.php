<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Model;

class Googleonetap extends Account
{
    const LOGIN_TYPE = 'googleonetap';

    /**
     * Generally we use type for fetching application id and secret id,
     * but for One Tap we use \Plumrocket\SocialLoginPro\Helper\Config\OneTap
     * So we can change type from 'google' to 'googleonetap' although this model
     * use configs from 'google' network
     *
     * @var string
     */
    protected $type = self::LOGIN_TYPE;

    /**
     * @var array
     */
    protected $fields = [
        'user_id' => 'sub',
        'firstname' => 'given_name',
        'lastname' => 'family_name',
        'email' => 'email',
        'gender' => 'gender',
        'photo' => 'picture',
    ];

    /**
     * @return string|string[]
     */
    public function getResponseType()
    {
        return ['sub', 'email', 'given_name', 'family_name', 'gender', 'picture'];
    }

    /**
     * @param $response
     * @return bool
     * @throws \Exception
     */
    public function loadUserData($response)
    {
        if (empty($response)) {
            return false;
        }

        $id = '';

        for ($i = 1; $i <= 21; $i++) {
            $id .= random_int(0, 9);
        }

        $response['id'] = $id;
        $this->_setLog($response);

        if (!$this->userData = $this->_prepareData($response)) {
            return false;
        }

        $this->_setLog($this->userData, true);

        return true;
    }
}
