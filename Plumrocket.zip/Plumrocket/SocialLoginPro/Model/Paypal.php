<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model;

/**
 * Class Paypal
 *
 * @package Plumrocket\SocialLoginPro\Model
 */
class Paypal extends Account
{
    /**
     * @var string
     */
    const ACCESS_DENIED = 'access_denied';

    /**
     * @var string
     */
    const CLOSE_POPUP = 'close_popup';

    /**
     * @var string
     */
    const METHOD_POST = 'POST';

    /**
     * @var string
     */
    const METHOD_GET = 'GET';

    /**
     * @var string
     */
    const SCHEMA = 'paypalv1.1';

    /**
     * @var string
     */
    protected $type = 'paypal';

    /**
     * @var string
     */
    protected $responseType = 'code';

    /**
     * @var string
     */
    protected $url = '';

    /**
     * @var array
     */
    protected $fields = [
                    'user_id' => 'user_id',
                    'firstname' => 'given_name', // empty
                    'lastname' => 'family_name', // empty
                    'name' => 'name',
                    'email' => 'email',
                    'dob' => 'birthday',
                    'gender' => 'gender', // empty
                    'photo' => 'picture', // empty
                ];

    /**
     * @var array
     */
    protected $dob = ['year', 'month', 'day', '-'];

    /**
     * @var array
     */
    protected $gender = ['male', 'female'];

    /**
     * @var array
     */
    protected $buttonLinkParams = [
                'scope' => 'openid profile email'
            ];

    /**
     * @var array
     */
    protected $popupSize = [450, 520];

    /**
     * @var null | string
     */
    protected $sandboxMode = null;

    /**
     * @var null | string
     */
    protected $startUrl = null;

    /**
     * Paypal Constructor
     */
    public function _construct()
    {
        parent::_construct();

        $this->sandboxMode = (bool)$this->helper->getConfig($this->helper->getConfigSectionId()
            . '/' . $this->type . '/sandbox_mode');

        if ($this->sandboxMode) {
            $this->applicationId = trim($this->helper->getConfig($this->helper->getConfigSectionId()
                . '/' . $this->type .'/sandbox_application_id'));
            $this->secret = trim($this->encryptor->decrypt($this->helper->getConfig($this->helper->getConfigSectionId()
                . '/' . $this->type . '/sandbox_secret')));
        }

        $this->url = sprintf(
            'https://www.%spaypal.com/webapps/auth/protocol/openidconnect/v1/authorize',
            $this->sandboxMode ? 'sandbox.' : ''
        );

        $this->startUrl = sprintf('https://api.%spaypal.com', $this->sandboxMode ? 'sandbox.' : '');
        $this->buttonLinkParams = array_merge($this->buttonLinkParams, [
            'client_id'     => $this->applicationId,
            'redirect_uri'  => $this->redirectUri,
            'response_type' => $this->responseType,
        ]);
    }

    /**
     * @return array|string|null
     */
    public function getProviderLink()
    {
        if (empty($this->applicationId) || empty($this->secret)) {
            $uri = null;
        } elseif (is_array($this->buttonLinkParams)) {
            $uri = $this->url . '?' . /*urldecode*/(http_build_query($this->buttonLinkParams));
        } else {
            $uri = $this->buttonLinkParams;
        }

        return $uri;
    }

    /**
     * @param $response
     * @return bool
     */
    public function loadUserData($response)
    {
        if (empty($response)) {
            $responseParams = $this->request->getParams();
            if (isset($responseParams['error']) && $responseParams['error'] === self::ACCESS_DENIED) {
                $this->_registry->register(self::CLOSE_POPUP, true);
            }

            return false;
        }

        $data = [];

        $params = [
            'code' => $response,
            'redirect_uri' => $this->redirectUri,
            'grant_type' => 'authorization_code',
        ];

        $token = null;

        $response = $this->_call(
            $this->startUrl . '/v1/identity/openidconnect/tokenservice',
            $params,
            $method = self::METHOD_POST
        );

        if ($response) {
            $token = json_decode($response, true);
        }

        $this->_setLog($token, true);

        if (isset($token['access_token'])) {
            $params = [
                'access_token' => $token['access_token'],
            ];

            $response = $this->_call(
                $this->startUrl . '/v1/identity/oauth2/userinfo?schema=' . self::SCHEMA,
                $params
            );

            if ($response) {
                $data = json_decode($response, true);
            }

            $this->_setLog($data, true);
        }

        if (! $this->userData = $this->_prepareData($data)) {
            return false;
        }

        $this->_setLog($this->userData, true);

        return true;
    }

    /**
     * @param $data
     * @return array|bool
     */
    protected function _prepareData($data)
    {
        if (empty($data['user_id'])) {
            return false;
        }

        if (! empty($data['name'])) {
            $prepareName = explode(' ', $data['name']);
            $data['given_name'] = !empty($data['given_name']) ? $data['given_name'] : $prepareName[0];
            $data['family_name'] = !empty($data['family_name']) ? $data['family_name'] : $prepareName[1];
        }

        if (! empty($data['emails'])) {
            foreach ($data['emails'] as $email) {
                if ($email['primary']) {
                    $data['email'] = $email['value'];
                    break;
                }
            }
        }

        return parent::_prepareData($data);
    }

    /**
     * @param        $url
     * @param array  $params
     * @param string $method
     * @param null   $curlResource
     * @return bool|string|null
     */
    protected function _call($url, $params = [], $method = self::METHOD_GET, $curlResource = null)
    {
        $curlResource = curl_init();

        if ($method == self::METHOD_POST) {
            curl_setopt($curlResource, CURLOPT_CUSTOMREQUEST, self::METHOD_POST);
            curl_setopt(
                $curlResource,
                CURLOPT_HTTPHEADER,
                ['Authorization: Basic ' . base64_encode($this->applicationId . ':' . $this->secret)]
            );
        } else {
            // GET.
            curl_setopt($curlResource, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $params['access_token']]);
            $params = [];
        }

        return parent::_call($url, $params, $method, $curlResource);
    }
}
