<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model\Buttons;

class Preparer
{
    /**
     * @param array $buttons
     * @param array $sortableParams
     * @param bool  $splitByVisibility
     * @return array
     */
    public function prepareSortAndVisibility(array $buttons, array $sortableParams, $splitByVisibility = true)
    {
        if (empty($sortableParams) || empty($buttons)) {
            $buttons = ! empty($buttons)
                ? $this->markButtons($buttons, true)
                : $buttons;

            if (! $splitByVisibility) {
                return $buttons;
            }

            return ['visible' => $buttons, 'hidden' => []];
        }

        $preparedButtons = ['visible' => [], 'hidden' => []];
        foreach ($sortableParams as $partName => $partButtons) {
            foreach ($partButtons as $button) {
                if (isset($buttons[$button])) {
                    $preparedButtons[$partName][$button] = $buttons[$button];
                    unset($buttons[$button]);
                }
            }
        }

        // If has not sortable enabled buttons.
        if (! empty($buttons)) {
            $preparedButtons['visible'] = array_merge($preparedButtons['visible'], $buttons);
        }

        $preparedButtons['visible'] = $this->markButtons($preparedButtons['visible'], true);
        $preparedButtons['hidden'] = $this->markButtons($preparedButtons['hidden'], false);

        if (! $splitByVisibility) {
            return array_merge($preparedButtons['visible'], $preparedButtons['hidden']);
        }

        return $preparedButtons;
    }

    /**
     * @param array $preparedButtonsPart
     * @param bool $visible
     * @return array
     */
    private function markButtons(array $preparedButtonsPart, $visible)
    {
        $preparedButtonsPart = array_map(
            static function ($button) use ($visible) {
                $button['visible'] = $visible;
                return $button;
            },
            $preparedButtonsPart
        );
        return $preparedButtonsPart;
    }
}
