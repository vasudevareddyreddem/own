<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model\Buttons;

abstract class AbstractProvider implements \Plumrocket\SocialLoginPro\Api\Buttons\ProviderInterface
{
    /**
     * @var \Plumrocket\SocialLoginPro\Model\Config\Provider
     */
    protected $configProvider;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\Buttons\Factory
     */
    protected $buttonsFactory;

    /**
     * @var \Plumrocket\SocialLoginPro\Api\TypesProviderInterface
     */
    protected $typesProvider;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\Buttons\Preparer
     */
    protected $preparer;

    /**
     * @var array[]
     */
    protected $buttonsCache = [];

    /**
     * AbstractProvider constructor.
     *
     * @param \Plumrocket\SocialLoginPro\Model\Config\Provider      $configProvider
     * @param \Plumrocket\SocialLoginPro\Model\Buttons\Factory      $buttonsFactory
     * @param \Plumrocket\SocialLoginPro\Api\TypesProviderInterface $typesProvider
     * @param \Plumrocket\SocialLoginPro\Model\Buttons\Preparer     $preparer
     */
    public function __construct(
        \Plumrocket\SocialLoginPro\Model\Config\Provider $configProvider,
        \Plumrocket\SocialLoginPro\Model\Buttons\Factory $buttonsFactory,
        \Plumrocket\SocialLoginPro\Api\TypesProviderInterface $typesProvider,
        \Plumrocket\SocialLoginPro\Model\Buttons\Preparer $preparer
    ) {
        $this->configProvider = $configProvider;
        $this->buttonsFactory = $buttonsFactory;
        $this->typesProvider = $typesProvider;
        $this->preparer = $preparer;
    }

    /**
     * {@inheritDoc}
     */
    public function getButtons($onlyEnabled = true, $storeId = null, $forceReload = false)
    {
        $cacheKey = $this->getCacheKey([$onlyEnabled, $storeId]);

        if ($forceReload || ! isset($this->buttonsCache[$cacheKey])) {
            $types = $onlyEnabled
                ? $this->typesProvider->getEnabledList($storeId)
                : $this->typesProvider->getAll($storeId);

            $this->buttonsCache[$cacheKey] = $this->buttonsFactory->create($types);
        }

        return $this->buttonsCache[$cacheKey];
    }

    /**
     * Get key for cache
     *
     * @param array $data
     * @return string
     */
    protected function getCacheKey($data)
    {
        $serializeData = [];
        foreach ($data as $key => $value) {
            if (is_object($value)) {
                $serializeData[$key] = $value->getId();
            } else {
                $serializeData[$key] = $value;
            }
        }
        $serializeData = json_encode($serializeData);
        return sha1($serializeData);
    }
}
