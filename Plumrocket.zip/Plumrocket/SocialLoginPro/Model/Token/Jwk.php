<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Model\Token;

use Magento\Framework\Encryption\UrlCoder;
use Plumrocket\SocialLoginPro\Api\JwkProviderInterface;

class Jwk
{
    /**
     * @var array
     */
    private $jwkProviders = [];

    /**
     * @var string
     */
    private $type;

    /**
     * @var UrlCoder
     */
    private $urlCoder;

    /**
     * Jwk constructor.
     *
     * @param UrlCoder $urlCoder
     * @param array $jwkProviders
     */
    public function __construct(UrlCoder $urlCoder, array $jwkProviders)
    {
        $this->jwkProviders = $jwkProviders;
        $this->urlCoder = $urlCoder;
    }

    /**
     * @param string $keyId
     * @param string $type
     * @return string
     */
    public function parseKey(string $keyId, string $type)
    {
        $jwk = $this->getJwk($keyId, $type);

        if (empty($jwk)) {
            throw new \InvalidArgumentException('JWK must not be empty');
        }

        if (! isset($jwk['kty'])) {
            throw new \UnexpectedValueException('JWK must contain a "kty" parameter');
        }

        if (array_key_exists('d', $jwk)) {
            throw new \UnexpectedValueException('RSA private keys are not supported');
        }

        if (! isset($jwk['n']) || ! isset($jwk['e'])) {
            throw new \UnexpectedValueException('RSA keys must contain values for both "n" and "e"');
        }

        $pemKey = $this->createPemFromModulusAndExponent($jwk['n'], $jwk['e']);

        return \openssl_pkey_get_public($pemKey);
    }

    /**
     * @param string $keyId
     * @param string $type
     * @return array
     */
    private function getJwk(string $keyId, string $type): array
    {
        if (! isset($this->jwkProviders[$type]) || !($this->jwkProviders[$type] instanceof JwkProviderInterface)) {
            throw new \InvalidArgumentException('JWK provider is not exists for "' . $type . '" type');
        }

        return $this->jwkProviders[$type]->get($keyId);
    }

    /**
     * @param $n
     * @param $e
     * @return false|string
     */
    private function createPemFromModulusAndExponent($n, $e)
    {
        $modulus = $this->urlCoder->decode($n);
        $publicExponent = $this->urlCoder->decode($e);

        $components = [
            'modulus' => \pack('Ca*a*', 2, $this->encodeLength(\strlen($modulus)), $modulus),
            'publicExponent' => \pack('Ca*a*', 2, $this->encodeLength(\strlen($publicExponent)), $publicExponent)
        ];

        $rsaPublicKey = \pack(
            'Ca*a*a*',
            48,
            $this->encodeLength(\strlen($components['modulus']) + \strlen($components['publicExponent'])),
            $components['modulus'],
            $components['publicExponent']
        );

        // sequence(oid(1.2.840.113549.1.1.1), null)) = rsaEncryption.
        $rsaOID = \pack('H*', '300d06092a864886f70d0101010500'); // hex version of MA0GCSqGSIb3DQEBAQUA
        $rsaPublicKey = \chr(0) . $rsaPublicKey;
        $rsaPublicKey = \chr(3) . $this->encodeLength(\strlen($rsaPublicKey)) . $rsaPublicKey;

        $rsaPublicKey = \pack(
            'Ca*a*',
            48,
            $this->encodeLength(\strlen($rsaOID . $rsaPublicKey)),
            $rsaOID . $rsaPublicKey
        );

        $rsaPublicKey = "-----BEGIN PUBLIC KEY-----\r\n" .
            \chunk_split(\base64_encode($rsaPublicKey), 64) .
            '-----END PUBLIC KEY-----';

        return $rsaPublicKey;
    }

    /**
     * @param $length
     * @return false|string
     */
    private function encodeLength($length)
    {
        if ($length <= 0x7F) {
            return \chr($length);
        }

        $temp = \ltrim(\pack('N', $length), \chr(0));

        return \pack('Ca*', 0x80 | \strlen($temp), $temp);
    }
}
