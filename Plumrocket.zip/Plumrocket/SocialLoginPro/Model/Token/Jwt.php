<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Model\Token;

use Magento\Framework\Encryption\UrlCoder;
use Magento\Framework\Serialize\SerializerInterface;

class Jwt
{
    /**
     * @var SerializerInterface
     */
    private $jsonSerializer;

    /**
     * @var array
     */
    private $supportedAlgs = [
        'RS256' => 'SHA256',
    ];

    /**
     * @var UrlCoder
     */
    private $urlCoder;

    /**
     * @var Jwk
     */
    private $jwkParser;

    /**
     * Jwt constructor.
     *
     * @param SerializerInterface $jsonSerializer
     * @param UrlCoder $urlCoder
     * @param Jwk $jwkParser
     */
    public function __construct(SerializerInterface $jsonSerializer, UrlCoder $urlCoder, Jwk $jwkParser)
    {
        $this->jsonSerializer = $jsonSerializer;
        $this->urlCoder = $urlCoder;
        $this->jwkParser = $jwkParser;
    }

    /**
     * Currently only RSA is supported
     *
     * @inheritDoc
     */
    public function unserialize($token, $key = '', $type = '')
    {
        list($headBase64, $payloadBase64, $signatureBase64) = explode('.', $token);

        $headJson = $this->urlCoder->decode($headBase64);
        $head = $this->jsonSerializer->unserialize($headJson);
        $payloadJson = $this->urlCoder->decode($payloadBase64);
        $payload = $this->jsonSerializer->unserialize($payloadJson);
        $signature = $this->urlCoder->decode($signatureBase64);

        if (isset($head['kid'])) {
            $key = $this->jwkParser->parseKey($head['kid'], $type);
        }

        if (! $this->verify($headBase64 . '.' . $payloadBase64, $signature, $key, $head['alg'])) {
            throw new \InvalidArgumentException('JWT signature verification failed');
        }

        return $payload;
    }

    /**
     * @param string $msg
     * @param resource|string $key
     * @param string $algorithm
     * @return string
     */
    private function verify(string $message, string $signature, $key, string $algorithm): string
    {
        if (! isset($this->supportedAlgs[$algorithm])) {
            throw new \InvalidArgumentException('Algorithm "' . $algorithm . '" is not supported');
        }

        $success = \openssl_verify($message, $signature, $key, $this->supportedAlgs[$algorithm]);

        if (! $success) {
            throw new \DomainException('OpenSSL unable to sign data');
        }

        return $signature;
    }
}
