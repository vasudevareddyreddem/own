<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Model\Token;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Exception\FileSystemException;

class Apple
{
    const APPLE_CONFIG_PATH = 'psloginpro/apple';
    const APPLE_REQUIRED_HEADERS = ['key_id' => 'kid'];
    const APPLE_REQUIRED_BODY = ['team_id' => 'iss', 'application_id' => 'sub'];
    const APPLE_ALGORITHM = 'ES256';
    const APPLE_AUD = 'https://appleid.apple.com';

    /**
     * @var \Magento\Framework\Filesystem\DriverInterface $driver
     */
    private $driver;

    /**
     * @var \Magento\Framework\Filesystem\DirectoryList $directory
     */
    private $directory;

    /**
     * @var \Magento\Framework\App\Config\Storage\WriterInterface
     */
    private $configWriter;

    /**
     * @var \Magento\Framework\Encryption\EncryptorInterface
     */
    private $encryptor;

    /**
     * @var @param \Plumrocket\SocialLoginPro\Helper\Config $helper
     */
    private $helper;

    /**
     * @var \Magento\Framework\Url\Encoder
     */
    private $urlEncoder;

    /**
     * Apple constructor.
     *
     * @param \Magento\Framework\Filesystem\DriverInterface         $driver
     * @param \Magento\Framework\Filesystem\DirectoryList           $directory
     * @param \Magento\Framework\App\Config\Storage\WriterInterface $configWriter
     * @param \Magento\Framework\Encryption\EncryptorInterface      $encryptor
     * @param \Plumrocket\SocialLoginPro\Helper\Config              $helper
     * @param \Magento\Framework\Url\Encoder                        $urlEncoder
     */
    public function __construct(
        \Magento\Framework\Filesystem\DriverInterface $driver,
        \Magento\Framework\Filesystem\DirectoryList $directory,
        \Magento\Framework\App\Config\Storage\WriterInterface $configWriter,
        \Magento\Framework\Encryption\EncryptorInterface $encryptor,
        \Plumrocket\SocialLoginPro\Helper\Config $helper,
        \Magento\Framework\Url\Encoder $urlEncoder
    ) {
        $this->driver = $driver;
        $this->directory = $directory;
        $this->configWriter = $configWriter;
        $this->encryptor = $encryptor;
        $this->helper = $helper;
        $this->urlEncoder = $urlEncoder;
    }

    /**
     * Generate Apple Secret
     *
     * @param null $key
     * @return $this
     */
    public function generateSecret($key = null)
    {
        $key = $key ?: $this->getKey();

        if (!$this->credentialsExists() || !$key) {
            return $this;
        }

        $headers = $this->setHeaders(self::APPLE_REQUIRED_HEADERS);
        $body = $this->setBody(self::APPLE_REQUIRED_BODY);

        $data = $this->urlEncoder->encode(json_encode($headers)) . '.' . $this->urlEncoder->encode(json_encode($body));

        $signature = $this->getSignature($data, $key);

        $clientSecret = $this->encryptor->encrypt($data . '.' . $signature);
        $this->configWriter->save(
            self::APPLE_CONFIG_PATH . '/secret',
            $clientSecret,
            ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
            0
        );

        return $this;
    }

    /**
     * @return bool|string
     */
    private function getKey()
    {
        if (!$keyPath = $this->helper->getConfig(self::APPLE_CONFIG_PATH . '/key_file')) {
            return false;
        }

        try {
            $directory = $this->directory->getPath(DirectoryList::MEDIA);
            $file = $directory . '/pslogin/apple/' . $keyPath;
            $this->driver->isExists($file);
            $key = $this->driver->fileGetContents($file);
        } catch (FileSystemException $e) {
            $key = false;
        }

        return openssl_pkey_get_private($key) ? $key : false;
    }

    /**
     * Set Headers
     *
     * @param array $headers
     * @return array
     */
    private function setHeaders($headers)
    {
        $data = [];
        foreach ($headers as $key => $param) {
            $value = $this->helper->getConfig(self::APPLE_CONFIG_PATH . '/' . $key);
            $data[$param] = $key === 'key_id' ? $this->encryptor->decrypt($value) : $value;
        }

        $data['alg'] = self::APPLE_ALGORITHM;

        return $data;
    }

    /**
     * Check if required headers is set
     *
     * @return boolean
     */
    private function isHeadersExists()
    {
        foreach (self::APPLE_REQUIRED_HEADERS as $key => $param) {
            if (!$this->helper->getConfig(self::APPLE_CONFIG_PATH . '/' . $key)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Set body
     *
     * @param array $body
     * @return array
     */
    private function setBody($body)
    {
        $data = [];
        foreach ($body as $key => $param) {
            $value = $this->helper->getConfig(self::APPLE_CONFIG_PATH . '/' . $key);
            $data[$param] = $key === 'team_id' ? $this->encryptor->decrypt($value) : $value;
        }

        $data['aud'] = self::APPLE_AUD;
        $data['iat'] = time();
        $data['exp'] = time() + 86400 * 180;

        return $data;
    }

    /**
     * Check if required body is set
     *
     * @return boolean
     */
    private function isBodyExists()
    {
        foreach (self::APPLE_REQUIRED_BODY as $key => $param) {
            if (!$this->helper->getConfig(self::APPLE_CONFIG_PATH . '/' . $key)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Get Signature
     *
     * @param string $data
     * @param resource $key
     * @return string
     */
    private function getSignature($data, $key)
    {
        $signature = '';
        openssl_sign($data, $signature, $key, OPENSSL_ALGO_SHA256);
        $signature = $this->opensslRemoveDERExtraData($signature);
        return $this->urlEncoder->encode($signature);
    }

    /**
     * Check if credentials exists
     *
     * @return boolean
     */
    private function credentialsExists()
    {
        return $this->isHeadersExists() && $this->isBodyExists();
    }

    /**
     * The signature returned by OpenSSL is an ASN.1 sequence that contains additional information.
     * You have to remove the extra data before concatenation.
     * DER = Distinguished Encoding Rules
     *
     * @param string $signature
     * @return string
     */
    private function opensslRemoveDERExtraData($signature)
    {
        $partLength = 64;
        $hex = unpack('H*', $signature)[1];
        if ('30' !== mb_substr($hex, 0, 2, '8bit')) { // SEQUENCE
            throw new \RuntimeException();
        }
        if ('81' === mb_substr($hex, 2, 2, '8bit')) { // LENGTH > 128
            $hex = mb_substr($hex, 6, null, '8bit');
        } else {
            $hex = mb_substr($hex, 4, null, '8bit');
        }
        if ('02' !== mb_substr($hex, 0, 2, '8bit')) { // INTEGER
            throw new \RuntimeException();
        }
        $decimalHexStr = hexdec(mb_substr($hex, 2, 2, '8bit'));
        $relativePositiveInt = $this->retrievePositiveInteger(mb_substr($hex, 4, $decimalHexStr * 2, '8bit'));
        $leftPadStr = str_pad($relativePositiveInt, $partLength, '0', STR_PAD_LEFT);
        $hex = mb_substr($hex, 4 + $decimalHexStr * 2, null, '8bit');
        if ('02' !== mb_substr($hex, 0, 2, '8bit')) { // INTEGER
            throw new \RuntimeException();
        }
        $decimalHexString = hexdec(mb_substr($hex, 2, 2, '8bit'));
        $relativePositiveInt = $this->retrievePositiveInteger(mb_substr($hex, 4, $decimalHexString * 2, '8bit'));
        $rightPadStr = str_pad($relativePositiveInt, $partLength, '0', STR_PAD_LEFT);

        return pack('H*', $leftPadStr . $rightPadStr);
    }

    /**
     * Retrive Positive Integer
     *
     * @param string $data
     * @return string
     */
    private function retrievePositiveInteger($data)
    {
        while ('00' === mb_substr($data, 0, 2, '8bit') && mb_substr($data, 2, 2, '8bit') > '7f') {
            $data = mb_substr($data, 2, null, '8bit');
        }
        return $data;
    }
}
