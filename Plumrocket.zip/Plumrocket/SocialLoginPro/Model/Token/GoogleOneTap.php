<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Model\Token;

use Magento\Framework\HTTP\Client\CurlFactory;
use Magento\Framework\Serialize\SerializerInterface;
use Plumrocket\SocialLoginPro\Api\JwkProviderInterface;

class GoogleOneTap implements JwkProviderInterface
{
    const ENDPOINT = 'https://www.googleapis.com/oauth2/v3/certs';

    /**
     * @var SerializerInterface
     */
    private $jsonSerializer;

    /**
     * @var CurlFactory
     */
    private $curlFactory;

    /**
     * GoogleOnetap constructor.
     *
     * @param CurlFactory $curlFactory
     * @param SerializerInterface $jsonSerializer
     */
    public function __construct(CurlFactory $curlFactory, SerializerInterface $jsonSerializer)
    {
        $this->jsonSerializer = $jsonSerializer;
        $this->curlFactory = $curlFactory;
    }

    /**
     * @param null $keyId
     * @return array
     * @throws \Magento\Framework\Exception\FileSystemException
     * @throws \Magento\Framework\Exception\NotFoundException
     */
    public function get($keyId = null): array
    {
        /** @var \Magento\Framework\HTTP\Client\Curl $curl */
        $curl = $this->curlFactory->create();
        $curl->get(self::ENDPOINT);
        $content = $curl->getBody();
        $content = $this->jsonSerializer->unserialize($content);

        foreach ($content['keys'] as $key) {
            if ($key['kid'] === $keyId) {
                return $key;
            }
        }

        throw new \Magento\Framework\Exception\NotFoundException(__('Key Id is not valid'));
    }
}
