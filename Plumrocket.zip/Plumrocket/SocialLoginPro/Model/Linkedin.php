<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model;

use Magento\Framework\Encryption\Encryptor;

/**
 * Class Linkedin
 *
 * @package Plumrocket\SocialLoginPro\Model
 */
class Linkedin extends Account
{
    /**
     * @var string
     */
    const METHOD_POST = 'POST';

    /**
     * @var string
     */
    const METHOD_GET = 'GET';

    /**
     * @var string
     */
    protected $type = 'linkedin';

    /**
     * @var string
     */
    protected $url = 'https://www.linkedin.com/oauth/v2/authorization';

    /**
     * @var array
     */
    protected $fieldsToResponse = [
        'user_id'        => 'id',
        'firstname'      => 'first-name',
        'lastname'       => 'last-name',
        'email'          => 'email-address',
        'photo'          => 'picture-url',
        'additional_url' => 'public-profile-url',
    ];

    /**
     * @var array
     */
    protected $fields = [
        'user_id'   => 'id',
        'firstname' => 'firstName',
        'lastname'  => 'lastName',
        'email'     => 'emailAddress',
        'dob'       => null,
        'gender'    => null,
        'photo'     => 'pictureUrl',
    ];

    /**
     * @var array
     */
    protected $buttonLinkParams = [
        'scope' => 'r_liteprofile,r_emailaddress',
        'state' => 'popup',
    ];

    /**
     * @var array
     */
    protected $popupSize = [400, 550];

    /**
     * Access Token
     */
    private $accessToken;

    /**
     * LinkedIn Construct
     */
    public function _construct()
    {
        parent::_construct();

        $state = $this->encryptor->hash(uniqid(rand(), true), Encryptor::HASH_VERSION_MD5);

        $this->buttonLinkParams = array_merge($this->buttonLinkParams, [
            'client_id'     => $this->applicationId,
            'redirect_uri'  => $this->redirectUri,
            'response_type' => $this->responseType,
            'state'         => $state,
            'grant_type'    => 'client_credentials',
            'client_secret' => $this->secret,
        ]);
    }

    /**
     * @param $response
     * @return bool
     */
    public function loadUserData($response)
    {
        if (empty($response)) {
            return false;
        }

        $data = [];

        $params = [
            'grant_type' => 'authorization_code',
            'code' => $response,
            'redirect_uri' => $this->redirectUri,
            'client_id' => $this->applicationId,
            'client_secret' => $this->secret,
        ];

        $token = null;

        if ($response = $this->_call('https://www.linkedin.com/oauth/v2/accessToken', $params, self::METHOD_POST)) {
            $token = json_decode($response, true);
        }

        if (isset($token['access_token'])) {
            $this->accessToken = $token['access_token'];

            $email = json_decode(
                $this->_call('https://api.linkedin.com/v2/emailAddress?q=members&projection=(elements*(handle~))'),
                true
            );

            if (isset($email['elements'][0]['handle~']['emailAddress'])) {
                $this->email = $email['elements'][0]['handle~']['emailAddress'];
            }

            if ($response = $this->_call('https://api.linkedin.com/v2/me')) {
                $data = json_decode($response, true);
            }

            $this->_setLog($data, true);
        }

        if (! is_array($data)) {
            $data = [];
        }

        if (! $this->userData = $this->_prepareData($data)) {
            return false;
        }

        if (isset($data['localizedFirstName'])) {
            $this->userData['firstname'] = $data['localizedFirstName'];
        }

        if (isset($data['localizedLastName'])) {
            $this->userData['lastname'] = $data['localizedLastName'];
        }

        $photoUrl = json_decode($this->_call(
            'https://api.linkedin.com/v2/me?projection=(id,profilePicture(displayImage~:playableStreams))'),
            true
        );

        if(isset($photoUrl['profilePicture']['displayImage~']['elements'][0]['identifiers'][0]['identifier'])) {
            $this->userData['photo'] =
                $photoUrl['profilePicture']['displayImage~']['elements'][0]['identifiers'][0]['identifier'];
        }

        $this->userData['email'] = $this->email;
        $this->_setLog($this->userData, true);

        return true;
    }

    /**
     * @param $data
     * @return array|bool
     */
    protected function _prepareData($data)
    {
        if (empty($data['id'])) {
            return false;
        }

        if (isset($data['publicProfileUrl'])) {
            $this->addAdditionalData('url', $data['publicProfileUrl']);
        }

        return parent::_prepareData($data);
    }

    /**
     * {@inheritdoc}
     */
    public function getSocialUrl()
    {
        if (null !== $this->getData('additional/url')) {
            return $this->getData('additional/url');
        }

        return null;
    }

    /**
     * @param        $url
     * @param array  $params
     * @param string $method
     * @param null   $curlResource
     * @return bool|string|null
     */
    protected function _call($url, $params = [], $method = self::METHOD_GET, $curlResource = null)
    {
        $curlResource = curl_init();

        if ($method == self::METHOD_POST) {
            curl_setopt($curlResource, CURLOPT_CUSTOMREQUEST, self::METHOD_POST);
            curl_setopt(
                $curlResource,
                CURLOPT_HTTPHEADER,
                ['Content-Type: ' . 'application/x-www-form-urlencoded']
            );
        } else {
            // GET.
            curl_setopt($curlResource, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $this->accessToken]);
            $params = [];
        }

        return parent::_call($url, $params, $method, $curlResource);
    }
}
