<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Model;

class Yahoo extends Account
{
    protected $type = 'yahoo';
    protected $_scope = 'openid+profile';
    protected $dob = ['year', 'month', 'day', '-'];

    protected $responseType = 'code';
    protected $url = 'https://api.login.yahoo.com/oauth2/request_auth';

    protected $fields = [
        'user_id' => 'sub',
        'firstname' => 'given_name',
        'lastname' => 'family_name',
        'email' => 'email',
        'dob' => 'birthdate',
        'photo' => 'picture',
    ];

    protected $popupSize = [650, 800];

    public function _construct()
    {
        parent::_construct();

        $this->buttonLinkParams = [
            'client_id'     => $this->applicationId,
            'redirect_uri'  => $this->redirectUri,
            'response_type' => $this->responseType,
            'language'      => 'en-us'
        ];
    }

    /**
     * @param $response
     * @return bool
     */
    public function loadUserData($response): bool
    {
        if (empty($response)) {
            $responseParams = $this->request->getParams();
            if (isset($responseParams['error']) && $responseParams['error'] === 'access_denied') {
                $this->_registry->register('close_popup', true);
            }

            return false;
        }

        $data = [];

        $params = [
            'client_id' => $this->applicationId,
            'client_secret' => $this->secret,
            'redirect_uri' => $this->redirectUri,
            'code' => $response,
            'grant_type' => 'authorization_code'
        ];

        $token = null;
        if ($response = $this->makePostCall('https://api.login.yahoo.com/oauth2/get_token', $params)) {
            $token = $this->serializer->unserialize($response);
        }

        $customerData = [];

        if (isset($token['access_token'])) {
            $url = 'https://api.login.yahoo.com/openid/v1/userinfo/';

            $response = $this->makeGetCall(
                $url,
                [],
                CURLOPT_HTTPHEADER,
                ['Authorization: Bearer ' . $token['access_token']]
            );

            if ($response && $customerData = $this->serializer->unserialize($response)) {
                if (is_array($customerData) && isset($customerData['profile'])) {
                    $customerData = $customerData['profile'];
                }
            }
        }

        if (! $this->userData = $this->_prepareData($customerData)) {
            return false;
        }

        $this->_setLog($this->userData, true);

        return true;
    }

    /**
     * @param $url
     * @param $params
     * @return array
     */
    protected function _prepareParams($url, $params): array
    {
        return ['url' => $url, 'params' => http_build_query($params)];
    }

    /**
     * @param $data
     * @return array|false
     */
    protected function _prepareData($data)
    {
        if (empty($data['sub'])) {
            return false;
        }

        return parent::_prepareData($data);
    }
}
