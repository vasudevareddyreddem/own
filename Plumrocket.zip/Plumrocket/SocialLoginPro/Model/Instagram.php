<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model;

class Instagram extends Account
{
    const URL_ACCESS_TOKEN = 'https://api.instagram.com/oauth/access_token';
    const URL_ACCOUNT_DATA = 'https://graph.instagram.com/';

    /**
     * @var string
     */
    protected $type = 'instagram';

    /**
     * @var string
     */
    protected $url = 'https://api.instagram.com/oauth/authorize';

    /**
     * @var string[]
     */
    protected $fields = [
        'user_id' => 'id',
        'firstname' => 'full_name_fn',
        'lastname' => 'full_name_ln',
        'email' => 'email',
        'dob' => '',
        'gender' => '',
        'photo' => 'profile_picture',
    ];

    /**
     * @var array
     */
    protected $dob = [];

    /**
     * @var array
     */
    protected $gender = [];

    /**
     * @var string[]
     */
    protected $buttonLinkParams = [
        'scope' => 'user_profile,user_media',
    ];

    /**
     * @var int[]
     */
    protected $popupSize = [500, 350];

    /**
     * Instagram construct
     */
    public function _construct()
    {
        parent::_construct();

        $this->buttonLinkParams = array_merge($this->buttonLinkParams, [
            'client_id'     => $this->applicationId,
            'redirect_uri'  => $this->redirectUri,
            'response_type' => 'code'
        ]);
    }

    /**
     * @param $response
     * @return bool
     */
    public function loadUserData($response)
    {
        $data = [];

        $params = [
            'client_id' => $this->applicationId,
            'client_secret' => $this->secret,
            'code' => $response,
            'redirect_uri' => $this->redirectUri,
            'grant_type' => 'authorization_code',
        ];

        $token = null;

        if ($response = $this->_callPost(self::URL_ACCESS_TOKEN, $params)) {
            $token = json_decode($response, true);
        }
        $this->_setLog($token, true);

        if (isset($token['access_token']) && isset($token['user_id'])) {
            $calledData = $this->_call($this->prepareGetParams($token['user_id'], $token['access_token']));
            $data = json_decode($calledData,true);
        }

        if (!$this->userData = $this->_prepareData($data)) {
            return false;
        }

        $this->_setLog($this->userData, true);

        return true;
    }

    /**
     * @param $data
     * @return array|bool
     */
    protected function _prepareData($data)
    {
        if (empty($data['id'])) {
            return false;
        }

        // Name.
        if (!empty($data['username'])) {
            $nameParts = explode(' ', $data['username'], 2);
            $data['full_name_fn'] = $nameParts[0];
            $data['full_name_ln'] = !empty($nameParts[1])? $nameParts[1] : '';
        }

        return parent::_prepareData($data);
    }

    /**
     * @param $url
     * @param array $params
     * @return bool|string
     */
    protected function _callPost($url, $params = [])
    {
        $this->_setLog($url, true, true);

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_USERPWD, $this->applicationId .':'. $this->secret);
        curl_setopt($curl, CURLOPT_POSTFIELDS, urldecode(http_build_query($params)));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($curl);

        if ($errno = curl_errno($curl)) {
            $this->_setLog(curl_getinfo($curl), true, true);
            $this->_setLog(curl_error($curl), true, true);
        }

        curl_close($curl);

        return $result;
    }

    /**
     * @param $userId
     * @param $accessToken
     * @return string
     */
    private function prepareGetParams($userId, $accessToken)
    {
        $url = self::URL_ACCOUNT_DATA;
        $url .= $userId;
        $url .= '?fields=id,username,media_count,account_type';
        $url .= '&access_token=' . $accessToken;

        return $url;
    }
}
