<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2017 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model;

use Magento\Framework\Encryption\Encryptor;

class Bitly extends Account
{
    protected $type = 'bitly';

    protected $responseType = ['code', 'state'];
    protected $url = 'https://bitly.com/oauth/authorize';

    protected $fields = [
                    'user_id' => 'login',
                    'firstname' => 'name_fn',
                    'lastname' => 'name_ln',
                    'email' => 'email', // empty
                    'dob' => 'birthday', // empty
                    'gender' => 'gender', // empty
                    'photo' => 'profile_image',
                ];

    protected $buttonLinkParams = [
                    'scope' => '',
                ];

    protected $popupSize = [850, 550];

    public function _construct()
    {
        parent::_construct();

        $this->buttonLinkParams = array_merge($this->buttonLinkParams, [
            'client_id'     => $this->applicationId,
            'redirect_uri'  => $this->redirectUri,
            'response_type' => $this->responseType[0],
            'state'         => $this->encryptor->hash(rand(), Encryptor::HASH_VERSION_MD5),
        ]);
    }

    public function loadUserData($response)
    {
        if (empty($response['code']) || empty($response['state'])) {
            return false;
        }

        $data = [];

        $params = [
            'client_id' => $this->applicationId,
            'client_secret' => $this->secret,
            'redirect_uri' => $this->redirectUri,
            'code' => $response['code'],
            'state' => $response['state'],
            'grant_type' => 'authorization_code',
        ];

        $token = null;
        if ($result = $this->_callPost('https://api-ssl.bitly.com/oauth/access_token', $params)) {
            parse_str($result, $token);
        }
        $this->_setLog($token, true);

        if (isset($token['access_token'])) {
            $params = [
                'access_token' => $token['access_token'],
            ];

            if ($response = $this->_callGet('https://api-ssl.bitly.com/v3/user/info', $params)) {
                $data = json_decode($response, true);
            }
            $this->_setLog($data, true);
        }

        if (!$this->userData = $this->_prepareData($data)) {
            return false;
        }

        $this->_setLog($this->userData, true);

        return true;
    }

    protected function _prepareData($data)
    {
        if (empty($data['data']['login'])) {
            return false;
        }

        $data = $data['data'];

        // Name.
        $name = $data['login'];
        if (!empty($data['full_name'])) {
            $name = $data['full_name'];
        } elseif (!empty($data['display_name'])) {
            $name = $data['display_name'];
        }

        $nameParts = explode(' ', $name, 2);
        $data['name_fn'] = $nameParts[0];
        $data['name_ln'] = !empty($nameParts[1])? $nameParts[1] : '';

        return parent::_prepareData($data);
    }

    protected function _callGet($url, $params = [])
    {
        if (is_array($params) && $params) {
            $url .= '?'. urldecode(http_build_query($params));
        }

        $this->_setLog($url, true, true);

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);

        // curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 3);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        // curl_setopt($curl, CURLOPT_USERAGENT, 'pslogin');

        $result = curl_exec($curl);

        if ($errno = curl_errno($curl)) {
            $this->_setLog(curl_getinfo($curl), true, true);
            $this->_setLog(curl_error($curl), true, true);
        }

        curl_close($curl);

        return $result;
    }

    protected function _callPost($url, $params = [])
    {
        $this->_setLog($url, true, true);
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, 1);

        curl_setopt($curl, CURLOPT_POSTFIELDS, urldecode(http_build_query($params)));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($curl);

        if ($errno = curl_errno($curl)) {
            $this->_setLog(curl_getinfo($curl), true, true);
            $this->_setLog(curl_error($curl), true, true);
        }

        curl_close($curl);

        return $result;
    }
}
