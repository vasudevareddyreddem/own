<?php
/**
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2017 Plumrocket Inc. (https://plumrocket.com)
 * @license     https://plumrocket.com/license/  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model;

class Github extends Account
{
    protected $type = 'github';

    protected $url = 'https://github.com/login/oauth/authorize';

    protected $fields = [
        'user_id' => 'id',
        'firstname' => 'login_fn',
        'lastname' => 'login_ln',
        'email' => 'email',
        'dob' => 'birthday',
        'gender' => 'gender',
        'photo' => 'avatar_url',
    ];

    protected $buttonLinkParams = [
        'scope' => 'user:email',
    ];

    protected $popupSize = [750, 500];

    public function _construct()
    {
        parent::_construct();
        $this->buttonLinkParams = array_merge($this->buttonLinkParams, [
            'client_id'     => $this->applicationId,
            'redirect_uri'  => $this->redirectUri,
            'response_type' => $this->responseType,
        ]);
    }

    public function loadUserData($response)
    {
        if (empty($response)) {
            return false;
        }

        $params = [
            'client_id' => $this->applicationId,
            'client_secret' => $this->secret,
            'code' => $response,
            'redirect_uri' => $this->redirectUri
        ];

        $token = $this->getToken($params);
        $socialUserData = $this->getSocialUserData($token, $params);

        if (!$this->userData = $this->_prepareData($socialUserData)) {
            return false;
        }

        $this->_setLog($this->userData, true);
        return true;
    }

    /**
     * @param array $params
     * @return string
     */
    private function getToken(array $params): string
    {
        $response = $this->makePostCall('https://github.com/login/oauth/access_token', $params);
        if (! $response) {
            $this->_setLog('Getting token was fail', true);
            return '';
        }

        parse_str($response, $parsedData);
        $this->_setLog($parsedData, true);
        return $parsedData['access_token'] ?? '';
    }

    /**
     * @param string $token
     * @param array  $params
     * @return array
     */
    private function getSocialUserData(string $token, array $params): array
    {
        if (! $token) {
            return [];
        }

        $this->curl->addHeader('Authorization', 'token ' . $token);
        $this->curl->addHeader('Accept', 'application/vnd.github.v3+json');
        $this->curl->addHeader('User-Agent', 'pslogin');

        $jsonData = $this->makeGetCall('https://api.github.com/user', $params);
        if (! $jsonData) {
            return [];
        }

        $data = $this->serializer->unserialize($jsonData);
        $this->_setLog($data, true);
        return $data;
    }

    protected function _prepareData($data)
    {
        if (empty($data['id'])) {
            return false;
        }

        // Parse first and last names from login
        if (! empty($data['name'])) {
            $nameParts = explode(' ', $data['name'], 2);
            $data['login_fn'] = $nameParts[0];
            $data['login_ln'] = !empty($nameParts[1])? $nameParts[1] : '';
        } elseif (! empty($data['login'])) {
            $nameParts = explode(' ', $data['login'], 2);
            $data['login_fn'] = $nameParts[0];
            $data['login_ln'] = !empty($nameParts[1])? $nameParts[1] : '';
        }

        return parent::_prepareData($data);
    }
}
