<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Model;

class Dropbox extends Account
{
    /**
     * @var string
     */
    const ACCESS_DENIED = 'access_denied';

    /**
     * @var string
     */
    protected $type = 'dropbox';

    /**
     * @var string
     */
    protected $url = 'https://www.dropbox.com/oauth2/authorize';

    /**
     * @var array
     */
    protected $fields = [
                    'user_id' => 'account_id',
                    'firstname' => 'display_name_fn',
                    'lastname' => 'display_name_ln',
                    'email' => 'email',
                    'dob' => '',
                    'gender' => '',
                    'photo' => '',
                ];

    /**
     * @var array
     */
    protected $dob = [];

    /**
     * @var array
     */
    protected $gender = ['male', 'female'];

    /**
     * @var array
     */
    protected $buttonLinkParams = [
                    'scope' => '',
                ];

    /**
     * @var array
     */
    protected $popupSize = [650, 550];

    public function _construct()
    {
        parent::_construct();

        $this->buttonLinkParams = array_merge($this->buttonLinkParams, [
            'client_id'     => $this->applicationId,
            'redirect_uri'  => $this->redirectUri,
            'response_type' => $this->responseType
        ]);
    }

    public function loadUserData($response)
    {
        if (empty($response)) {
            $responseParams = $this->request->getParams();
            if (isset($responseParams['error']) && $responseParams['error'] === 'access_denied') {
                $this->_registry->register('close_popup', true);
            }

            return false;
        }

        $data = [];

        $params = [
            'client_id' => $this->applicationId,
            'client_secret' => $this->secret,
            'code' => $response,
            'redirect_uri' => $this->redirectUri,
            'grant_type' => 'authorization_code',
        ];

        $token = null;
        if ($response = $this->_callPost('https://api.dropboxapi.com/oauth2/token', $params)) {
            $token = json_decode($response, true);
        }

        $this->_setLog($token, true);

        if (isset($token['access_token'])) {
            $params = [
                'access_token' => $token['access_token']
            ];

            if ($response = $this->_callPost('https://api.dropboxapi.com/2/users/get_current_account', $params)) {
                $data = json_decode($response, true);
            }

            $this->_setLog($data, true);
        }

        if (!$this->userData = $this->_prepareData($data)) {
            return false;
        }

        $this->_setLog($this->userData, true);

        return true;
    }

    protected function _prepareData($data)
    {
        if (empty($data['account_id'])) {
            return false;
        }

        // Name.
        if (! empty($data['name'])) {
            $data['display_name_fn'] = $data['name']['given_name'];
            $data['display_name_ln'] = $data['name']['surname'];
        }

        return parent::_prepareData($data);
    }

    protected function _callPost($url, $params = [])
    {
        $this->_setLog($url, true, true);
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, 1);
        if (isset($params['access_token'])) {
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode(null));
            curl_setopt($curl, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $params['access_token']
            ]);
        } else {
            curl_setopt($curl, CURLOPT_POSTFIELDS, urldecode(http_build_query($params)));
        }

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($curl);

        if ($errno = curl_errno($curl)) {
            $this->_setLog(curl_getinfo($curl), true, true);
            $this->_setLog(curl_error($curl), true, true);
        }

        curl_close($curl);

        return $result;
    }
}
