<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

// @codingStandardsIgnoreFile

namespace Plumrocket\SocialLoginPro\Model;

class Facebook extends Account
{
    protected $type = 'facebook';

    protected $url = 'https://www.facebook.com/dialog/oauth';

    protected $fields = [
                    'user_id' => 'id',
                    'firstname' => 'first_name',
                    'lastname' => 'last_name',
                    'email' => 'email',
                    'dob' => 'birthday',
                    'gender' => 'gender',
                    'photo' => 'picture',
                ];

    protected $buttonLinkParams = [
                    'scope' => 'email',
                    'display' => 'popup',
                ];

    protected $popupSize = [650, 350];

    public function _construct()
    {
        parent::_construct();

        if ($this->helper->getConfig($this->helper->getConfigSectionId() . '/' . $this->type . '/enable_birthday')) {
            $this->buttonLinkParams['scope'] .= ',user_birthday';
        }

        $this->buttonLinkParams = array_merge($this->buttonLinkParams, [
            'client_id'     => $this->applicationId,
            'redirect_uri'  => $this->redirectUri,
            'response_type' => $this->responseType
        ]);
    }

    public function loadUserData($response)
    {
        if (empty($response)) {
            $responseParams = $this->request->getParams();
            if (isset($responseParams['error']) && $responseParams['error'] === "access_denied") {
                $this->_registry->register('close_popup', true);
            }

            return false;
        }

        $data = [];

        $params = [
            'client_id' => $this->applicationId,
            'client_secret' => $this->secret,
            'code' => $response,
            'redirect_uri' => $this->redirectUri
        ];

        $token = null;
        if ($response = $this->_call('https://graph.facebook.com/oauth/access_token', $params)) {
            try {
                $token = $this->serializer->unserialize($response);
            } catch (\InvalidArgumentException $e) {
                $token = null;
            }

            if (! $token) {
                parse_str($response, $token);
            }
        }

        $this->_setLog($token, true);

        if (isset($token['access_token'])) {
            $params = [
                'access_token'  => $token['access_token'],
                'fields'        => implode(',', $this->fields)
            ];

            if ($response = $this->_call('https://graph.facebook.com/me', $params)) {
                $data = json_decode($response, true);
            }

            if (!empty($data['id'])) {
                $data['picture'] = "https://graph.facebook.com/{$data['id']}/picture?" .
                    "access_token={$token['access_token']}";
            }

            $this->_setLog($data, true);
        }

        if (!$this->userData = $this->_prepareData($data)) {
            return false;
        }

        $this->_setLog($this->userData, true);

        return true;
    }

    protected function _prepareData($data)
    {
        if (empty($data['id'])) {
            return false;
        }

        return parent::_prepareData($data);
    }

    /**
     * Retrieve social url
     * @return string
     */
    public function getSocialUrl()
    {
        if ($id = $this->getUserId()) {
            return 'https://facebook.com/' . $id;
        }
        return null;
    }
}
