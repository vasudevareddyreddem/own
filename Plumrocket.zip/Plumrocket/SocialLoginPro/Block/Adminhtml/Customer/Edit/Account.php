<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2017 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Block\Adminhtml\Customer\Edit;

class Account extends \Magento\Backend\Block\Template
{
    /**
     * @var \Plumrocket\SocialLoginPro\Model\ResourceModel\Account\CollectionFactory
     */
    private $accountCollectionFactory;

    /**
     * @var \Plumrocket\SocialLoginPro\Helper\Data
     */
    private $dataHelper;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\AccountProviderInterface
     */
    private $accountProvider;

    /**
     * Account constructor.
     *
     * @param \Plumrocket\SocialLoginPro\Model\ResourceModel\Account\CollectionFactory $accountCollectionFactory
     * @param \Plumrocket\SocialLoginPro\Helper\Data                                   $dataHelper
     * @param \Magento\Backend\Block\Template\Context                                  $context
     * @param \Plumrocket\SocialLoginPro\Model\AccountProviderInterface                $accountProvider
     * @param array                                                                    $data
     */
    public function __construct(
        \Plumrocket\SocialLoginPro\Model\ResourceModel\Account\CollectionFactory $accountCollectionFactory,
        \Plumrocket\SocialLoginPro\Helper\Data $dataHelper,
        \Magento\Backend\Block\Template\Context $context,
        \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->dataHelper = $dataHelper;
        $this->accountCollectionFactory = $accountCollectionFactory;
        $this->accountProvider = $accountProvider;
    }

    /**
     * @return \Plumrocket\SocialLoginPro\Model\Account[]
     */
    public function getSocialAccounts()
    {
        $accounts = [];

        if ($customerId = $this->_request->getParam('id')) {
            $collection = $this->accountCollectionFactory->create()->addFieldToFilter('customer_id', $customerId);

            foreach ($collection as $account) {
                $model = $this->accountProvider->getByType($account->getType());

                $accounts[] = $model->setData($account->getData())
                    ->setPhoto($this->dataHelper->getPhotoPath(false, $customerId, $account->getType()));
            }
        }

        return $accounts;
    }
}
