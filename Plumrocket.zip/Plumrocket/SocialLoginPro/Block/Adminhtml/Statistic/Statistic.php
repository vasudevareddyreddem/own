<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2018 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Block\Adminhtml\Statistic;

class Statistic extends \Magento\Backend\Block\Template
{
    const GROUP_BY_DAY   = 'day';
    const GROUP_BY_MONTH = 'month';
    const GROUP_BY_YEAR  = 'year';

    /**
     * Account factory
     * @var \Plumrocket\SocialLoginPro\Model\AccountFactory
     */
    private $accountFactory;

    /**
     * @var null|array
     */
    private $statisticData = null;

    public function __construct(
        \Plumrocket\SocialLoginPro\Model\AccountFactory $accountFactory,
        \Magento\Backend\Block\Template\Context $context,
        array $data = []
    ) {
        $this->accountFactory = $accountFactory;
        parent::__construct($context, $data);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Statistics'));
        return parent::_prepareLayout();
    }

    /**
     * @return array
     */
    public function getStatisticData()
    {
        if (null === $this->statisticData) {
            $fromTime = $this->getDateForFilter('from');
            $toTime = $this->getDateForFilter('to');
            $dateRangeFormat = $this->getDateRangeFormat();

            $types = $this->accountFactory->create()->getCollection()
                ->addFieldToSelect('type')
                ->addFieldToSelect('created_at')
                ->addFieldToFilter(
                    'created_at',
                    [
                        'from' => $fromTime,
                        'to'   => $toTime
                    ]
                )
                ->addExpressionFieldToSelect('count', 'COUNT({{id}})', 'id');

            if ($dateRangeFormat[0] == self::GROUP_BY_YEAR) {
                $types->getSelect()->group(["YEAR(`created_at`)", 'type']);
            } elseif ($dateRangeFormat[0] == self::GROUP_BY_MONTH) {
                $types->getSelect()->group(["YEAR(`created_at`)", "MONTH(`created_at`)", 'type']);
            } else {
                $types->getSelect()->group(['created_at', 'type']);
            }

            $types->setOrder('created_at', 'ASC')->load();

            $data = [];
            foreach ($types as $type) {
                $type['created_at'] = $this->_localeDate->date($type['created_at'])->format($dateRangeFormat[1]);
                if (! isset($data['dates'][$type['created_at']])) {
                    $data['dates'][$type['created_at']] = ['created_at' => $type['created_at']];
                }

                if (! isset($data['types'][$type['type']])) {
                    $data['types'][$type['type']] = [
                        'type' => $type['type'],
                        'name'  => ucfirst($type['type']),
                        'dates' => []
                    ];
                }

                if (! isset($data['types'][$type['type']]['dates'][$type['created_at']])) {
                    $data['types'][$type['type']]['dates'][$type['created_at']] = [
                        'created_at' => $type['created_at'],
                        'count'      => $type['count']
                    ];
                } else {
                    $data['types'][$type['type']]['dates'][$type['created_at']]['count'] += $type['count'];
                }
            }
            $this->statisticData = $data;
        }

        return $this->statisticData;
    }

    /**
     * @return array|null
     */
    public function getPieData()
    {
        $data = [];
        $data['types'][] = ['Network', 'Registration'];
        if (! empty($this->statisticData)) {
            foreach ($this->statisticData['types'] as $value) {
                if (! isset($data['types'][$value['type']])) {
                    $count = 0;
                    foreach ($value['dates'] as $item) {
                        $count += $item['count'];
                    }
                    $data['types'][] = [$value['name'], $count];
                }
            }
            $period = '(' . date('M d, Y', strtotime($this->getFromTime())) . ' - '
                . date('M d, Y', strtotime($this->getToTime())) . ')';
            $data['title'] = __("Total Number of Registered Customers by Social Network") . "\r" . $period;

            return [
                'types' => json_encode($data['types']),
                'title' => json_encode($data['title'])
            ];
        } else {
            return null;
        }
    }

    /**
     * @return array|null
     */
    public function getLineData()
    {
        $data = [];
        $group = ($this->getDateRangeFormat()[0] !== null) ? strtolower($this->getDateRangeFormat()[0]) : 'day';
        $data['data'][0][] = $group;
        if (! empty($this->statisticData)) {
            foreach ($this->statisticData['types'] as $item) {
                $data['data'][0][] = $item['name'];
            }
            $i = 1;
            foreach ($this->statisticData['dates'] as $value) {
                $data['data'][$i][] = $value['created_at'];
                foreach ($this->statisticData['types'] as $item) {
                    if (isset($item['dates'][$value['created_at']])) {
                        $data['data'][$i][] = (int)$item['dates'][$value['created_at']]['count'];
                    } else {
                        $data['data'][$i][] = 0;
                    }
                }
                $i++;
            }
            $data['title'] = __('Registered Customers by Social Network - Show By: ') . ucfirst($group);
            $data['ytitle'] = __('Registrations');

            return [
                'data'   => json_encode($data['data']),
                'title'  => json_encode($data['title']),
                'ytitle' => json_encode($data['ytitle'])
            ];
        } else {
            return null;
        }
    }

    public function getFromTime()
    {
        $fromTime = $this->_localeDate->date($this->_localeDate->scopeTimeStamp() - (60*60*24*30))->format('Y-m-d ');
        $requestTime = $this->getRequest()->getParam('show_from_time');
        return $requestTime ? $requestTime : $fromTime;
    }

    public function getToTime()
    {
        $toTime = $this->_localeDate->date()->format('Y-m-d');
        $requestTime = $this->getRequest()->getParam('show_to_time');
        return $requestTime ? $requestTime : $toTime;
    }

    /**
     * @param string $period
     * @return string
     */
    public function getDateForFilter($period)
    {
        switch ($period) {
            case 'to':
                return $this->_localeDate->convertConfigTimeToUtc(
                    $this->_localeDate->date(strtotime($this->getToTime()) + 60*60*24-1)
                );
                break;
            case 'from':
                // no break
            default:
                return $this->_localeDate->convertConfigTimeToUtc(
                    $this->_localeDate->date(strtotime($this->getFromTime()))
                );
                break;
        }
    }

    /**
     * @return array
     */
    public function getGroupByOptions()
    {
        return [
            self::GROUP_BY_DAY   => __('Day'),
            self::GROUP_BY_MONTH => __('Month'),
            self::GROUP_BY_YEAR  => __('Year')
        ];
    }

    /**
     * @return array
     */
    protected function getDateRangeFormat()
    {
        $showBy = $this->getRequest()->getParam('show_by')
            ? $this->getRequest()->getParam('show_by')
            : self::GROUP_BY_DAY;

        $this->setData('show_by', $showBy);

        switch ($showBy) {
            case self::GROUP_BY_MONTH:
                return [self::GROUP_BY_MONTH, 'M, Y'];
                break;
            case self::GROUP_BY_YEAR:
                return [self::GROUP_BY_YEAR, 'Y'];
                break;
            case self::GROUP_BY_DAY:
                // no break
            default:
                return [null, 'M d, Y'];
                break;
        }
    }
}
