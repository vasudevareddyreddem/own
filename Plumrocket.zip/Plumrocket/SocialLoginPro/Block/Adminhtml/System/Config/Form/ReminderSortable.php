<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Block\Adminhtml\System\Config\Form;

class ReminderSortable extends \Magento\Config\Block\System\Config\Form\Field
{
    /**
     * @var \Plumrocket\SocialLoginPro\Model\Buttons\Provider\Reminder
     */
    private $reminderButtonsProvider;

    /**
     * ReminderSortable constructor.
     *
     * @param \Magento\Backend\Block\Template\Context                    $context
     * @param \Plumrocket\SocialLoginPro\Model\Buttons\Provider\Reminder $reminderButtonsProvider
     * @param array                                                      $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Plumrocket\SocialLoginPro\Model\Buttons\Provider\Reminder $reminderButtonsProvider,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->reminderButtonsProvider = $reminderButtonsProvider;
    }

    public function _construct()
    {
        parent::_construct();
        $this->setTemplate('system/config/reminder_sortable.phtml');
    }

    public function render(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $this->element = $element;
        return $this->toHtml();
    }

    public function getButtons()
    {
        return $this->reminderButtonsProvider->getButtons();
    }

    /**
     * @param string $part
     * @return array
     */
    public function getPreparedButtons($part)
    {
        return $this->reminderButtonsProvider->getPreparedButtons()[$part];
    }
}
