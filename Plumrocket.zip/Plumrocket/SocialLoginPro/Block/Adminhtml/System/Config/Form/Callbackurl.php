<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Block\Adminhtml\System\Config\Form;

use Magento\Backend\Block\Template\Context;
use Magento\Config\Block\System\Config\Form\Field;
use Plumrocket\SocialLoginPro\Model\Provider\Callback as CallbackProvider;

class Callbackurl extends Field
{
    /**
     * @var CallbackProvider
     */
    private $callback;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param CallbackProvider                        $callback
     * @param array                                   $data
     */
    public function __construct(
        Context $context,
        CallbackProvider $callback,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->callback = $callback;
    }

    protected function _getElementHtml(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $providerName = str_replace(['psloginpro_', '_callbackurl'], '', $element->getHtmlId());
        $url = $this->callback->getUrl($providerName, true);

         if ($providerName === 'wechat') {
             $url = parse_url($url);
             $url = $url['host'];
         }

        return '<input id="'. $element->getHtmlId() . '' .
            '" type="text" name="" value="'. $url .'" ' .
            'class="input-text psloginpro-callbackurl-autofocus" ' .
            'style="background-color: #EEE; color: #999;" ' .
            'readonly="readonly" />';
    }
}
