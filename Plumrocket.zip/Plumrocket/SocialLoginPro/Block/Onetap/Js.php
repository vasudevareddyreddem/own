<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Block\Onetap;

use Magento\Customer\Model\Context;
use Magento\Framework\App\Http\Context as HttpContext;
use Magento\Framework\View\Element\Template;
use Plumrocket\SocialLoginPro\Helper\Config\OneTap as OneTapConfig;

class Js extends Template
{
    /**
     * @var HttpContext
     */
    private $httpContext;

    /**
     * @var OneTapConfig
     */
    private $oneTapConfig;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\App\Http\Context              $httpContext
     * @param \Plumrocket\SocialLoginPro\Helper\Config\OneTap  $oneTapConfig
     * @param array                                            $data
     */
    public function __construct(
        Template\Context $context,
        HttpContext $httpContext,
        OneTapConfig $oneTapConfig,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->httpContext = $httpContext;
        $this->oneTapConfig = $oneTapConfig;
    }

    /**
     * @return bool
     */
    public function canShow(): bool
    {
        return $this->oneTapConfig->isEnabled()
            && $this->oneTapConfig->isAllowedOnCurrentPage()
            && ! $this->httpContext->getValue(Context::CONTEXT_AUTH)
            && $this->oneTapConfig->getClientId();
    }
}
