<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLogin
 * @copyright   Copyright (c) 2018 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Block\Customer\Form;

class Register extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Plumrocket\SocialLoginPro\Helper\Data
     */
    protected $dataHelper;

    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    protected $customerSession;

    /**
     * Register constructor.
     *
     * @param \Plumrocket\SocialLoginPro\Helper\Data $dataHelper
     * @param \Magento\Framework\Session\SessionManagerInterface $customerSession
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param array $data
     */
    public function __construct(
        \Plumrocket\SocialLoginPro\Helper\Data $dataHelper,
        \Magento\Framework\Session\SessionManagerInterface $customerSession,
        \Magento\Framework\View\Element\Template\Context $context,
        array $data = []
    ) {
        $this->customerSession = $customerSession;
        $this->dataHelper = $dataHelper;
        parent::__construct($context, $data);
    }

    /**
     * @return array|null
     */
    public function getPsloginData()
    {
        $data = $this->customerSession->getPsloginFields();
        $this->customerSession->unsPsloginFields();

        return $data != null ? $data : null;
    }

    /**
     * @param string $email
     * @return bool
     */
    public function isFakeMail($email)
    {
        return $this->dataHelper->isFakeMail($email);
    }
}
