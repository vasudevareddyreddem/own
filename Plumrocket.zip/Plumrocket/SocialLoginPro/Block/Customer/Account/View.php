<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Block\Customer\Account;

class View extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Plumrocket\SocialLoginPro\Helper\Data
     */
    private $dataHelper;

    /**
     * @var \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface
     */
    private $customerNetworksManager;

    /**
     * View constructor.
     *
     * @param \Magento\Framework\View\Element\Template\Context                $context
     * @param \Plumrocket\SocialLoginPro\Helper\Data                          $dataHelper
     * @param \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager
     * @param array                                                           $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Plumrocket\SocialLoginPro\Helper\Data $dataHelper,
        \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->dataHelper = $dataHelper;
        $this->customerNetworksManager = $customerNetworksManager;
    }

    /**
     * Retrieve customer account
     *
     * @return array|\Plumrocket\SocialLoginPro\Model\Account[]|null
     */
    public function getCustomerAccounts()
    {
        return $this->customerNetworksManager->getLinkedNetworksForCurrentCustomer();
    }

    /**
     * Retrieve linking description
     * @return string
     */
    public function getLinkingDescription()
    {
        return $this->dataHelper->getLinkingDescription();
    }

    /**
     * Is social linking enabled
     * @return boolean
     */
    public function isLinkingEnabled()
    {
        return $this->dataHelper->isLinkingEnabled();
    }
}
