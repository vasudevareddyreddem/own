<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Block\Popup;

class BindEmail extends \Magento\Framework\View\Element\Template
{
    /**
     * @return string
     */
    public function getStoreName()
    {
        return (string)$this->_scopeConfig->getValue(
            'general/store_information/name',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        ) ?: 'Magento Store';
    }

    /**
     * @return false|string
     */
    public function getJsLayout()
    {
        $layout = json_decode(parent::getJsLayout(), true);
        $layout['components']['pr-pslogin-email-popup'] = $this->getJsComponentConfig();
        return json_encode($layout);
    }

    /**
     * @return array
     */
    public function getJsComponentConfig()
    {
        return [
            'component' => 'Plumrocket_SocialLoginPro/js/view/bind-email',
            'storeName' => $this->getStoreName(),
            'loginWithEmailUrl' => $this->getUrl('pslogin/account/register'),
            'loginWithPassUrl' => $this->getUrl('pslogin/account_login/password'),
            'forgotPassUrl' => $this->getUrl('customer/account/forgotpassword'),
            'login_networks_buttons_html' => $this->getChildHtml('pslogin.login.popup.buttons'),
            'successIcon' => $this->getViewFileUrl('Plumrocket_SocialLoginPro::images/success_icon.png'),
            'loaderIconSrc' => $this->getViewFileUrl('images/loader-2.gif'),
        ];
    }
}
