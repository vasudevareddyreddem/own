<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Block\Popup;

/**
 * Class Login
 *
 * @method $this setLinkedNetworkTypes(array $types)
 * @method array getLinkedNetworkTypes()
 */
class Login extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Plumrocket\SocialLoginPro\Model\Buttons\Factory
     */
    private $buttonsFactory;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\Buttons\Preparer
     */
    private $buttonsPreparer;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\Config\Provider
     */
    private $configProvider;

    /**
     * Login constructor.
     *
     * @param \Magento\Framework\View\Element\Template\Context  $context
     * @param \Plumrocket\SocialLoginPro\Model\Buttons\Factory  $buttonsFactory
     * @param \Plumrocket\SocialLoginPro\Model\Buttons\Preparer $buttonsPreparer
     * @param \Plumrocket\SocialLoginPro\Model\Config\Provider  $configProvider
     * @param array                                             $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Plumrocket\SocialLoginPro\Model\Buttons\Factory $buttonsFactory,
        \Plumrocket\SocialLoginPro\Model\Buttons\Preparer $buttonsPreparer,
        \Plumrocket\SocialLoginPro\Model\Config\Provider $configProvider,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->buttonsFactory = $buttonsFactory;
        $this->buttonsPreparer = $buttonsPreparer;
        $this->configProvider = $configProvider;
    }

    /**
     * @return array
     */
    public function getLinkedButtons()
    {
        $types = $this->getLinkedNetworkTypes();
        $buttons = $this->buttonsFactory->create($types);

        return $this->buttonsPreparer->prepareSortAndVisibility(
            $buttons,
            $this->configProvider->getSortableParams(),
            false
        );
    }
}
