<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Block\Popup\Reminder\Link;

class Buttons extends \Plumrocket\SocialLoginPro\Block\Link\Buttons
{
    /**
     * @var \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface
     */
    private $customerNetworksManager;

    /**
     * Buttons constructor.
     *
     * @param \Magento\Framework\View\Element\Template\Context                $context
     * @param \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager
     * @param \Plumrocket\SocialLoginPro\Model\Buttons\Provider\Reminder      $reminderButtonsProvider
     * @param array                                                           $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Plumrocket\SocialLoginPro\Model\Buttons\Provider\Reminder $reminderButtonsProvider,
        \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager,
        array $data = []
    ) {
        parent::__construct($context, $reminderButtonsProvider, $data);
        $this->customerNetworksManager = $customerNetworksManager;
    }

    /**
     * Retrieve link buttons
     * @return array
     */
    public function getLinkButtons()
    {
        if (! empty($this->customerNetworksManager->getLinkedTypesForCurrentCustomer())) {
            return [];
        }

        return parent::getLinkButtons();
    }
}
