<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\SocialLoginPro\Api;

interface CustomerNetworksManagerInterface
{
    /**
     * @param int $customerId
     * @return string[]
     */
    public function getLinkedTypesByCustomerId($customerId);

    /**
     * @param int $customerId
     * @return \Plumrocket\SocialLoginPro\Model\Account[]
     */
    public function getLinkedNetworksByCustomerId($customerId);

    /**
     * @return string[]
     */
    public function getLinkedTypesForCurrentCustomer();

    /**
     * @return \Plumrocket\SocialLoginPro\Model\Account[]
     */
    public function getLinkedNetworksForCurrentCustomer();

    /**
     * @param string $type
     * @param int    $userId
     * @return bool
     */
    public function isNetworkAlreadyLinked($type, $userId);

    /**
     * @param string $type
     * @param int    $userId
     * @return bool
     */
    public function getCustomerIdByNetwork($type, $userId);

    /**
     * @param string      $type
     * @param int         $userId
     * @param int         $customerId
     * @param string|null $customerPhoto
     * @return bool
     *
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\ValidatorException
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     */
    public function linkNetworkToCustomer($type, $userId, $customerId, $customerPhoto = null);

    /**
     * @param int $customerId
     * @param int $networkAccountId
     * @return bool
     */
    public function unlinkNetworkFromCustomer($customerId, $networkAccountId);
}
