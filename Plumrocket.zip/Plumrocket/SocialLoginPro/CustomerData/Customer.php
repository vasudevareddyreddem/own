<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\CustomerData;

use Magento\Customer\CustomerData\SectionSourceInterface;
use Magento\Customer\Helper\Session\CurrentCustomer;
use Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface;
use Plumrocket\SocialLoginPro\Helper\Data;
use Plumrocket\SocialLoginPro\Model\Account\Photo;

/**
 * Customer section
 */
class Customer implements SectionSourceInterface
{
    /**
     * @var CurrentCustomer
     */
    protected $currentCustomer;

    /**
     * @var Data
     */
    protected $helper;

    /**
     * @var \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface
     */
    private $customerNetworksManager;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\Account\Photo
     */
    private $photo;

    /**
     * @param CurrentCustomer                                                 $currentCustomer
     * @param Data                                                            $helper
     * @param \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager
     * @param \Plumrocket\SocialLoginPro\Model\Account\Photo                  $photo
     */
    public function __construct(
        CurrentCustomer $currentCustomer,
        Data $helper,
        CustomerNetworksManagerInterface $customerNetworksManager,
        Photo $photo
    ) {
        $this->currentCustomer = $currentCustomer;
        $this->helper = $helper;
        $this->customerNetworksManager = $customerNetworksManager;
        $this->photo = $photo;
    }

    /**
     * @return array
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getSectionData(): array
    {
        $customerId = $this->currentCustomer->getCustomerId();
        return [
            'photo' => $this->helper->photoEnabled() ? $this->photo->getPhotoUrl($customerId) : '',
            'isCustomer' => (bool)$customerId,
            'linked' => $this->customerNetworksManager->getLinkedTypesByCustomerId($customerId),
        ];
    }
}
