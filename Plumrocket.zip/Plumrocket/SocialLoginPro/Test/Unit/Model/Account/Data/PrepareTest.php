<?php
/**
 * Plumrocket Inc.
 * NOTICE OF LICENSE
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Test\Unit\Model\Account\Data;

use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;
use Plumrocket\SocialLoginPro\Helper\Config;
use Plumrocket\SocialLoginPro\Model\Account\Data\FakeEmail;
use Plumrocket\SocialLoginPro\Model\Account\Data\Prepare;

/**
 * @since 3.5.3
 */
class PrepareTest extends TestCase
{
    /**
     * @var \Plumrocket\SocialLoginPro\Model\Account\Data\Prepare
     */
    private $isMatchUrl;

    protected function setUp(): void
    {
        $configMock = $this->createMock(Config::class);

        $objectManager = new ObjectManager($this);

        $this->isMatchUrl = $objectManager->getObject(
            Prepare::class, [
                'config' => $configMock,
                'fakeEmail' => $objectManager->getObject(FakeEmail::class),
            ]
        );
    }

    /**
     * @dataProvider fakeEmailDataProvider
     *
     * @param array $dataIn
     * @param array $dataOut
     */
    public function testFakeEmail(array $dataIn, array $dataOut)
    {
        self::assertSame($dataOut, $this->isMatchUrl->names($dataIn));
    }

    /**
     * @dataProvider separatedEmailDataProvider
     *
     * @param array $dataIn
     * @param array $dataOut
     */
    public function testSeparatedEmail(array $dataIn, array $dataOut)
    {
        self::assertSame($dataOut, $this->isMatchUrl->names($dataIn));
    }

    /**
     * @dataProvider oneWordEmailDataProvider
     *
     * @param array $dataIn
     * @param array $dataOut
     */
    public function testOneWordEmail(array $dataIn, array $dataOut)
    {
        self::assertSame($dataOut, $this->isMatchUrl->names($dataIn));
    }

    /**
     * @dataProvider multyseparatorEmailDataProvider
     *
     * @param array $dataIn
     * @param array $dataOut
     */
    public function testMultyseparatorEmail(array $dataIn, array $dataOut)
    {
        self::assertSame($dataOut, $this->isMatchUrl->names($dataIn));
    }

    /**
     * @dataProvider appleHideEmailData
     *
     * @param array $dataIn
     * @param array $dataOut
     */
    public function testAppleHideEmail(array $dataIn, array $dataOut)
    {
        self::assertSame($dataOut, $this->isMatchUrl->names($dataIn));
    }

    /**
     * @return \Generator
     */
    public function fakeEmailDataProvider()
    {
        yield [
            'dataIn' => [
                'firstname' => '',
                'lastname'  => '',
                'email'     => FakeEmail::FAKE_EMAIL_PREFIX . 'test@example.com'
            ],
            'dataOut' => [
                'firstname' => 'Customer',
                'lastname'  => 'Unknown',
                'email'     => FakeEmail::FAKE_EMAIL_PREFIX . 'test@example.com'
            ],
        ];
        yield [
            'dataIn' => [
                'firstname' => '',
                'lastname'  => 'Parker',
                'email'     => FakeEmail::FAKE_EMAIL_PREFIX . 'test@example.com'
            ],
            'dataOut' => [
                'firstname' => 'Customer',
                'lastname'  => 'Parker',
                'email'     => FakeEmail::FAKE_EMAIL_PREFIX . 'test@example.com'
            ],
        ];
        yield [
            'dataIn' => [
                'firstname' => 'John',
                'lastname'  => '',
                'email'     => FakeEmail::FAKE_EMAIL_PREFIX . 'test@example.com'
            ],
            'dataOut' => [
                'firstname' => 'John',
                'lastname'  => 'Unknown',
                'email'     => FakeEmail::FAKE_EMAIL_PREFIX . 'test@example.com'
            ],
        ];
        yield [
            'dataIn' => [
                'firstname' => 'John',
                'lastname'  => 'Parker',
                'email'     => FakeEmail::FAKE_EMAIL_PREFIX . 'test@example.com'
            ],
            'dataOut' => [
                'firstname' => 'John',
                'lastname'  => 'Parker',
                'email'     => FakeEmail::FAKE_EMAIL_PREFIX . 'test@example.com'
            ],
        ];
    }

    /**
     * @return \Generator
     */
    public function separatedEmailDataProvider()
    {
        yield [
            'dataIn' => [
                'firstname' => '',
                'lastname'  => '',
                'email'     => 'jim.parker@xyz.com'
            ],
            'dataOut' => [
                'firstname' => 'Jim',
                'lastname'  => 'Parker',
                'email'     => 'jim.parker@xyz.com'
            ],
        ];
        yield [
            'dataIn' => [
                'firstname' => '',
                'lastname'  => 'Parker-Blake',
                'email'     => 'jim.parker@xyz.com'
            ],
            'dataOut' => [
                'firstname' => 'Jim',
                'lastname'  => 'Parker-Blake',
                'email'     => 'jim.parker@xyz.com'
            ],
        ];
        yield [
            'dataIn' => [
                'firstname' => 'John',
                'lastname'  => '',
                'email'     => 'jim-parker@xyz.com'
            ],
            'dataOut' => [
                'firstname' => 'John',
                'lastname'  => 'Parker',
                'email'     => 'jim-parker@xyz.com'
            ],
        ];
        yield [
            'dataIn' => [
                'firstname' => 'John',
                'lastname'  => 'Parker-Blake',
                'email'     => 'jim-parker@xyz.com'
            ],
            'dataOut' => [
                'firstname' => 'John',
                'lastname'  => 'Parker-Blake',
                'email'     => 'jim-parker@xyz.com'
            ],
        ];
    }

    /**
     * @return \Generator
     */
    public function oneWordEmailDataProvider()
    {
        yield [
            'dataIn'  => [
                'firstname' => '',
                'lastname'  => '',
                'email'     => 'parker@xyz.com'
            ],
            'dataOut' => [
                'firstname' => 'Customer',
                'lastname'  => 'Parker',
                'email'     => 'parker@xyz.com'
            ],
        ];
        yield [
            'dataIn'  => [
                'firstname' => '',
                'lastname'  => 'Parker-Blake',
                'email'     => 'parker@xyz.com'
            ],
            'dataOut' => [
                'firstname' => 'Customer',
                'lastname'  => 'Parker-Blake',
                'email'     => 'parker@xyz.com'
            ],
        ];
        yield [
            'dataIn'  => [
                'firstname' => 'John',
                'lastname'  => 'Parker-Blake',
                'email'     => 'parker@xyz.com'
            ],
            'dataOut' => [
                'firstname' => 'John',
                'lastname'  => 'Parker-Blake',
                'email'     => 'parker@xyz.com'
            ],
        ];
        yield [
            'dataIn'  => [
                'firstname' => 'John',
                'lastname'  => '',
                'email'     => 'qwerty@xyz.com'
            ],
            'dataOut' => [
                'firstname' => 'John',
                'lastname'  => 'Qwerty',
                'email'     => 'qwerty@xyz.com'
            ],
        ];
        yield [
            'dataIn'  => [
                'firstname' => 'John',
                'lastname'  => '',
                'email'     => 'qwerty123@xyz.com'
            ],
            'dataOut' => [
                'firstname' => 'John',
                'lastname'  => 'Qwerty123',
                'email'     => 'qwerty123@xyz.com'
            ],
        ];
        yield [
            'dataIn'  => [
                'firstname' => '',
                'lastname'  => 'Parker-Blake',
                'email'     => 'qwerty123@xyz.com'
            ],
            'dataOut' => [
                'firstname' => 'Customer',
                'lastname'  => 'Parker-Blake',
                'email'     => 'qwerty123@xyz.com'
            ],
        ];
    }

    /**
     * @return \Generator
     */
    public function appleHideEmailData()
    {
        yield [
            'dataIn'  => [
                'firstname' => '',
                'lastname'  => '',
                'email'     => 'dpdcnf87nu@privaterelay.appleid.com'
            ],
            'dataOut' => [
                'firstname' => 'Customer',
                'lastname'  => 'Unknown',
                'email'     => 'dpdcnf87nu@privaterelay.appleid.com'
            ],
        ];
    }

    /**
     * @return \Generator
     */
    public function multyseparatorEmailDataProvider()
    {
        yield [
            'dataIn'  => [
                'firstname' => '',
                'lastname'  => '',
                'email'     => 'jim-test@xyz.com'
            ],
            'dataOut' => [
                'firstname' => 'Jim',
                'lastname'  => 'Test',
                'email'     => 'jim-test@xyz.com'
            ],
        ];
        yield [
            'dataIn'  => [
                'firstname' => '',
                'lastname'  => '',
                'email'     => 'jim.parker-man@xyz.com'
            ],
            'dataOut' => [
                'firstname' => 'Jim',
                'lastname'  => 'Parker-man',
                'email'     => 'jim.parker-man@xyz.com'
            ],
        ];
        yield [
            'dataIn'  => [
                'firstname' => '',
                'lastname'  => '',
                'email'     => 'jim-test.parker@xyz.com'
            ],
            'dataOut' => [
                'firstname' => 'Jim-test',
                'lastname'  => 'Parker',
                'email'     => 'jim-test.parker@xyz.com'
            ],
        ];
        yield [
            'dataIn'  => [
                'firstname' => '',
                'lastname'  => '',
                'email'     => 'jim-test.parker.office@xyz.com'
            ],
            'dataOut' => [
                'firstname' => 'Jim-test',
                'lastname'  => 'Parker',
                'email'     => 'jim-test.parker.office@xyz.com'
            ],
        ];
        yield [
            'dataIn'  => [
                'firstname' => 'Jim-test',
                'lastname'  => '',
                'email'     => 'jim-test.parker.office@xyz.com'
            ],
            'dataOut' => [
                'firstname' => 'Jim-test',
                'lastname'  => 'Parker',
                'email'     => 'jim-test.parker.office@xyz.com'
            ],
        ];
    }
}
