<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Observer;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Response\RedirectInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Session\SessionManagerInterface;
use Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface;
use Plumrocket\SocialLoginPro\Helper\Data;
use Plumrocket\SocialLoginPro\Model\AccountProviderInterface;

class RegistrationSuccessObserver implements ObserverInterface
{
    /**
     * @var \Plumrocket\SocialLoginPro\Helper\Data
     */
    private $helper;

    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    private $session;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    private $request;

    /**
     * @var \Plumrocket\SocialLoginPro\Model\AccountProviderInterface
     */
    private $accountProvider;

    /**
     * @var \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface
     */
    private $customerNetworksManager;

    /**
     * RegistrationSuccessObserver constructor.
     *
     * @param \Plumrocket\SocialLoginPro\Helper\Data $helper
     * @param \Magento\Framework\Session\SessionManagerInterface $customerSession
     * @param \Magento\Framework\App\RequestInterface $httpRequest
     * @param \Plumrocket\SocialLoginPro\Model\AccountProviderInterface $accountProvider
     * @param \Plumrocket\SocialLoginPro\Api\CustomerNetworksManagerInterface $customerNetworksManager
     */
    public function __construct(
        Data $helper,
        SessionManagerInterface $customerSession,
        RequestInterface $httpRequest,
        AccountProviderInterface $accountProvider,
        CustomerNetworksManagerInterface $customerNetworksManager
    ) {
        $this->helper = $helper;
        $this->session = $customerSession;
        $this->request = $httpRequest;
        $this->accountProvider = $accountProvider;
        $this->customerNetworksManager = $customerNetworksManager;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     * @throws \Magento\Framework\Exception\InputException
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\ValidatorException
     * @throws \Magento\Framework\Stdlib\Cookie\CookieSizeLimitReachedException
     * @throws \Magento\Framework\Stdlib\Cookie\FailureToSendException
     */
    public function execute(Observer $observer)
    {
        if (!$this->helper->moduleEnabled()) {
            return;
        }

        $data = $this->session->getData('pslogin');

        if (! empty($data['provider']) && ! empty($data['timeout']) && $data['timeout'] > time()) {
            try {
                $model = $this->accountProvider->getByType($data['provider']);
            } catch (\Magento\Framework\Exception\LocalizedException $localizedException) {
                return;
            }

            $customerId = null;
            if ($customer = $observer->getCustomer()) {
                $customerId = $customer->getId();
            }

            if ($customerId) {
                $model->setUserData($data);

                $this->customerNetworksManager->linkNetworkToCustomer(
                    $model->getProvider(),
                    $model->getUserData('user_id'),
                    $customerId,
                    $model->getUserData('photo')
                );
            }
            $this->session->unsPsloginFields();
        }

        // Show share-popup.
        $this->helper->showSharePopup();

        // Set redirect url.
        $redirectUrl = $this->helper->getRedirectUrl('register');
        $this->request->setParam(RedirectInterface::PARAM_NAME_SUCCESS_URL, $redirectUrl);
    }
}
