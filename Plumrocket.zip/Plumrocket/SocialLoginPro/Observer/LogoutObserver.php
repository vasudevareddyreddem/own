<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\SocialLoginPro\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Framework\Stdlib\Cookie\CookieMetadataFactory;
use Magento\Framework\Stdlib\CookieManagerInterface;
use Plumrocket\SocialLoginPro\Helper\Config\OneTap;
use Plumrocket\SocialLoginPro\Helper\Data;

class LogoutObserver implements ObserverInterface
{
    const COOKIE_DURATION = 86400;

    /**
     * @var \Plumrocket\SocialLoginPro\Helper\Data
     */
    private $dataHelper;

    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    private $customerSession;

    /**
     * @var \Magento\Framework\Stdlib\CookieManagerInterface
     */
    private $cookieManager;

    /**
     * @var \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory
     */
    private $cookieMetadataFactory;

    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    private $sessionManager;

    /**
     * @var \Plumrocket\SocialLoginPro\Helper\Config\OneTap
     */
    private $oneTapConfig;

    /**
     * LogoutObserver constructor.
     *
     * @param \Plumrocket\SocialLoginPro\Helper\Data                 $helper
     * @param \Magento\Framework\Session\SessionManagerInterface     $customerSession
     * @param \Magento\Framework\Stdlib\CookieManagerInterface       $cookieManager
     * @param \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory
     * @param \Magento\Framework\Session\SessionManagerInterface     $sessionManager
     * @param \Plumrocket\SocialLoginPro\Helper\Config\OneTap        $oneTapConfig
     */
    public function __construct(
        Data $helper,
        SessionManagerInterface $customerSession,
        CookieManagerInterface $cookieManager,
        CookieMetadataFactory $cookieMetadataFactory,
        SessionManagerInterface $sessionManager,
        OneTap $oneTapConfig
    ) {
        $this->dataHelper = $helper;
        $this->customerSession = $customerSession;
        $this->cookieManager = $cookieManager;
        $this->cookieMetadataFactory = $cookieMetadataFactory;
        $this->sessionManager = $sessionManager;
        $this->oneTapConfig = $oneTapConfig;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        if (!$this->dataHelper->moduleEnabled()) {
            return;
        }

        if ($this->oneTapConfig->isEnabledAutoSignIn()) {
            $this->disableOneTabAutoSingIn();
        }

        $this->customerSession->unsLoginProvider();
    }

    private function disableOneTabAutoSingIn()
    {
        $metadata = $this->cookieMetadataFactory
            ->createPublicCookieMetadata()
            ->setDuration(self::COOKIE_DURATION)
            ->setPath($this->sessionManager->getCookiePath())
            ->setDomain($this->sessionManager->getCookieDomain());

        $this->cookieManager->setPublicCookie(
            'pslogin_disable_one_tap_auto_sign_in',
            1,
            $metadata
        );
    }
}
