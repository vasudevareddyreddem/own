<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Popuplogin
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Popuplogin\Controller\Ajax;

use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Api\Data\AddressInterface;
use Magento\Customer\Api\Data\AddressInterfaceFactory;
use Magento\Customer\Api\Data\CustomerInterface;
use Magento\Customer\Api\Data\CustomerInterfaceFactory;
use Magento\Customer\Api\Data\RegionInterfaceFactory;
use Magento\Customer\Api\GroupManagementInterface;
use Magento\Customer\Helper\Address;
use Magento\Customer\Model\Metadata\FormFactory;
use Magento\Customer\Model\Session;
use Magento\Customer\Model\Url as CustomerUrl;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Escaper;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Phrase;
use Magento\Framework\UrlFactory;
use Magento\Newsletter\Model\SubscriberFactory;
use Magento\Store\Model\StoreManagerInterface;
use Plumrocket\Popuplogin\Helper\Config\RegistrationForm as RegistrationFormConfig;
use Plumrocket\Popuplogin\Model\Config\Source\Subscriptions;
use Psr\Log\LoggerInterface;

/**
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Register extends \Magento\Framework\App\Action\Action
{
    /**
     * @var AccountManagementInterface
     */
    private $accountManagement;

    /**
     * @var Address
     */
    private $addressHelper;

    /**
     * @var FormFactory
     */
    private $formFactory;

    /**
     * @var SubscriberFactory
     */
    private $subscriberFactory;

    /**
     * @var RegionInterfaceFactory
     */
    private $regionDataFactory;

    /**
     * @var AddressInterfaceFactory
     */
    private $addressDataFactory;

    /**
     * @var CustomerInterfaceFactory
     */
    private $customerDataFactory;

    /**
     * @var GroupManagementInterface
     */
    private $customerGroupManagement;

    /**
     * @var CustomerUrl
     */
    private $customerUrl;

    /**
     * @var Escaper
     */
    private $escaper;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    private $urlModel;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var Session
     */
    private $session;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var \Plumrocket\Popuplogin\Helper\Config\RegistrationForm
     */
    private $registrationFormConfig;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;

    /**
     * @param \Magento\Framework\App\Action\Context                 $context
     * @param \Magento\Customer\Model\Session                       $customerSession
     * @param \Magento\Store\Model\StoreManagerInterface            $storeManager
     * @param \Magento\Customer\Api\AccountManagementInterface      $accountManagement
     * @param \Magento\Customer\Helper\Address                      $addressHelper
     * @param \Magento\Framework\UrlFactory                         $urlFactory
     * @param \Magento\Customer\Model\Metadata\FormFactory          $formFactory
     * @param \Magento\Newsletter\Model\SubscriberFactory           $subscriberFactory
     * @param \Magento\Customer\Api\Data\RegionInterfaceFactory     $regionDataFactory
     * @param \Magento\Customer\Api\Data\AddressInterfaceFactory    $addressDataFactory
     * @param \Magento\Customer\Api\Data\CustomerInterfaceFactory   $customerDataFactory
     * @param \Magento\Customer\Api\GroupManagementInterface        $customerGroupManagement
     * @param \Magento\Customer\Model\Url                           $customerUrl
     * @param \Magento\Framework\Escaper                            $escaper
     * @param \Magento\Framework\Api\DataObjectHelper               $dataObjectHelper
     * @param \Magento\Framework\Controller\Result\JsonFactory      $resultJsonFactory
     * @param \Plumrocket\Popuplogin\Helper\Config\RegistrationForm $registrationFormConfig
     * @param \Psr\Log\LoggerInterface                              $logger
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        StoreManagerInterface $storeManager,
        AccountManagementInterface $accountManagement,
        Address $addressHelper,
        UrlFactory $urlFactory,
        FormFactory $formFactory,
        SubscriberFactory $subscriberFactory,
        RegionInterfaceFactory $regionDataFactory,
        AddressInterfaceFactory $addressDataFactory,
        CustomerInterfaceFactory $customerDataFactory,
        GroupManagementInterface $customerGroupManagement,
        CustomerUrl $customerUrl,
        Escaper $escaper,
        DataObjectHelper $dataObjectHelper,
        JsonFactory $resultJsonFactory,
        RegistrationFormConfig $registrationFormConfig,
        LoggerInterface $logger
    ) {
        $this->session = $customerSession;
        $this->storeManager = $storeManager;
        $this->accountManagement = $accountManagement;
        $this->addressHelper = $addressHelper;
        $this->formFactory = $formFactory;
        $this->subscriberFactory = $subscriberFactory;
        $this->regionDataFactory = $regionDataFactory;
        $this->addressDataFactory = $addressDataFactory;
        $this->customerDataFactory = $customerDataFactory;
        $this->customerGroupManagement = $customerGroupManagement;
        $this->customerUrl = $customerUrl;
        $this->escaper = $escaper;
        $this->urlModel = $urlFactory->create();
        $this->dataObjectHelper = $dataObjectHelper;
        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
        $this->registrationFormConfig = $registrationFormConfig;
        $this->logger = $logger;
    }

    /**
     * Add address to customer during create account
     *
     * @param array $credentials
     * @return AddressInterface|null
     */
    protected function extractAddress(array $credentials)
    {
        $addressForm = $this->formFactory->create('customer_address', 'customer_register_address');
        $attributes = $addressForm->getAttributes();

        // {{ Check filed address
        $checkAddressKeys = array_flip(array_intersect(array_keys($attributes), array_keys($credentials)));
        foreach (['firstname', 'lastname', 'country_id'] as $key) {
            if (isset($checkAddressKeys[$key])) {
                unset($checkAddressKeys[$key]);
            }
        }

        if (!count($checkAddressKeys)) {
            return null;
        }
        // }}

        $addressData = [];
        $regionDataObject = null;
        foreach ($attributes as $attribute) {
            $attributeCode = $attribute->getAttributeCode();
            $value = $credentials[$attributeCode] ?? null;
            if ($value === null) {
                continue;
            }
            switch ($attributeCode) {
                case 'region_id':
                    $regionDataObject = $this->regionDataFactory->create();
                    $regionDataObject->setRegionId($value);
                    break;
                case 'region':
                    $regionDataObject = $this->regionDataFactory->create();
                    $regionDataObject->setRegion($value);
                    break;
                default:
                    $addressData[$attributeCode] = $value;
            }
        }

        $addressDataObject = $this->addressDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $addressDataObject,
            $addressData,
            AddressInterface::class
        );
        if ($regionDataObject) {
            $addressDataObject->setRegion($regionDataObject);
        }

        $addressDataObject
            ->setIsDefaultBilling(false)
            ->setIsDefaultShipping(false);

        return $addressDataObject;
    }

    protected function extractCustomer(array $credentials)
    {
        $customerForm = $this->formFactory->create('customer', 'customer_account_create');
        $allowedAttributes = $customerForm->getAllowedAttributes();
        $attributes = $customerForm->getAttributes();
        $isGroupIdEmpty = isset($allowedAttributes['group_id']);

        $customerData = [];

        foreach ($attributes as $attribute) {
            $attributeCode = $attribute->getAttributeCode();
            $value = $credentials[$attributeCode] ?? null;
            if ($value === null) {
                continue;
            }
            $customerData[$attributeCode] = $value;
        }

        $customerDataObject = $this->customerDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $customerDataObject,
            $customerData,
            CustomerInterface::class
        );
        $store = $this->storeManager->getStore();
        if ($isGroupIdEmpty) {
            $customerDataObject->setGroupId(
                $this->customerGroupManagement->getDefaultGroup($store->getId())->getId()
            );
        }

        $customerDataObject->setWebsiteId($store->getWebsiteId());
        $customerDataObject->setStoreId($store->getId());

        return $customerDataObject;
    }

    /**
     * Create customer account action
     *
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Json|\Magento\Framework\Controller\ResultInterface
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function execute()
    {
        $httpBadRequestCode = 400;

        $resultJson = $this->resultJsonFactory->create();
        try {
            $credentials = $this->getRequest()->getParams();
        } catch (\Exception $e) {
            return $resultJson->setHttpResponseCode($httpBadRequestCode);
        }
        if (!$credentials || $this->getRequest()->getMethod() !== 'POST' || !$this->getRequest()->isXmlHttpRequest()) {
            return $resultJson->setHttpResponseCode($httpBadRequestCode);
        }

        if (!isset($credentials['country_id'])) {
            $credentials['country_id'] = $this->registrationFormConfig->getConfig('general/country/default');
        }

        $this->session->regenerateId();

        try {
            $address = $this->extractAddress($credentials);
            $customer = $this->extractCustomer($credentials);
            if ($address) {
                $customer->setAddresses([$address]);
            }

            $password = $credentials['password'] ?? null;
            $confirmation = $credentials['password_confirmation'] ?? $password;
            $this->checkPasswordConfirmation($password, $confirmation);

            $redirectUrl = $this->session->getBeforeAuthUrl();
            $customer = $this->accountManagement
                ->createAccount($customer, $password, $redirectUrl);

            if (isset($credentials['subscribe'])
                || $this->registrationFormConfig->getSubscriptionFlow() === Subscriptions::HIDE_AND_SUBSCRIBE
            ) {
                $this->subscriberFactory->create()->subscribeCustomerById($customer->getId());
            }

            $this->_eventManager->dispatch(
                'customer_register_success',
                ['account_controller' => $this, 'customer' => $customer]
            );

            $confirmationStatus = $this->accountManagement->getConfirmationStatus($customer->getId());
            if ($confirmationStatus === AccountManagementInterface::ACCOUNT_CONFIRMATION_REQUIRED) {
                $email = $this->escaper->escapeHtml($this->customerUrl->getEmailConfirmationUrl($customer->getEmail()));
                // @codingStandardsIgnoreStart
                $response = [
                    'errors' => false,
                    'message' => __(
                        'You must confirm your account. Please check your email for the confirmation link or <a href="%1">click here</a> for a new link.',
                        $email
                    )
                ];
                // @codingStandardsIgnoreEnd
            } else {
                $this->session->setCustomerDataAsLoggedIn($customer);
                $response = [
                    'errors' => false,
                    'message' => $this->getSuccessMessage()
                ];
            }
        } catch (StateException $e) {
            $url = $this->urlModel->getUrl('customer/account/forgotpassword');
            // @codingStandardsIgnoreStart
            $message = __(
                'There is already an account with this email address. If you are sure that it is your email address, <a href="%1">click here</a> to get your password and access your account.',
                $url
            );
            // @codingStandardsIgnoreEnd
            $response = [
                'errors' => true,
                'message' => $message
            ];
        } catch (InputException $e) {
            $message = $this->escaper->escapeHtml($e->getMessage());
            foreach ($e->getErrors() as $error) {
                $message .= $this->escaper->escapeHtml($error->getMessage());
            }
            $response = [
                'errors' => true,
                'message' => $message
            ];
        } catch (LocalizedException $e) {
            $response = [
                'errors' => true,
                'message' => $this->escaper->escapeHtml($e->getMessage())
            ];
        } catch (\Exception $e) {
            $this->logger->critical($e->getMessage());
            $response = [
                'errors' => true,
                'message' => __('We can\'t save the customer.')
            ];
        }

        $this->session->setAffiliateTrackingCode(true);
        $this->session->setCustomerFormData($this->getRequest()->getPostValue());
        return $resultJson->setData($response);
    }

    /**
     * Make sure that password and password confirmation matched
     *
     * @param string $password
     * @param string $confirmation
     * @return void
     * @throws InputException
     */
    protected function checkPasswordConfirmation($password, $confirmation)
    {
        if ($password !== $confirmation) {
            throw new InputException(__('Please make sure your passwords match.'));
        }
    }

    /**
     * Retrieve success message
     *
     * @return \Magento\Framework\Phrase
     */
    protected function getSuccessMessage(): Phrase
    {
        if ($this->addressHelper->isVatValidationEnabled()) {
            if ($this->addressHelper->getTaxCalculationAddressType() === Address::TYPE_SHIPPING) {
                // @codingStandardsIgnoreStart
                $message = __(
                    'If you are a registered VAT customer, please <a href="%1">click here</a> to enter your shipping address for proper VAT calculation.',
                    $this->urlModel->getUrl('customer/address/edit')
                );
                // @codingStandardsIgnoreEnd
            } else {
                // @codingStandardsIgnoreStart
                $message = __(
                    'If you are a registered VAT customer, please <a href="%1">click here</a> to enter your billing address for proper VAT calculation.',
                    $this->urlModel->getUrl('customer/address/edit')
                );
                // @codingStandardsIgnoreEnd
            }
        } else {
            $message = __('Thank you for registering with %1.', $this->storeManager->getStore()->getFrontendName());
        }
        return $message;
    }
}
