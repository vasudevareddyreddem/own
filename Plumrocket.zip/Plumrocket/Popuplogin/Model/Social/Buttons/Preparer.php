<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Popuplogin\Model\Social\Buttons;

class Preparer
{
    /**
     * @var int
     */
    private $visibleCount;

    /**
     * @var array
     */
    private $preparedButtons;

    /**
     * Preparer constructor.
     *
     * @param int $visibleCount
     */
    public function __construct($visibleCount = 3)
    {
        $this->visibleCount = $visibleCount;
    }

    /**
     * @param array $preparedButtons
     * @param       $part
     * @return array|mixed
     */
    public function execute(array $preparedButtons, $part)
    {
        if (null === $this->preparedButtons) {
            $this->preparedButtons = $this->prepareVisibility($preparedButtons);
        }

        return isset($this->preparedButtons[$part])
            ? $this->preparedButtons[$part]
            : array_merge($this->preparedButtons['visible'], $this->preparedButtons['hidden']);
    }

    /**
     * @param $preparedButtons
     * @return array
     */
    private function prepareVisibility(array $preparedButtons)
    {
        $visibleCount = $this->visibleCount;

        $result = ['visible' => [], 'hidden' => []];

        foreach ($preparedButtons as $network => $button) {
            if ($visibleCount > 0 && $button['visible']) {
                $result['visible'][$network] = $button;
            } else {
                $button['visible'] = false;
                $result['hidden'][$network] = $button;
            }

            --$visibleCount;
        }

        return $result;
    }
}
