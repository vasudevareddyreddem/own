<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_PopupLogin
 * @copyright   Copyright (c) 2018 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Popuplogin\Model\Captcha;

use Magento\Captcha\Helper\Data as CaptchaHelper;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Session\SessionManagerInterface;

class Checker
{
    /**
     * @var \Magento\Captcha\Helper\Data
     */
    protected $helper;

    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    protected $sessionManager;

    /**
     * @var JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * Checker constructor.
     *
     * @param CaptchaHelper           $helper
     * @param SessionManagerInterface $sessionManager
     * @param JsonFactory             $resultJsonFactory
     */
    public function __construct(
        CaptchaHelper $helper,
        SessionManagerInterface $sessionManager,
        JsonFactory $resultJsonFactory
    ) {
        $this->helper = $helper;
        $this->sessionManager = $sessionManager;
        $this->resultJsonFactory = $resultJsonFactory;
    }

    public function checkCaptcha($credentials, $formIds)
    {
        $captchaFormIdField = 'captcha_form_id';
        $captchaInputName = 'captcha_string';

        if ($credentials !== null) {
            $captchaString = $credentials[$captchaInputName] ?? null;
            $currentFormId = $credentials[$captchaFormIdField] ?? null;

            foreach ($formIds as $formId) {
                /** @var \Magento\Captcha\Model\DefaultModel $captchaModel */
                $captchaModel = $this->helper->getCaptcha($formId);

                if (! $captchaModel->isRequired()) {
                    continue;
                }

                if ($captchaModel->isRequired() && !in_array($currentFormId, $formIds, true)) {
                    $resultJson = $this->resultJsonFactory->create();
                    return $resultJson->setData(['errors' => true, 'message' => __('Provided form does not exist')]);
                }

                if (($formId === $currentFormId) && ! $captchaModel->isCorrect($captchaString)) {
                    $resultJson = $this->resultJsonFactory->create();
                    return $resultJson->setData(['errors' => true, 'message' => __('Incorrect CAPTCHA')]);
                }
            }
        }

        return null;
    }
}
