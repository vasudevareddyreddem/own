/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_PopupLogin
 * @copyright   Copyright (c) 2018 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

define(
    [
        'jquery',
        'Magento_Captcha/js/view/checkout/defaultCaptcha',
        'Magento_Captcha/js/model/captchaList',
        'Plumrocket_Popuplogin/js/action/register'
    ],
    function (
        $,
        defaultCaptcha,
        captchaList,
        loginAction
    ) {
        'use strict';

        return defaultCaptcha.extend({
            /** @inheritdoc */
            initialize: function () {
                var self = this,
                    currentCaptcha;

                this._super();
                currentCaptcha = captchaList.getCaptchaByFormId(this.formId);

                if (currentCaptcha != null) {
                    currentCaptcha.setIsVisible(true);
                    this.setCurrentCaptcha(currentCaptcha);
                    self.refresh();

                    loginAction.registerCallback(function (loginData) {
                        self.refresh();
                        $('#captcha_prpl_registration_form').prop('disabled', false);
                        $('#captcha_prpl_registration_form').removeClass('_disabled');
                        $('input[name="captcha_form_id"]').prop('disabled', false);
                        $('input[name="captcha_form_id"]').removeClass('_disabled');
                    });
                }
            }
        });
    }
);
