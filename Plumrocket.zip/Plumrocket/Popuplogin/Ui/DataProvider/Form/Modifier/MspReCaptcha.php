<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Popuplogin
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Popuplogin\Ui\DataProvider\Form\Modifier;

use Magento\Framework\Module\Manager;
use Magento\Framework\ObjectManagerInterface;
use Plumrocket\Popuplogin\Helper\Config;

/**
 * Set settings for MSP reCAPTCHA if module is enabled,
 * otherwise completely remove recaptcha component
 *
 * @since 2.2.0
 */
class MspReCaptcha
{
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    private $objectManager;

    /**
     * @var \Magento\Framework\Module\Manager
     */
    private $moduleManager;

    /**
     * @var \Plumrocket\Popuplogin\Helper\Config
     */
    private $config;

    /**
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Magento\Framework\Module\Manager         $moduleManager
     * @param \Plumrocket\Popuplogin\Helper\Config      $config
     */
    public function __construct(
        ObjectManagerInterface $objectManager,
        Manager $moduleManager,
        Config $config
    ) {
        $this->objectManager = $objectManager;
        $this->moduleManager = $moduleManager;
        $this->config = $config;
    }

    public function modify(array $jsLayout): array
    {
        if ($this->isEnabled()) {
            $recaptchaSettings = $this->getRecaptchaSettings();
            foreach ($jsLayout['components']['prpl-popuplogin']['children'] as $area => $areaData) {
                if (isset($areaData['children']['msp_recaptcha'])) {
                    $areaData['children']['msp_recaptcha']['settings'] = $recaptchaSettings;
                }
                $jsLayout['components']['prpl-popuplogin']['children'][$area] = $areaData;
            }
            return $jsLayout;
        }

        foreach ($jsLayout['components']['prpl-popuplogin']['children'] as $area => $areaData) {
            unset($areaData['children']['msp_recaptcha']);
            $jsLayout['components']['prpl-popuplogin']['children'][$area] = $areaData;
        }
        return $jsLayout;
    }

    /**
     * Check if magento has enabled MSP reCAPTCHA module and it enabled for frontend
     *
     * @return bool
     */
    private function isEnabled(): bool
    {
        return $this->moduleManager->isEnabled('MSP_ReCaptcha')
            && $this->config->getConfig('msp_securitysuite_recaptcha/frontend/enabled');
    }

    /**
     * Retrieve recaptcha settings for MSP ReCaptcha module
     *
     * @return array
     */
    public function getRecaptchaSettings(): array
    {
        $settings = $this->objectManager
            ->create(\MSP\ReCaptcha\Model\LayoutSettings::class)
            ->getCaptchaSettings();

        return $this->fixForDisplayInPopup($settings);
    }

    /**
     * @param array $settings
     * @return array
     */
    private function fixForDisplayInPopup(array $settings): array
    {
        if (isset($settings['size']) && $settings['size'] === 'compact') {
            $settings['size'] = 'normal';
        }

        if (isset($settings['badge']) && $settings['badge'] !== 'invisible') {
            $settings['badge'] = 'inline';
        }

        return $settings;
    }
}
