<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Popuplogin
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Popuplogin\Ui\DataProvider\Form\Modifier;

use Magento\Framework\Module\Manager;
use Magento\Framework\ObjectManagerInterface;

/**
 * Set settings for Magento reCAPTCHA if module is enabled,
 * otherwise completely remove recaptcha component
 *
 * @since 2.2.0
 */
class MagentoReCaptcha
{
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    private $objectManager;

    /**
     * @var \Magento\Framework\Module\Manager
     */
    private $moduleManager;

    /**
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Magento\Framework\Module\Manager         $moduleManager
     */
    public function __construct(
        ObjectManagerInterface $objectManager,
        Manager $moduleManager
    ) {
        $this->objectManager = $objectManager;
        $this->moduleManager = $moduleManager;
    }

    public function modify(array $jsLayout): array
    {
        if ($this->isEnabled()) {
            foreach (['registration', 'login', 'forgotpassword'] as $area) {
                if ($this->isEnabledForArea($area)) {
                    $jsLayout['components']['prpl-popuplogin']['children'][$area]['children']['re_captcha']['settings']
                        = $this->getRecaptchaSettings($area);
                } else {
                    unset($jsLayout['components']['prpl-popuplogin']['children'][$area]['children']['re_captcha']);
                }
            }
            return $jsLayout;
        }

        foreach ($jsLayout['components']['prpl-popuplogin']['children'] as $area => $areaData) {
            unset($areaData['children']['re_captcha']);
            $jsLayout['components']['prpl-popuplogin']['children'][$area] = $areaData;
        }
        return $jsLayout;
    }

    /**
     * Check if magento has enabled reCAPTCHA module
     *
     * @return bool
     */
    private function isEnabled(): bool
    {
        return $this->moduleManager->isEnabled('Magento_ReCaptchaUi');
    }

    private function isEnabledForArea(string $area): bool
    {
        /** @var \Magento\ReCaptchaUi\Model\IsCaptchaEnabledInterface $isCaptchaEnabled */
        $isCaptchaEnabled = $this->objectManager->get(\Magento\ReCaptchaUi\Model\IsCaptchaEnabledInterface::class);
        return $isCaptchaEnabled->isCaptchaEnabledFor($this->areaToKey($area));
    }

    /**
     * Retrieve recaptcha settings for MSP ReCaptcha module
     *
     * @param string $area
     * @return array
     */
    public function getRecaptchaSettings(string $area): array
    {
        /** @var \Magento\ReCaptchaUi\Model\UiConfigResolverInterface $uiConfigResolver*/
        $uiConfigResolver = $this->objectManager->get(\Magento\ReCaptchaUi\Model\UiConfigResolverInterface::class);
        return $this->fixForDisplayInPopup($uiConfigResolver->get($this->areaToKey($area)));
    }

    /**
     * @param string $area
     * @return string
     */
    private function areaToKey(string $area): string
    {
        $areaToKeyMapping = [
            'login'          => 'customer_login',
            'registration'   => 'customer_create',
            'forgotpassword' => 'customer_forgot_password',
        ];

        return $areaToKeyMapping[$area];
    }

    /**
     * @param array $settings
     * @return array
     */
    private function fixForDisplayInPopup(array $settings): array
    {
        if (isset($settings['rendering']['size']) && $settings['rendering']['size'] === 'compact') {
            $settings['rendering']['size'] = 'normal';
        }

        return $settings;
    }
}
