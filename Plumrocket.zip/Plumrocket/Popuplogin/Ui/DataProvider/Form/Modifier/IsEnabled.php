<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Popuplogin
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Popuplogin\Ui\DataProvider\Form\Modifier;

use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Filesystem\DriverInterface;
use Magento\Framework\Module\Dir\Reader;
use Plumrocket\Popuplogin\Helper\Config\Design;
use Plumrocket\Popuplogin\Helper\Config\ForgotPasswordForm;
use Plumrocket\Popuplogin\Helper\Config\LoginForm;
use Plumrocket\Popuplogin\Helper\Config\RegistrationForm;

/**
 * Check configuration for each area (login, register, forgot password)
 * and if they disabled remove them from js layout
 *
 * @since 2.2.0
 */
class IsEnabled
{
    /**
     * @var \Plumrocket\Popuplogin\Helper\Config\Design
     */
    private $designConfig;

    /**
     * @var \Plumrocket\Popuplogin\Helper\Config\LoginForm
     */
    private $loginFormConfig;

    /**
     * @var \Plumrocket\Popuplogin\Helper\Config\RegistrationForm
     */
    private $registrationFormConfig;

    /**
     * @var \Plumrocket\Popuplogin\Helper\Config\ForgotPasswordForm
     */
    private $forgotPasswordFormConfig;

    /**
     * @var \Magento\Framework\Module\Dir\Reader
     */
    private $dirReader;

    /**
     * @var \Magento\Framework\Filesystem\DriverInterface
     */
    private $fileDriver;

    /**
     * @param \Plumrocket\Popuplogin\Helper\Config\Design             $designConfig
     * @param \Plumrocket\Popuplogin\Helper\Config\LoginForm          $loginFormConfig
     * @param \Plumrocket\Popuplogin\Helper\Config\RegistrationForm   $registrationFormConfig
     * @param \Plumrocket\Popuplogin\Helper\Config\ForgotPasswordForm $forgotPasswordFormConfig
     * @param \Magento\Framework\Module\Dir\Reader                    $dirReader
     * @param \Magento\Framework\Filesystem\DriverInterface           $fileDriver
     */
    public function __construct(
        Design $designConfig,
        LoginForm $loginFormConfig,
        RegistrationForm $registrationFormConfig,
        ForgotPasswordForm $forgotPasswordFormConfig,
        Reader $dirReader,
        DriverInterface $fileDriver
    ) {
        $this->designConfig = $designConfig;
        $this->loginFormConfig = $loginFormConfig;
        $this->registrationFormConfig = $registrationFormConfig;
        $this->forgotPasswordFormConfig = $forgotPasswordFormConfig;
        $this->dirReader = $dirReader;
        $this->fileDriver = $fileDriver;
    }

    public function modify(array $jsLayout): array
    {
        $component = $jsLayout['components']['prpl-popuplogin'];
        $theme = $this->designConfig->getTheme();

        $areaStatuses = [
            'registration' => $this->registrationFormConfig->isEnabled(),
            'login' => $this->loginFormConfig->isEnabled(),
            'forgotpassword' => $this->forgotPasswordFormConfig->isEnabled(),
        ];

        foreach ($areaStatuses as $area => $isEnabled) {
            if ($isEnabled) {
                $templateFormat = $component['children'][$area]['config']['template'];
                $component['children'][$area]['config']['template']
                    = $this->getThemeDir($templateFormat, $theme, $area);
            } else {
                unset($component['children'][$area]);
            }
        }

        $templateFormat = $component['children']['registration_success']['config']['template'];
        $component['children']['registration_success']['config']['template']
            = $this->getThemeDir($templateFormat, $theme, 'registration_success');

        $jsLayout['components']['prpl-popuplogin'] = $component;

        return $jsLayout;
    }

    /**
     * @param string $templateFormat
     * @param string $theme
     * @param string $area
     * @return string
     */
    private function getThemeDir(string $templateFormat, string $theme, string $area): string
    {
        $dir = $this->dirReader->getModuleDir('view', 'Plumrocket_Popuplogin') .
            '/frontend/web/template/themes/' . $theme;

        try {
            if (! $this->fileDriver->isDirectory($dir)
                || ! $this->fileDriver->isDirectory($dir . '/forms')
                || ! $this->fileDriver->isExists($dir . '/forms/' . $area . '.phtml')
            ) {
                $theme = 'default';
            }
        } catch (FileSystemException $e) {
            $theme = 'default';
        }

        return sprintf($templateFormat, $theme);
    }
}
