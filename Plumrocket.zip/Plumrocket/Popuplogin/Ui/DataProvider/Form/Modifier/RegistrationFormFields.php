<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Popuplogin
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Popuplogin\Ui\DataProvider\Form\Modifier;

use Magento\Checkout\Block\Checkout\AttributeMerger;
use Magento\Customer\Model\AttributeMetadataDataProvider;
use Magento\Directory\Model\ResourceModel\Region\Collection;
use Magento\Ui\Component\Form\AttributeMapper;
use Plumrocket\Popuplogin\Block\DirectoryBlock;
use Plumrocket\Popuplogin\Helper\Config\RegistrationForm;
use Plumrocket\Popuplogin\Model\Config\Source\Subscriptions;

/**
 * @since 2.2.0
 */
class RegistrationFormFields
{
    /**
     * @var \Plumrocket\Popuplogin\Helper\Config\RegistrationForm
     */
    private $registrationFormConfig;

    /**
     * @var \Magento\Customer\Model\AttributeMetadataDataProvider
     */
    private $attributeMetadataDataProvider;

    /**
     * @var \Magento\Ui\Component\Form\AttributeMapper
     */
    private $attributeMapper;

    /**
     * @var \Magento\Checkout\Block\Checkout\AttributeMerger
     */
    private $merger;

    /**
     * @var \Magento\Directory\Model\ResourceModel\Country\Collection
     */
    private $countryCollection;

    /**
     * @var \Magento\Directory\Model\ResourceModel\Region\Collection
     */
    private $regionCollection;

    /**
     * @var \Plumrocket\Popuplogin\Block\DirectoryBlock
     */
    private $topDestinationCountries;

    /**
     * @param \Plumrocket\Popuplogin\Helper\Config\RegistrationForm     $registrationFormConfig
     * @param \Magento\Customer\Model\AttributeMetadataDataProvider     $attributeMetadataDataProvider
     * @param \Magento\Ui\Component\Form\AttributeMapper                $attributeMapper
     * @param \Magento\Checkout\Block\Checkout\AttributeMerger          $merger
     * @param \Magento\Directory\Model\ResourceModel\Country\Collection $countryCollection
     * @param \Magento\Directory\Model\ResourceModel\Region\Collection  $regionCollection
     * @param \Plumrocket\Popuplogin\Block\DirectoryBlock               $topDestinationCountries
     */
    public function __construct(
        RegistrationForm $registrationFormConfig,
        AttributeMetadataDataProvider $attributeMetadataDataProvider,
        AttributeMapper $attributeMapper,
        AttributeMerger $merger,
        \Magento\Directory\Model\ResourceModel\Country\Collection $countryCollection,
        Collection $regionCollection,
        DirectoryBlock $topDestinationCountries
    ) {
        $this->registrationFormConfig = $registrationFormConfig;
        $this->attributeMetadataDataProvider = $attributeMetadataDataProvider;
        $this->attributeMapper = $attributeMapper;
        $this->merger = $merger;
        $this->countryCollection = $countryCollection;
        $this->regionCollection = $regionCollection;
        $this->topDestinationCountries = $topDestinationCountries;
    }

    public function modify(array $jsLayout): array
    {
        if (! $this->registrationFormConfig->isEnabled()
            || ! ($formFields = $this->registrationFormConfig->getFormFields())) {
            return $jsLayout;
        }

        $registration = $jsLayout['components']['prpl-popuplogin']['children']['registration'];
        $registerFields = $registration['children']['registration-fieldset']['children'];

        /** @var \Magento\Eav\Api\Data\AttributeInterface[] $attributes */
        $attributes = [];

        $attributes['register'] = $this->attributeMetadataDataProvider->loadAttributesCollection(
            'customer',
            'customer_account_create'
        );
        $attributes['address'] = $this->attributeMetadataDataProvider->loadAttributesCollection(
            'customer_address',
            'customer_register_address'
        );

        $elements = [];
        foreach ($attributes as $type) {
            foreach ($type as $attribute) {
                $attributeCode = $attribute->getAttributeCode();
                $elements[$attributeCode] = $this->attributeMapper->map($attribute);
                if (isset($elements[$attributeCode]['sortOrder'])) {
                    $elements[$attributeCode]['sortOrder']
                        = $formFields[$attributeCode]['sort_order'] ?? $elements[$attributeCode]['sortOrder'];
                }
                if (isset($elements[$attributeCode]['label'])) {
                    $elements[$attributeCode]['label']
                        = $formFields[$attributeCode]['label'] ?? __($elements[$attributeCode]['label']);
                }
                if (isset($elements[$attributeCode]['visible'])) {
                    $elements[$attributeCode]['visible']
                        = isset($formFields[$attributeCode]['enable']) && $formFields[$attributeCode]['enable'];
                }
            }
        }

        if (isset($elements['region_id']['visible'])) {
            $elements['region_id']['visible']
                = isset($formFields['region']['enable']) && $formFields['region']['enable'];
            $elements['region_id']['sortOrder']
                = $formFields['region']['sort_order'] ?? $elements['region']['sortOrder'];
        }
        $hideRegion = empty($elements['region_id']['visible']);

        foreach (['password', 'password_confirmation'] as $fieldName) {
            if ($formFields[$fieldName]['enable']) {
                $registerFields[$fieldName]['sortOrder'] = $formFields[$fieldName]['sort_order'];
                $registerFields[$fieldName]['label']
                    = $formFields[$fieldName]['label'] ?? __($registerFields[$fieldName]['label']);
            } else {
                unset($registerFields[$fieldName]);
            }
        }

        $subscriptionFlow = $this->registrationFormConfig->getSubscriptionFlow();
        if ($subscriptionFlow === Subscriptions::HIDE || $subscriptionFlow === Subscriptions::HIDE_AND_SUBSCRIBE) {
            unset($registerFields['subscribe']);
        } else {
            $registerFields['subscribe']['value'] = $subscriptionFlow === Subscriptions::SHOW_CHECKED;
        }

        $mergedFields = $this->merger->merge(
            $elements,
            'prplProvider',
            'prpl-popuplogin',
            $registerFields
        );

        if ($hideRegion) {
            unset($mergedFields['region'], $mergedFields['region_id']);
        }

        foreach ($mergedFields as $key => &$field) {
            if ($key === 'dob') {
                $field['options'] = [
                    'changeYear' => true,
                    'changeMonth' => true,
                ];
            }
            if (isset($field['visible'])
                && ! (isset($formFields[$key]['enable']) && (bool) $formFields[$key]['enable'])
                && $key !== 'subscribe'
            ) {
                unset($mergedFields[$key]);
                continue;
            }

            if (isset($field['sortOrder'], $formFields[$key]['sort_order'])) {
                $field['sortOrder'] = $formFields[$key]['sort_order'];
            }

            if (isset($field['label']) && !isset($field['placeholder'])) {
                $field['placeholder'] = __($field['label']);
                if (isset($field['children'])) {
                    foreach ($field['children'] as $childKey => &$field_ch) {
                        $field_ch['placeholder'] = __($field['label']) . " " . ($childKey + 1);
                    }
                }
            }
        }

        if (isset($mergedFields['gender'])) {
            $mergedFields['gender']['options'][0]['label'] = 'Please select ' . $mergedFields['gender']['label'];
        }

        $registration['children']['registration-fieldset']['children'] = $mergedFields;
        $jsLayout['components']['prpl-popuplogin']['children']['registration'] = $registration;

        $jsLayout['components']['prplProvider']['dictionaries'] = [
            'country_id' => $this->countryCollection
                ->loadByStore()
                ->setForegroundCountries($this->topDestinationCountries->getTopDestinations())->toOptionArray(),
            'region_id' => $this->regionCollection->addAllowedCountriesFilter()->toOptionArray(),
        ];

        return $jsLayout;
    }
}
