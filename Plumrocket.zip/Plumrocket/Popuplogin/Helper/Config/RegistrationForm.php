<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Popuplogin
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Popuplogin\Helper\Config;

use Magento\Framework\App\Helper\Context;
use Plumrocket\Base\Helper\ConfigUtils;
use Plumrocket\Popuplogin\Model\Config\Backend\FormFields;

/**
 * @since 2.2.0
 */
class RegistrationForm extends ConfigUtils
{
    const XML_PATH_SHOW = 'prpopuplogin/registration/show';
    const XML_PATH_FORM_FIELD = 'prpopuplogin/registration/form_fields';
    const XML_PATH_SUBSCRIPTION = 'prpopuplogin/registration/subscribe';

    /**
     * @var \Plumrocket\Popuplogin\Model\Config\Backend\FormFields
     */
    private $formFieldsModel;

    public function __construct(
        Context $context,
        FormFields $formFieldsModel
    ) {
        parent::__construct($context);
        $this->formFieldsModel = $formFieldsModel;
    }

    /**
     * @param null $scopeCode
     * @param null $scopeType
     * @return bool
     */
    public function isEnabled($scopeCode = null, $scopeType = null): bool
    {
        return (bool) $this->getConfig(self::XML_PATH_SHOW, $scopeCode, $scopeType);
    }

    /**
     * @param null $scopeCode
     * @param null $scopeType
     * @return array
     */
    public function getFormFields($scopeCode = null, $scopeType = null): array
    {
        return $this->formFieldsModel->parseValue(
            $this->getConfig(self::XML_PATH_FORM_FIELD, $scopeCode, $scopeType)
        );
    }

    /**
     * @param null $scopeCode
     * @param null $scopeType
     * @return int
     */
    public function getSubscriptionFlow($scopeCode = null, $scopeType = null): int
    {
        return (int) $this->getConfig(self::XML_PATH_SUBSCRIPTION, $scopeCode, $scopeType);
    }
}
