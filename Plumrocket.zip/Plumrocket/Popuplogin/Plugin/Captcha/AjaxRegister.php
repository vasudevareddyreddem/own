<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_PopupLogin
 * @copyright   Copyright (c) 2018 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Popuplogin\Plugin\Captcha;

class AjaxRegister
{
    /**
     * @var array
     */
    private $formIds;

    /**
     * @var \Plumrocket\Popuplogin\Model\Captcha\Checker
     */
    private $captchaChecker;

    /**
     * AjaxRegister constructor
     *
     * @param array $formIds
     * @param \Plumrocket\Popuplogin\Model\Captcha\Checker $captchaChecker
     */
    public function __construct(
        array $formIds,
        \Plumrocket\Popuplogin\Model\Captcha\Checker $captchaChecker
    ) {
        $this->formIds = $formIds;
        $this->captchaChecker = $captchaChecker;
    }

    public function aroundExecute(
        \Plumrocket\Popuplogin\Controller\Ajax\Register $subject,
        \Closure $proceed
    ) {
        $credentials = $subject->getRequest()->getParams();

        if ($result = $this->captchaChecker->checkCaptcha($credentials, $this->formIds)) {
            return $result;
        }

        return $proceed();
    }
}
