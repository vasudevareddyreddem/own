<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_PopupLogin
 * @copyright   Copyright (c) 2018 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Popuplogin\Plugin\Captcha\Helper;

class Data
{
    /**
     * @var \Plumrocket\Popuplogin\Helper\Data
     */
    private $dataHelper;

    /**
     * Data constructor.
     *
     * @param \Plumrocket\Popuplogin\Helper\Data $dataHelper
     */
    public function __construct(\Plumrocket\Popuplogin\Helper\Data $dataHelper)
    {
        $this->dataHelper = $dataHelper;
    }

    /**
     * @param \Magento\Captcha\Helper\Data $subject
     * @param                              $result
     * @param                              $key
     * @param null                         $store
     * @return string
     */
    public function afterGetConfig(\Magento\Captcha\Helper\Data $subject, $result, $key, $store = null)
    {
        if ($this->dataHelper->moduleEnabled() && 'forms' === $key && $result) {
            if (strpos($result, 'user_login') !== false) {
                $result .= ',prpl_login_form';
            }

            if (strpos($result, 'user_create') !== false) {
                $result .= ',prpl_registration_form';
            }

            if (strpos($result, 'user_forgotpassword') !== false) {
                $result .= ',prpl_forgotpassword_form';
            }
        }

        return $result;
    }
}
