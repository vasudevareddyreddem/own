<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_PopupLogin
 * @copyright   Copyright (c) 2018 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Popuplogin\Plugin\Captcha;

class AjaxLogin
{
    /**
     * @var \Magento\Framework\Serialize\SerializerInterface
     */
    private $serializer;

    /**
     * @var \Magento\Captcha\Helper\Data
     */
    private $helper;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var \Plumrocket\Popuplogin\Helper\Data
     */
    private $dataHelper;

    /**
     * AjaxLogin constructor.
     *
     * @param \Magento\Captcha\Helper\Data $helper
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     * @param \Plumrocket\Popuplogin\Helper\Data $dataHelper
     * @param \Magento\Framework\Serialize\SerializerInterface $serializer
     */
    public function __construct(
        \Magento\Captcha\Helper\Data $helper,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Plumrocket\Popuplogin\Helper\Data $dataHelper,
        \Magento\Framework\Serialize\SerializerInterface $serializer
    ) {
        $this->helper = $helper;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->dataHelper = $dataHelper;
        $this->serializer = $serializer;
    }

    /**
     * @param \Magento\Customer\Controller\Ajax\Login $subject
     * @param \Closure $proceed
     * @return $this
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function aroundExecute(
        \Magento\Customer\Controller\Ajax\Login $subject,
        \Closure $proceed
    ) {
        $loginFormId = 'user_login';
        $popupLoginFormId = 'prpl_login_form';

        if (! $this->helper->getConfig('enable')) {
            return $proceed();
        }

        $targetForms = $this->getTargetForms();
        if (! in_array($loginFormId, $targetForms)) {
            return $proceed();
        }

        $captchaModel = $this->helper->getCaptcha($loginFormId);
        $popupCaptchaModel = $this->helper->getCaptcha($popupLoginFormId);
        $captchaInputName = 'captcha_string';

        $request = $subject->getRequest();
        $loginParams = [];
        $content = $request->getContent();
        if ($content) {
            $loginParams = $this->serializer->unserialize($content);
        }

        $username = isset($loginParams['username']) ? $loginParams['username'] : null;
        $captchaString = isset($loginParams[$captchaInputName]) ? $loginParams[$captchaInputName] : null;

        if ($captchaModel->isRequired($username) && null == $captchaString) {
            return $this->setResultJsonData([
                'errors' => true,
                'show_captcha' => true,
                'message' => __('Invalid login or password.')
            ]);
        }

        if ($captchaModel->isRequired($username)) {
            if (! $popupCaptchaModel->isCorrect($captchaString)) {
                return $this->setResultJsonData([
                    'errors' => true,
                    'show_captcha' => true,
                    'message' => __('Incorrect CAPTCHA')
                ]);
            }
        }

        $captchaModel->logAttempt($username);

        return $proceed();
    }

    /**
     *
     * @return array
     */
    private function getTargetForms()
    {
        $formsString = (string)$this->helper->getConfig('forms');
        return explode(',', $formsString);
    }

    /**
     *
     * @param array $data
     * @return \Magento\Framework\Controller\Result\Json
     */
    private function setResultJsonData($data)
    {
        $resultJson = $this->resultJsonFactory->create();
        return $resultJson->setData($data);
    }
}
