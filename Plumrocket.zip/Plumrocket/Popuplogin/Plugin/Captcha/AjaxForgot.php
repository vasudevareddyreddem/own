<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_PopupLogin
 * @copyright   Copyright (c) 2018 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Popuplogin\Plugin\Captcha;

class AjaxForgot
{
    /**
     * @var \Magento\Framework\Serialize\SerializerInterface
     */
    private $serializer;

    /**
     * @var array
     */
    private $formIds;

    /**
     * @var \Plumrocket\Popuplogin\Model\Captcha\Checker
     */
    private $captchaChecker;

    /**
     * @var \Plumrocket\Popuplogin\Helper\Data
     */
    private $dataHelper;

    /**
     * AjaxForgot constructor.
     *
     * @param \Plumrocket\Popuplogin\Model\Captcha\Checker $captchaChecker
     * @param \Plumrocket\Popuplogin\Helper\Data $dataHelper
     * @param \Magento\Framework\Serialize\SerializerInterface $serializer
     * @param array $formIds
     */
    public function __construct(
        \Plumrocket\Popuplogin\Model\Captcha\Checker $captchaChecker,
        \Plumrocket\Popuplogin\Helper\Data $dataHelper,
        \Magento\Framework\Serialize\SerializerInterface $serializer,
        array $formIds = []
    ) {
        $this->formIds = $formIds;
        $this->captchaChecker = $captchaChecker;
        $this->dataHelper = $dataHelper;
        $this->serializer = $serializer;
    }

    public function aroundExecute(
        \Plumrocket\Popuplogin\Controller\Ajax\Forgot $subject,
        \Closure $proceed
    ) {
        if (! $this->dataHelper->moduleEnabled()) {
            return $proceed();
        }

        $credentials = null;
        $content = $subject->getRequest()->getContent();

        if ($content) {
            $credentials = $this->serializer->unserialize($content);
        }

        if ($result = $this->captchaChecker->checkCaptcha($credentials, $this->formIds)) {
            return $result;
        }

        return $proceed();
    }
}
