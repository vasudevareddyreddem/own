<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Popuplogin
 * @copyright   Copyright (c) 2018 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Popuplogin\Plugin;

class AddressValidatePlugin
{
    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    private $request;

    /**
     * @var \Plumrocket\Popuplogin\Helper\Data
     */
    private $dataHelper;

    /**
     * AddressValidatePlugin constructor.
     *
     * @param \Magento\Framework\App\RequestInterface $httpRequest
     * @param \Plumrocket\Popuplogin\Helper\Data      $dataHelper
     */
    public function __construct(
        \Magento\Framework\App\RequestInterface $httpRequest,
        \Plumrocket\Popuplogin\Helper\Data $dataHelper
    ) {
        $this->request = $httpRequest;
        $this->dataHelper = $dataHelper;
    }

    /**
     * @param $subject
     * @param $errors
     * @return bool
     */
    public function afterValidate($subject, $errors)
    {
        if (! $this->dataHelper->moduleEnabled()) {
            return $errors;
        }

        if ('prpopuplogin' === $this->request->getModuleName()
            || 'resetpasswordpost' === $this->request->getActionName()
            || ('confirm' === $this->request->getActionName() && 'customer' === $this->request->getModuleName())
        ) {
            return true;
        }

        return $errors;
    }
}
