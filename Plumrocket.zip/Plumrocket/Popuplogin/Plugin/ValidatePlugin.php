<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_Popuplogin
 * @copyright   Copyright (c) 2018 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Popuplogin\Plugin;

class ValidatePlugin
{
    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * @var \Plumrocket\Popuplogin\Helper\Data
     */
    protected $_helper;

    /**
     * @var \Magento\Customer\Model\Customer
     */
    private $_customer;

    /**
     * @var \Magento\Customer\Model\Address
     */
    private $_address;

    /**
     * @var \Plumrocket\Popuplogin\Helper\Data
     */
    private $dataHelper;

    /**
     * ValidatePlugin constructor.
     *
     * @param \Magento\Framework\App\RequestInterface $httpRequest
     * @param \Plumrocket\Popuplogin\Helper\Data      $helperData
     * @param \Magento\Customer\Model\Customer        $customer
     * @param \Magento\Customer\Model\Address         $address
     * @param \Plumrocket\Popuplogin\Helper\Data      $dataHelper
     */
    public function __construct(
        \Magento\Framework\App\RequestInterface $httpRequest,
        \Plumrocket\Popuplogin\Helper\Data $helperData,
        \Magento\Customer\Model\Customer $customer,
        \Magento\Customer\Model\Address $address,
        \Plumrocket\Popuplogin\Helper\Data $dataHelper
    ) {
        $this->_request = $httpRequest;
        $this->_helper   = $helperData;
        $this->_customer   = $customer;
        $this->_address   = $address;
        $this->dataHelper = $dataHelper;
    }

    /**
     * @param            $subject
     * @param            $entityName
     * @param            $groupName
     * @param array|null $builderConfig
     * @return array
     */
    public function beforeCreateValidator($subject, $entityName, $groupName, array $builderConfig = null)
    {
        if (! $this->dataHelper->moduleEnabled()) {
            return [$entityName, $groupName, $builderConfig];
        }

        if ('prpopuplogin' === $this->_request->getModuleName()
            || 'resetpasswordpost' === $this->_request->getActionName()
            || ('confirm' === $this->_request->getActionName() && 'customer' === $this->_request->getModuleName())
        ) {
            $builderConfig = $this->_getBuilderConfig($entityName, $builderConfig);
        }

        return [$entityName, $groupName, $builderConfig];
    }

    /**
     * @param $entityName
     * @param $builderConfig
     * @return array
     */
    protected function _getBuilderConfig($entityName, $builderConfig)
    {
        $allAttributes = [];
        $validateAttributes = [];
        if ($entityName === 'customer') {
            $allAttributes = $this->_customer->getEntityType()->getAttributeCollection()->getItems();
        } elseif ($entityName === 'customer_address') {
            $allAttributes = $this->_address->getEntityType()->getAttributeCollection()->getItems();
        }

        if (count($allAttributes)) {
            $enableAttributes = \Zend_Json::decode(
                $this->_helper->getConfig($this->_helper->getConfigSectionId() . '/registration/form_fields')
            );
            foreach ($allAttributes as $attribute) {
                $attributeCode = $attribute->getAttributeCode();
                if (isset($enableAttributes[$attributeCode])) {
                    $attribute->setIsVisible($enableAttributes[$attributeCode][1]);
                }
                $validateAttributes[] = $attribute;
            }

            if (count($validateAttributes)) {
                $builderConfig = [
                    'eav_data_validator' => [['method' => 'setAttributes', 'arguments' => [
                        'attributesCodes' => $validateAttributes
                    ]]]
                ];
            }
        }

        return $builderConfig;
    }
}
