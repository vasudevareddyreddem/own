<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Popuplogin\Test\Unit\Model\Social\Buttons;

use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use PHPUnit\Framework\TestCase;

class PreparerTest extends TestCase
{
    /**
     * @var \Plumrocket\Popuplogin\Model\Social\Buttons\Preparer
     */
    private $model;

    protected function setUp(): void
    {
        $objectManager = new ObjectManager($this);

        $this->model = $objectManager->getObject(\Plumrocket\Popuplogin\Model\Social\Buttons\Preparer::class);
    }

    /**
     * @dataProvider getLotsOfButtons
     *
     * @param $preparedButtons
     * @param $expect
     */
    public function testReduceVisibleQty($preparedButtons, $expect)
    {
        $this->assertSame(
            $expect['visible'],
            $this->model->execute($preparedButtons, 'visible')
        );

        $this->assertSame(
            $expect['hidden'],
            $this->model->execute($preparedButtons, 'hidden')
        );
    }

    /**
     * @dataProvider getFewVisibleButtons
     *
     * @param $preparedButtons
     * @param $expect
     */
    public function testReduceVisibleQtyWithSameQty($preparedButtons, $expect)
    {
        $this->assertSame(
            $expect['visible'],
            $this->model->execute($preparedButtons, 'visible')
        );

        $this->assertSame(
            $expect['hidden'],
            $this->model->execute($preparedButtons, 'hidden')
        );
    }

    /**
     * @dataProvider getFewButtons
     *
     * @param $preparedButtons
     * @param $expect
     */
    public function testNoReduceIfVisibleCountLessThenCutCount($preparedButtons, $expect)
    {
        $this->assertSame(
            $expect['visible'],
            $this->model->execute($preparedButtons, 'visible')
        );

        $this->assertSame(
            $expect['hidden'],
            $this->model->execute($preparedButtons, 'hidden')
        );
    }

    /**
     * @dataProvider getZeroButtons
     *
     * @param $preparedButtons
     * @param $expect
     */
    public function testReduceEmptyArray($preparedButtons, $expect)
    {
        $this->assertSame(
            $expect['visible'],
            $this->model->execute($preparedButtons, 'visible')
        );

        $this->assertSame(
            $expect['hidden'],
            $this->model->execute($preparedButtons, 'hidden')
        );
    }

    /**
     * @return array
     */
    public function getLotsOfButtons()
    {
        return [
            [
                'preparedButtons' => [
                    'google'   => [
                        'type'    => 'google',
                        'visible' => true,
                    ],
                    'yahoo'    => [
                        'type'    => 'yahoo',
                        'visible' => true,
                    ],
                    'linkedin' => [
                        'type'    => 'linkedin',
                        'visible' => true,
                    ],
                    'paypal'   => [
                        'type'    => 'paypal',
                        'visible' => true,
                    ],
                    'qq'       => [
                        'type'    => 'qq',
                        'visible' => true,
                    ],
                ],
                'expect' => [
                    'visible' => [
                        'google'   => [
                            'type'    => 'google',
                            'visible' => true,
                        ],
                        'yahoo'    => [
                            'type'    => 'yahoo',
                            'visible' => true,
                        ],
                        'linkedin' => [
                            'type'    => 'linkedin',
                            'visible' => true,
                        ],
                    ],
                    'hidden' => [
                        'paypal'   => [
                            'type'    => 'paypal',
                            'visible' => false,
                        ],
                        'qq'       => [
                            'type'    => 'qq',
                            'visible' => false,
                        ],
                    ],
                ],
            ]
        ];
    }

    /**
     * @return array
     */
    public function getFewButtons()
    {
        return [
            [
                'preparedButtons' => [
                    'google'   => [
                        'type'    => 'google',
                        'visible' => true,
                    ],
                    'yahoo'    => [
                        'type'    => 'yahoo',
                        'visible' => true,
                    ],
                    'linkedin' => [
                        'type'    => 'linkedin',
                        'visible' => true,
                    ],
                ],
                'expect' => [
                    'visible' => [
                        'google'   => [
                            'type'    => 'google',
                            'visible' => true,
                        ],
                        'yahoo'    => [
                            'type'    => 'yahoo',
                            'visible' => true,
                        ],
                        'linkedin' => [
                            'type'    => 'linkedin',
                            'visible' => true,
                        ],
                    ],
                    'hidden' => []
                ],
            ]
        ];
    }

    /**
     * @return array
     */
    public function getFewVisibleButtons()
    {
        return [
            [
                'preparedButtons' => [
                    'google'   => [
                        'type'    => 'google',
                        'visible' => true,
                    ],
                    'yahoo'    => [
                        'type'    => 'yahoo',
                        'visible' => false,
                    ],
                    'linkedin' => [
                        'type'    => 'linkedin',
                        'visible' => false,
                    ],
                    'paypal'   => [
                        'type'    => 'paypal',
                        'visible' => false,
                    ],
                    'qq'       => [
                        'type'    => 'qq',
                        'visible' => false,
                    ],
                ],
                'expect' => [
                    'visible' => [
                        'google'   => [
                            'type'    => 'google',
                            'visible' => true,
                        ],
                    ],
                    'hidden' => [
                        'yahoo'    => [
                            'type'    => 'yahoo',
                            'visible' => false,
                        ],
                        'linkedin' => [
                            'type'    => 'linkedin',
                            'visible' => false,
                        ],
                        'paypal'   => [
                            'type'    => 'paypal',
                            'visible' => false,
                        ],
                        'qq'       => [
                            'type'    => 'qq',
                            'visible' => false,
                        ],
                    ],
                ],
            ]
        ];
    }

    /**
     * @return array
     */
    public function getZeroButtons()
    {
        return [
            [
                'preparedButtons' => [],
                'expect' => [
                    'visible' => [],
                    'hidden' => [],
                ]
            ],
        ];
    }
}
