<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_SocialLoginPro
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Popuplogin\Block\Popuplogin;

class Social extends \Magento\Framework\View\Element\Template
{
    /**
     * @var string
     */
    private $configuredSocialModuleName;

    /**
     * @var \Plumrocket\Base\Helper\Base
     */
    private $baseHelper;

    /**
     * @var \Plumrocket\Popuplogin\Model\Social\Buttons\PreparerFactory
     */
    private $buttonPreparerFactory;

    /**
     * Social constructor.
     *
     * @param \Magento\Framework\View\Element\Template\Context            $context
     * @param \Plumrocket\Base\Helper\Base                                $baseHelper
     * @param \Plumrocket\Popuplogin\Model\Social\Buttons\PreparerFactory $buttonPreparerFactory
     * @param array                                                       $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Plumrocket\Base\Helper\Base $baseHelper,
        \Plumrocket\Popuplogin\Model\Social\Buttons\PreparerFactory $buttonPreparerFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->baseHelper = $baseHelper;
        $this->buttonPreparerFactory = $buttonPreparerFactory;
    }

    /**
     * @param $htmlBefore
     * @return string
     */
    public function getSocialLoginButtonsHtml($htmlBefore)
    {
        if ($moduleName = $this->getConfiguredSocialModuleName()) {
            $html = $this->createSocialBlock($moduleName)
                ->setButtonPreparer($this->buttonPreparerFactory->create())
                ->setTemplate("Plumrocket_$moduleName::customer/form/login/buttons.phtml")
                ->toHtml();

            return $this->escapeJs($htmlBefore . $html);
        }

        return '';
    }

    /**
     * @param $htmlBefore
     * @return string
     */
    public function getSocialRegisterButtonsHtml($htmlBefore)
    {
        if ($moduleName = $this->getConfiguredSocialModuleName()) {
            $html = $this->createSocialBlock($moduleName)
                ->setButtonPreparer($this->buttonPreparerFactory->create())
                ->setTemplate(
                    ('SocialLoginPro' === $moduleName)
                        ? "Plumrocket_$moduleName::customer/form/register/prpl/buttons.phtml"
                        : "Plumrocket_$moduleName::customer/form/register/buttons.phtml"
                )
                ->toHtml();

            return $this->escapeJs($htmlBefore . $html);
        }

        return '';
    }

    /**
     * @return string
     */
    private function getConfiguredSocialModuleName()
    {
        if (null === $this->configuredSocialModuleName) {
            $this->configuredSocialModuleName = '';

            if (2 === $this->baseHelper->moduleExists('SocialLoginPro')) {
                $moduleName = 'SocialLoginPro';
            } elseif (2 === $this->baseHelper->moduleExists('SocialLoginFree')) {
                $moduleName = 'SocialLoginFree';
            }

            if (isset($moduleName)) {
                if ($moduleName === 'SocialLoginPro') {
                    /** @var \Plumrocket\SocialLoginPro\Helper\Data $socialHelper */
                    $socialHelper = $this->baseHelper->getModuleHelper($moduleName);
                    if ($socialHelper->modulePositionEnabled('login') && $socialHelper->hasButtons()) {
                        $this->configuredSocialModuleName = $moduleName;
                    }

                    return $this->configuredSocialModuleName;
                }

                /**
                 * @var \Plumrocket\SocialLoginFree\Helper\Data $socialHelper
                 * @var \Plumrocket\SocialLoginFree\Helper\Config $socialConfig
                 */
                $socialHelper = $this->baseHelper->getModuleHelper($moduleName);
                $socialConfig = $this->baseHelper->getConfigHelper($moduleName);
                if ($socialConfig->isModulePositionEnabled('login') && $socialHelper->hasButtons()) {
                    $this->configuredSocialModuleName = $moduleName;
                }
            }
        }

        return $this->configuredSocialModuleName;
    }

    /**
     * @param $moduleName
     * @return \Plumrocket\SocialLoginPro\Block\Buttons|\Plumrocket\SocialLoginFree\Block\Buttons
     */
    private function createSocialBlock($moduleName)
    {
        return $this->getLayout()->createBlock("Plumrocket\\$moduleName\Block\Buttons");
    }
}
