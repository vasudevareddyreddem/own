<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_PopupLogin
 * @copyright   Copyright (c) 2015 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Popuplogin\Block\Adminhtml\System\Config\Form\FormFields;

use \Magento\Backend\Block\Widget\Grid\Extended;
use \Magento\Framework\Data\Form\Element\Renderer\RendererInterface;
use \Plumrocket\Popuplogin\Block\Adminhtml\System\Config\Form\FormFields\InputTable\Column as InputTableColumn;

class InputTable extends Extended implements RendererInterface
{
    /**
     * @var \Magento\Framework\Data\Form\Element\AbstractElement
     */
    protected $_element;

    /**
     * @var string
     */
    protected $_containerFieldId = null;

    /**
     * @var string
     */
    protected $_rowKey = null;

    /**
     * @var \Magento\Framework\Data\CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var \Magento\Framework\DataObjectFactory
     */
    protected $dataObjectFactory;

    /**
     * InputTable constructor.
     *
     * @param \Magento\Backend\Block\Template\Context   $context
     * @param \Magento\Backend\Helper\Data              $backendHelper
     * @param \Magento\Framework\Data\CollectionFactory $collectionFactory
     * @param \Magento\Framework\DataObjectFactory      $dataObjectFactory
     * @param array                                     $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Magento\Framework\Data\CollectionFactory $collectionFactory,
        \Magento\Framework\DataObjectFactory $dataObjectFactory,
        array $data = []
    ) {
        parent::__construct($context, $backendHelper, $data);
        $this->collectionFactory = $collectionFactory;
        $this->dataObjectFactory = $dataObjectFactory;
    }

    // ******************************************
    // *                                        *
    // *           Grid functions               *
    // *                                        *
    // ******************************************
    public function _construct()
    {
        parent::_construct();
        $this->setPagerVisibility(false);
        $this->setFilterVisibility(false);
        $this->setMessageBlockVisibility(false);
    }

    /**
     * @param string                              $columnId
     * @param array|\Magento\Framework\DataObject $column
     *
     * @return $this
     * @throws \Exception
     */
    public function addColumn($columnId, $column)
    {
        if (is_array($column)) {
            $column['sortable'] = false;
            $this->getColumnSet()->setChild(
                $columnId,
                $this->getLayout()
                    ->createBlock(InputTableColumn::class)
                    ->setData($column)
                    ->setId($columnId)
                    ->setGrid($this)
            );
            $this->getColumnSet()->getChildBlock($columnId)->setGrid($this);
        } else {
            throw new \Exception(__('Please correct the column format and try again.'));
        }

        $this->_lastColumnId = $columnId;
        return $this;
    }

    /**
     * @return bool
     */
    public function canDisplayContainer()
    {
        return false;
    }

    /**
     * @return $this
     */
    protected function _prepareLayout()
    {
        return \Magento\Backend\Block\Widget::_prepareLayout();
    }

    /**
     * @param array $array
     *
     * @return $this
     */
    public function setArray($array)
    {
        $collection = $this->collectionFactory->create();
        $i = 1;
        if (is_array($array)) {
            foreach ($array as $item) {
                if (!$item instanceof \Magento\Framework\DataObject) {
                    $item = $this->dataObjectFactory->create(['data' => $item]);
                }
                if (!$item->getId()) {
                    $item->setId($i);
                }
                $collection->addItem($item);
                $i++;
            }
        }
        $this->setCollection($collection);
        return $this;
    }

    /**
     * @return string
     */
    public function getRowKey()
    {
        return $this->_rowKey;
    }

    /**
     * @param $key
     *
     * @return $this
     */
    public function setRowKey($key)
    {
        $this->_rowKey = $key;
        return $this;
    }

    /**
     * @return string
     */
    public function getContainerFieldId()
    {
        return $this->_containerFieldId;
    }

    /**
     * @param string $name
     *
     * @return $this
     */
    public function setContainerFieldId($name)
    {
        $this->_containerFieldId = $name;
        return $this;
    }

    // ******************************************
    // *                                        *
    // *           Render functions             *
    // *                                        *
    // ******************************************

    /**
     * @param \Magento\Framework\Data\Form\Element\AbstractElement $element
     *
     * @return string
     */
    public function render(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $this->setElement($element);
        return '
            <tr>
                <td class="label">' . $element->getLabelHtml() . '</td>
                <td class="value">' . $this->toHtml() . '</td>
            </tr>';
    }

    /**
     * @param \Magento\Framework\Data\Form\Element\AbstractElement $element
     *
     * @return $this
     */
    public function setElement(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $this->_element = $element;
        return $this;
    }

    /**
     * @return \Magento\Framework\Data\Form\Element\AbstractElement
     */
    public function getElement()
    {
        return $this->_element;
    }
}
