<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_PopupLogin
 * @copyright   Copyright (c) 2019 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\Popuplogin\Block;

class Style extends \Magento\Framework\View\Element\Template
{
    /**
     * @param $field
     * @return string
     */
    public function getStyles($field)
    {
        $styles = $this->_scopeConfig->getValue(
            'prpopuplogin/design/' . $field,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );

        return (string)$styles;
    }

    /**
     * @return bool
     */
    public function isStyleEnabled()
    {
        $enable = $this->_scopeConfig->getValue(
            'prpopuplogin/design/show_design',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );

        return (bool)$enable;
    }
}
