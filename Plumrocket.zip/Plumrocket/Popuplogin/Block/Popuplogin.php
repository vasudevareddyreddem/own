<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_PopupLogin
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\Popuplogin\Block;

use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\Template;
use Magento\Theme\Block\Html\Header\Logo;
use Plumrocket\Base\Model\Utils\IsMatchUrl as BaseUtilsIsMatchUrl;
use Plumrocket\Popuplogin\Helper\Config;
use Plumrocket\Popuplogin\Helper\Config\EventTracking as EventTrackingConfig;
use Plumrocket\Popuplogin\Model\Config\Source\Pages;
use Plumrocket\Popuplogin\Model\Config\Source\ShowOn;
use Plumrocket\Popuplogin\Ui\DataProvider\Form\Modifier\IsEnabled as IsEnabledModifier;
use Plumrocket\Popuplogin\Ui\DataProvider\Form\Modifier\MagentoReCaptcha as MagentoReCaptchaModifier;
use Plumrocket\Popuplogin\Ui\DataProvider\Form\Modifier\MspReCaptcha as MspReCaptchaModifier;
use Plumrocket\Popuplogin\Ui\DataProvider\Form\Modifier\RegistrationFormFields as RegistrationFormFieldsModifier;

class Popuplogin extends Template
{
    /**
     * @var array
     */
    protected $jsLayout;

    /**
     * @var \Plumrocket\Popuplogin\Helper\Data
     */
    private $helper;

    /**
     * @var \Magento\Customer\Model\Session
     */
    private $customerSession;

    /**
     * @var EventTrackingConfig
     */
    private $eventTrackingConfig;

    /**
     * @var \Plumrocket\Base\Model\Utils\IsMatchUrl
     */
    private $isMatchUrl;

    /**
     * @var \Plumrocket\Popuplogin\Helper\Config
     */
    private $config;

    /**
     * @var \Plumrocket\Popuplogin\Ui\DataProvider\Form\Modifier\IsEnabled
     */
    private $isEnabledModifier;

    /**
     * @var RegistrationFormFieldsModifier
     */
    private $registrationFormFieldsModifier;

    /**
     * @var MspReCaptchaModifier
     */
    private $mspReCaptchaModifier;

    /**
     * @var \Plumrocket\Popuplogin\Ui\DataProvider\Form\Modifier\MagentoReCaptcha
     */
    private $magentoReCaptchaModifier;

    /**
     * @var \Magento\Framework\Serialize\SerializerInterface
     */
    private $serializer;

    /**
     * phpcs:disable Generic.Files.LineLength
     *
     * @param \Magento\Framework\View\Element\Template\Context                            $context
     * @param \Plumrocket\Popuplogin\Helper\Data                                          $helper
     * @param \Magento\Customer\Model\Session                                             $customerSession
     * @param \Plumrocket\Popuplogin\Helper\Config\EventTracking                          $eventTrackingConfig
     * @param \Plumrocket\Base\Model\Utils\IsMatchUrl                                     $isMatchUrl
     * @param \Plumrocket\Popuplogin\Helper\Config                                        $config
     * @param \Plumrocket\Popuplogin\Ui\DataProvider\Form\Modifier\IsEnabled              $isEnabledModifier
     * @param \Plumrocket\Popuplogin\Ui\DataProvider\Form\Modifier\RegistrationFormFields $registrationFormFieldsModifier
     * @param \Plumrocket\Popuplogin\Ui\DataProvider\Form\Modifier\MspReCaptcha           $mspReCaptchaModifier
     * @param \Plumrocket\Popuplogin\Ui\DataProvider\Form\Modifier\MagentoReCaptcha       $magentoReCaptchaModifier
     * @param \Magento\Framework\Serialize\SerializerInterface                            $serializer
     * @param array                                                                       $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Plumrocket\Popuplogin\Helper\Data $helper,
        \Magento\Customer\Model\Session $customerSession,
        EventTrackingConfig $eventTrackingConfig,
        BaseUtilsIsMatchUrl $isMatchUrl,
        Config $config,
        IsEnabledModifier $isEnabledModifier,
        RegistrationFormFieldsModifier $registrationFormFieldsModifier,
        MspReCaptchaModifier $mspReCaptchaModifier,
        MagentoReCaptchaModifier $magentoReCaptchaModifier,
        SerializerInterface $serializer,
        array $data = []
    ) {
        // phpcs:enable Generic.Files.LineLength
        parent::__construct($context, $data);
        $this->jsLayout = isset($data['jsLayout']) && is_array($data['jsLayout']) ? $data['jsLayout'] : [];
        $this->helper = $helper;
        $this->customerSession = $customerSession;
        $this->eventTrackingConfig = $eventTrackingConfig;
        $this->isMatchUrl = $isMatchUrl;
        $this->config = $config;
        $this->isEnabledModifier = $isEnabledModifier;
        $this->registrationFormFieldsModifier = $registrationFormFieldsModifier;
        $this->mspReCaptchaModifier = $mspReCaptchaModifier;
        $this->magentoReCaptchaModifier = $magentoReCaptchaModifier;
        $this->serializer = $serializer;
    }

    /**
     * Get js layout from layout and modify depends on configuration
     *
     * @return string
     */
    public function getJsLayout()
    {
        $jsLayout = $this->jsLayout;
        $jsLayout = $this->isEnabledModifier->modify($jsLayout);
        $jsLayout = $this->registrationFormFieldsModifier->modify($jsLayout);
        $jsLayout = $this->mspReCaptchaModifier->modify($jsLayout);
        $jsLayout = $this->magentoReCaptchaModifier->modify($jsLayout);
        return $this->serializer->serialize($jsLayout);
    }

    /**
     * @return array
     */
    public function getConfig()
    {
        $config = $this->helper->getConfig($this->helper->getConfigSectionId());

        $loginCustomPage = $config['login']['custom_page'] ?? '';
        $registrationCustomPage = $config['registration']['custom_page'] ?? '';

        $config_success_page = $config['login']['success_page'] ?? '';
        $config['login']['success_page_url'] = $this->_getSuccessUrl($config_success_page, $loginCustomPage);
        $config['login']['url'] = $this->getUrl('customer/ajax/login');
        $config_success_page = $config['registration']['success_page'] ?? '';
        $config['registration']['success_page_url']
            = $this->_getSuccessUrl($config_success_page, $registrationCustomPage);
        $config['registration']['url'] = $this->getUrl('prpopuplogin/ajax/register');

        $config['forgotpassword']['url'] = $this->getUrl('prpopuplogin/ajax/forgot');

        $blockLogo = $this->getLayout()->getBlock('logo');
        if (!$blockLogo) {
            /** @var \Magento\Theme\Block\Html\Header\Logo $blockLogo */
            $blockLogo = $this->getLayout()->createBlock(Logo::class, uniqid(microtime()));
        }
        $config['design']['alt'] = $blockLogo->getLogoAlt();

        if ($config['design']['logo']) {
            $path = $this->helper->getConfigSectionId().'/'.$config['design']['logo'];
            $baseUrl = $this->_urlBuilder->getBaseUrl(['_type' => UrlInterface::URL_TYPE_MEDIA]);
            $config['design']['logo'] = $baseUrl.$path;
        } else {
            $config['design']['logo'] = $blockLogo->getLogoSrc();
        }

        unset($config['general']['serial']);

        return $config;
    }

    protected function _getSuccessUrl($successPage, $customPage): string
    {
        switch ($successPage) {
            case '':
            case Pages::STAY_ON_PAGE:
            case Pages::COMPLETE_ACTION:
                $page = '';
                break;
            case Pages::CUSTOM_URL:
                $page = $customPage;
                break;
            case Pages::ACCOUNT_PAGE:
                $page = $this->getUrl('customer/account');
                break;
            case Pages::LOGIN_PAGE:
                $page = $this->getUrl('customer/account/login');
                break;
            default:
                $page = $this->getUrl($successPage);
                break;
        }
        return $page;
    }

    protected function _toHtml()
    {
        if (!$this->helper->moduleEnabled()
            || $this->customerSession->getCustomerGroupId()
            || !$this->_checkLocation()
        ) {
            $this->setTemplate('');
        }
        if ($this->helper->moduleEnabled() && $this->customerSession->getAffiliateTrackingCode() === true) {
            $this->customerSession->setAffiliateTrackingCode(false);
            $this->setTemplate('trackingcode.phtml');
        }
        return parent::_toHtml();
    }

    /**
     * @deplacated since 2.2.0
     * @see getRegistrationAffiliateTrackingHtml
     * @return string
     */
    public function getTrackingCode()
    {
        return $this->getRegistrationAffiliateTrackingHtml();
    }

    public function getRegistrationAffiliateTrackingHtml(): string
    {
        return $this->eventTrackingConfig->getRegistrationAffiliateCode();
    }

    protected function _checkLocation(): bool
    {
        $showOn = $this->config->getShowOn();
        if ($showOn === ShowOn::ALL) {
            return true;
        }

        $key = ($showOn === ShowOn::ENABLE) ? 'enable_on': 'disable_on';
        $urls = explode("\n", $this->helper->getConfig($this->helper->getConfigSectionId().'/general/'.$key));
        $urls = array_filter(array_map('trim', $urls));
        if ($this->isMatchUrl->executeList($this->_urlBuilder->getCurrentUrl(), $urls)) {
            return $showOn === ShowOn::ENABLE;
        }

        return $showOn !== ShowOn::ENABLE;
    }

    /**
     * @deplacated was added only for compatibility with magento 2.1
     *
     * @return bool
     */
    public function enablePasswordStrength(): bool
    {
        return true;
    }
}
