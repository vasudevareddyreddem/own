<?php
/**
 * BSS Commerce Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://bsscommerce.com/Bss-Commerce-License.txt
 *
 * @category   BSS
 * @package    Bss_GiftCard
 * @author     Extension Team
 * @copyright  Copyright (c) 2017-2018 BSS Commerce Co. ( http://bsscommerce.com )
 * @license    http://bsscommerce.com/Bss-Commerce-License.txt
 */

namespace Bss\GiftCard\Block\Adminhtml\Items\Column\Name;

use Magento\Backend\Block\Template\Context;
use Bss\GiftCard\Helper\Catalog\Product\Configuration;
use Magento\Sales\Block\Adminhtml\Items\Column\Name as ColumnName;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\CatalogInventory\Api\StockConfigurationInterface;
use Magento\Framework\Registry;
use Magento\Catalog\Model\Product\OptionFactory;

/**
 * Class GiftCard
 *
 * @package Bss\GiftCard\Block\Adminhtml\Items\Column\Name
 */
class GiftCard extends ColumnName
{
    /**
     * @var Configuration
     */
    private $configurationHelper;

    /**
     * @param Context $context
     * @param StockRegistryInterface $stockRegistry
     * @param StockConfigurationInterface $stockConfiguration
     * @param Registry $registry
     * @param OptionFactory $optionFactory
     * @param Configuration $configurationHelper
     * @param array $data
     */
    public function __construct(
        Context $context,
        StockRegistryInterface $stockRegistry,
        StockConfigurationInterface $stockConfiguration,
        Registry $registry,
        OptionFactory $optionFactory,
        Configuration $configurationHelper,
        array $data = []
    ) {
        $this->configurationHelper = $configurationHelper;
        parent::__construct(
            $context,
            $stockRegistry,
            $stockConfiguration,
            $registry,
            $optionFactory,
            $data
        );
    }

    /**
     * @return array
     */
    public function getOrderOptions()
    {
        return array_merge(
            $this->getOptionConvert(),
            parent::getOrderOptions()
        );
    }

    /**
     * Truncate string
     *
     * @param string $value
     * @param int $length
     * @param string $etc
     * @param string &$remainder
     * @param bool $breakWords
     * @return string
     */
    public function truncateString(
        $value,
        $length = 80,
        $etc = '...',
        &$remainder = '',
        $breakWords = true
    ) {
        $length = 350;
        return parent::truncateString(
            $value,
            $length,
            $etc,
            $remainder,
            $breakWords
        );
    }

    /**
     * @return array
     */
    private function getOptionConvert()
    {
        $options = $this->getItem()->getProductOptions();
        $buyRequest = [];
        if (isset($options['info_buyRequest'])) {
            $buyRequest = $options['info_buyRequest'];
        }
        return $this->configurationHelper->renderOptions($buyRequest);
    }

    /**
     * @param string|array $data
     * @param array|null $allowedTags
     * @return string
     */
    public function escapeHtml($data, $allowedTags = null)
    {
        $options = $this->getOptionConvert();
        if (!empty($options)) {
            $optionValue = array_column($options, 'value');
            if (in_array($data, $optionValue)) {
                return $data;
            }
        }
        return parent::escapeHtml($data, $allowedTags);
    }
}
