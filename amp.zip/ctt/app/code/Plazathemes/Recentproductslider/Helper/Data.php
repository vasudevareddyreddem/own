<?php
/**
* Copyright © 2015 PlazaThemes.com. All rights reserved.

* @author PlazaThemes Team <contact@plazathemes.com>
*/

namespace Plazathemes\Recentproductslider\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper {

}
